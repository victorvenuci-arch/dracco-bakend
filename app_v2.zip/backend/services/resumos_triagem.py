import logging
from typing import Optional, Dict, Any, List

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from models.resumos_triagem import Resumos_triagem

logger = logging.getLogger(__name__)


# ------------------ Service Layer ------------------
class Resumos_triagemService:
    """Service layer for Resumos_triagem operations"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, data: Dict[str, Any], user_id: Optional[str] = None) -> Optional[Resumos_triagem]:
        """Create a new resumos_triagem"""
        try:
            if user_id:
                data['user_id'] = user_id
            obj = Resumos_triagem(**data)
            self.db.add(obj)
            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Created resumos_triagem with id: {obj.id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error creating resumos_triagem: {str(e)}")
            raise

    async def check_ownership(self, obj_id: int, user_id: str) -> bool:
        """Check if user owns this record"""
        try:
            obj = await self.get_by_id(obj_id, user_id=user_id)
            return obj is not None
        except Exception as e:
            logger.error(f"Error checking ownership for resumos_triagem {obj_id}: {str(e)}")
            return False

    async def get_by_id(self, obj_id: int, user_id: Optional[str] = None) -> Optional[Resumos_triagem]:
        """Get resumos_triagem by ID (user can only see their own records)"""
        try:
            query = select(Resumos_triagem).where(Resumos_triagem.id == obj_id)
            if user_id:
                query = query.where(Resumos_triagem.user_id == user_id)
            result = await self.db.execute(query)
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching resumos_triagem {obj_id}: {str(e)}")
            raise

    async def get_list(
        self, 
        skip: int = 0, 
        limit: int = 20, 
        user_id: Optional[str] = None,
        query_dict: Optional[Dict[str, Any]] = None,
        sort: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get paginated list of resumos_triagems (user can only see their own records)"""
        try:
            query = select(Resumos_triagem)
            count_query = select(func.count(Resumos_triagem.id))
            
            if user_id:
                query = query.where(Resumos_triagem.user_id == user_id)
                count_query = count_query.where(Resumos_triagem.user_id == user_id)
            
            if query_dict:
                for field, value in query_dict.items():
                    if hasattr(Resumos_triagem, field):
                        query = query.where(getattr(Resumos_triagem, field) == value)
                        count_query = count_query.where(getattr(Resumos_triagem, field) == value)
            
            count_result = await self.db.execute(count_query)
            total = count_result.scalar()

            if sort:
                if sort.startswith('-'):
                    field_name = sort[1:]
                    if hasattr(Resumos_triagem, field_name):
                        query = query.order_by(getattr(Resumos_triagem, field_name).desc())
                else:
                    if hasattr(Resumos_triagem, sort):
                        query = query.order_by(getattr(Resumos_triagem, sort))
            else:
                query = query.order_by(Resumos_triagem.id.desc())

            result = await self.db.execute(query.offset(skip).limit(limit))
            items = result.scalars().all()

            return {
                "items": items,
                "total": total,
                "skip": skip,
                "limit": limit,
            }
        except Exception as e:
            logger.error(f"Error fetching resumos_triagem list: {str(e)}")
            raise

    async def update(self, obj_id: int, update_data: Dict[str, Any], user_id: Optional[str] = None) -> Optional[Resumos_triagem]:
        """Update resumos_triagem (requires ownership)"""
        try:
            obj = await self.get_by_id(obj_id, user_id=user_id)
            if not obj:
                logger.warning(f"Resumos_triagem {obj_id} not found for update")
                return None
            for key, value in update_data.items():
                if hasattr(obj, key) and key != 'user_id':
                    setattr(obj, key, value)

            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Updated resumos_triagem {obj_id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error updating resumos_triagem {obj_id}: {str(e)}")
            raise

    async def delete(self, obj_id: int, user_id: Optional[str] = None) -> bool:
        """Delete resumos_triagem (requires ownership)"""
        try:
            obj = await self.get_by_id(obj_id, user_id=user_id)
            if not obj:
                logger.warning(f"Resumos_triagem {obj_id} not found for deletion")
                return False
            await self.db.delete(obj)
            await self.db.commit()
            logger.info(f"Deleted resumos_triagem {obj_id}")
            return True
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error deleting resumos_triagem {obj_id}: {str(e)}")
            raise

    async def get_by_field(self, field_name: str, field_value: Any) -> Optional[Resumos_triagem]:
        """Get resumos_triagem by any field"""
        try:
            if not hasattr(Resumos_triagem, field_name):
                raise ValueError(f"Field {field_name} does not exist on Resumos_triagem")
            result = await self.db.execute(
                select(Resumos_triagem).where(getattr(Resumos_triagem, field_name) == field_value)
            )
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching resumos_triagem by {field_name}: {str(e)}")
            raise

    async def list_by_field(
        self, field_name: str, field_value: Any, skip: int = 0, limit: int = 20
    ) -> List[Resumos_triagem]:
        """Get list of resumos_triagems filtered by field"""
        try:
            if not hasattr(Resumos_triagem, field_name):
                raise ValueError(f"Field {field_name} does not exist on Resumos_triagem")
            result = await self.db.execute(
                select(Resumos_triagem)
                .where(getattr(Resumos_triagem, field_name) == field_value)
                .offset(skip)
                .limit(limit)
                .order_by(Resumos_triagem.id.desc())
            )
            return result.scalars().all()
        except Exception as e:
            logger.error(f"Error fetching resumos_triagems by {field_name}: {str(e)}")
            raise