import json
import logging
from typing import List, Optional

from datetime import datetime, date

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.resumos_triagem import Resumos_triagemService
from dependencies.auth import get_current_user
from schemas.auth import UserResponse

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/resumos_triagem", tags=["resumos_triagem"])


# ---------- Pydantic Schemas ----------
class Resumos_triagemData(BaseModel):
    """Entity data schema (for create/update)"""
    cidade_id: int
    cidade_nome: str
    quantidade_pacotes: int
    data_vencimento: str = None
    auxiliar_responsavel: str = None
    status: str = None
    created_at: Optional[datetime] = None


class Resumos_triagemUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    cidade_id: Optional[int] = None
    cidade_nome: Optional[str] = None
    quantidade_pacotes: Optional[int] = None
    data_vencimento: Optional[str] = None
    auxiliar_responsavel: Optional[str] = None
    status: Optional[str] = None
    created_at: Optional[datetime] = None


class Resumos_triagemResponse(BaseModel):
    """Entity response schema"""
    id: int
    cidade_id: int
    cidade_nome: str
    quantidade_pacotes: int
    data_vencimento: Optional[str] = None
    auxiliar_responsavel: Optional[str] = None
    status: Optional[str] = None
    user_id: str
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class Resumos_triagemListResponse(BaseModel):
    """List response schema"""
    items: List[Resumos_triagemResponse]
    total: int
    skip: int
    limit: int


class Resumos_triagemBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[Resumos_triagemData]


class Resumos_triagemBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: Resumos_triagemUpdateData


class Resumos_triagemBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[Resumos_triagemBatchUpdateItem]


class Resumos_triagemBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=Resumos_triagemListResponse)
async def query_resumos_triagems(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Query resumos_triagems with filtering, sorting, and pagination (user can only see their own records)"""
    logger.debug(f"Querying resumos_triagems: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = Resumos_triagemService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
            user_id=str(current_user.id),
        )
        logger.debug(f"Found {result['total']} resumos_triagems")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying resumos_triagems: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=Resumos_triagemListResponse)
async def query_resumos_triagems_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query resumos_triagems with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying resumos_triagems: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = Resumos_triagemService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} resumos_triagems")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying resumos_triagems: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=Resumos_triagemResponse)
async def get_resumos_triagem(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get a single resumos_triagem by ID (user can only see their own records)"""
    logger.debug(f"Fetching resumos_triagem with id: {id}, fields={fields}")
    
    service = Resumos_triagemService(db)
    try:
        result = await service.get_by_id(id, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Resumos_triagem with id {id} not found")
            raise HTTPException(status_code=404, detail="Resumos_triagem not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching resumos_triagem {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=Resumos_triagemResponse, status_code=201)
async def create_resumos_triagem(
    data: Resumos_triagemData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a new resumos_triagem"""
    logger.debug(f"Creating new resumos_triagem with data: {data}")
    
    service = Resumos_triagemService(db)
    try:
        result = await service.create(data.model_dump(), user_id=str(current_user.id))
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create resumos_triagem")
        
        logger.info(f"Resumos_triagem created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating resumos_triagem: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating resumos_triagem: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[Resumos_triagemResponse], status_code=201)
async def create_resumos_triagems_batch(
    request: Resumos_triagemBatchCreateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create multiple resumos_triagems in a single request"""
    logger.debug(f"Batch creating {len(request.items)} resumos_triagems")
    
    service = Resumos_triagemService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump(), user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} resumos_triagems successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[Resumos_triagemResponse])
async def update_resumos_triagems_batch(
    request: Resumos_triagemBatchUpdateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update multiple resumos_triagems in a single request (requires ownership)"""
    logger.debug(f"Batch updating {len(request.items)} resumos_triagems")
    
    service = Resumos_triagemService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict, user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} resumos_triagems successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=Resumos_triagemResponse)
async def update_resumos_triagem(
    id: int,
    data: Resumos_triagemUpdateData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update an existing resumos_triagem (requires ownership)"""
    logger.debug(f"Updating resumos_triagem {id} with data: {data}")

    service = Resumos_triagemService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Resumos_triagem with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Resumos_triagem not found")
        
        logger.info(f"Resumos_triagem {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating resumos_triagem {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating resumos_triagem {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_resumos_triagems_batch(
    request: Resumos_triagemBatchDeleteRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple resumos_triagems by their IDs (requires ownership)"""
    logger.debug(f"Batch deleting {len(request.ids)} resumos_triagems")
    
    service = Resumos_triagemService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id, user_id=str(current_user.id))
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} resumos_triagems successfully")
        return {"message": f"Successfully deleted {deleted_count} resumos_triagems", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_resumos_triagem(
    id: int,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete a single resumos_triagem by ID (requires ownership)"""
    logger.debug(f"Deleting resumos_triagem with id: {id}")
    
    service = Resumos_triagemService(db)
    try:
        success = await service.delete(id, user_id=str(current_user.id))
        if not success:
            logger.warning(f"Resumos_triagem with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Resumos_triagem not found")
        
        logger.info(f"Resumos_triagem {id} deleted successfully")
        return {"message": "Resumos_triagem deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting resumos_triagem {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")