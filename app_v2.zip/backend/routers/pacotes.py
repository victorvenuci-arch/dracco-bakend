import json
import logging
from typing import List, Optional

from datetime import datetime, date

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.pacotes import PacotesService

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/pacotes", tags=["pacotes"])


# ---------- Pydantic Schemas ----------
class PacotesData(BaseModel):
    """Entity data schema (for create/update)"""
    codigo_rastreio: str
    cidade_id: int
    cidade_nome: str
    data_vencimento: str = None
    auxiliar_responsavel: str = None
    status: str
    created_at: Optional[datetime] = None


class PacotesUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    codigo_rastreio: Optional[str] = None
    cidade_id: Optional[int] = None
    cidade_nome: Optional[str] = None
    data_vencimento: Optional[str] = None
    auxiliar_responsavel: Optional[str] = None
    status: Optional[str] = None
    created_at: Optional[datetime] = None


class PacotesResponse(BaseModel):
    """Entity response schema"""
    id: int
    codigo_rastreio: str
    cidade_id: int
    cidade_nome: str
    data_vencimento: Optional[str] = None
    auxiliar_responsavel: Optional[str] = None
    status: str
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class PacotesListResponse(BaseModel):
    """List response schema"""
    items: List[PacotesResponse]
    total: int
    skip: int
    limit: int


class PacotesBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[PacotesData]


class PacotesBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: PacotesUpdateData


class PacotesBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[PacotesBatchUpdateItem]


class PacotesBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=PacotesListResponse)
async def query_pacotess(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Query pacotess with filtering, sorting, and pagination"""
    logger.debug(f"Querying pacotess: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = PacotesService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
        )
        logger.debug(f"Found {result['total']} pacotess")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying pacotess: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=PacotesListResponse)
async def query_pacotess_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query pacotess with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying pacotess: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = PacotesService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} pacotess")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying pacotess: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=PacotesResponse)
async def get_pacotes(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Get a single pacotes by ID"""
    logger.debug(f"Fetching pacotes with id: {id}, fields={fields}")
    
    service = PacotesService(db)
    try:
        result = await service.get_by_id(id)
        if not result:
            logger.warning(f"Pacotes with id {id} not found")
            raise HTTPException(status_code=404, detail="Pacotes not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching pacotes {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=PacotesResponse, status_code=201)
async def create_pacotes(
    data: PacotesData,
    db: AsyncSession = Depends(get_db),
):
    """Create a new pacotes"""
    logger.debug(f"Creating new pacotes with data: {data}")
    
    service = PacotesService(db)
    try:
        result = await service.create(data.model_dump())
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create pacotes")
        
        logger.info(f"Pacotes created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating pacotes: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating pacotes: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[PacotesResponse], status_code=201)
async def create_pacotess_batch(
    request: PacotesBatchCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create multiple pacotess in a single request"""
    logger.debug(f"Batch creating {len(request.items)} pacotess")
    
    service = PacotesService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump())
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} pacotess successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[PacotesResponse])
async def update_pacotess_batch(
    request: PacotesBatchUpdateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Update multiple pacotess in a single request"""
    logger.debug(f"Batch updating {len(request.items)} pacotess")
    
    service = PacotesService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} pacotess successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=PacotesResponse)
async def update_pacotes(
    id: int,
    data: PacotesUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing pacotes"""
    logger.debug(f"Updating pacotes {id} with data: {data}")

    service = PacotesService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict)
        if not result:
            logger.warning(f"Pacotes with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Pacotes not found")
        
        logger.info(f"Pacotes {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating pacotes {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating pacotes {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_pacotess_batch(
    request: PacotesBatchDeleteRequest,
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple pacotess by their IDs"""
    logger.debug(f"Batch deleting {len(request.ids)} pacotess")
    
    service = PacotesService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id)
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} pacotess successfully")
        return {"message": f"Successfully deleted {deleted_count} pacotess", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_pacotes(
    id: int,
    db: AsyncSession = Depends(get_db),
):
    """Delete a single pacotes by ID"""
    logger.debug(f"Deleting pacotes with id: {id}")
    
    service = PacotesService(db)
    try:
        success = await service.delete(id)
        if not success:
            logger.warning(f"Pacotes with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Pacotes not found")
        
        logger.info(f"Pacotes {id} deleted successfully")
        return {"message": "Pacotes deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting pacotes {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")