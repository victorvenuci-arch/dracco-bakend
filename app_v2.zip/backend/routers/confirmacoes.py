import json
import logging
from typing import List, Optional

from datetime import datetime, date

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.confirmacoes import ConfirmacoesService
from dependencies.auth import get_current_user
from schemas.auth import UserResponse

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/confirmacoes", tags=["confirmacoes"])


# ---------- Pydantic Schemas ----------
class ConfirmacoesData(BaseModel):
    """Entity data schema (for create/update)"""
    cidade_id: int
    cidade_nome: str = None
    entregador_id: str = None
    entregador_nome: str = None
    data_hora: Optional[datetime] = None
    gps_lat: float = None
    gps_lng: float = None


class ConfirmacoesUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    cidade_id: Optional[int] = None
    cidade_nome: Optional[str] = None
    entregador_id: Optional[str] = None
    entregador_nome: Optional[str] = None
    data_hora: Optional[datetime] = None
    gps_lat: Optional[float] = None
    gps_lng: Optional[float] = None


class ConfirmacoesResponse(BaseModel):
    """Entity response schema"""
    id: int
    cidade_id: int
    cidade_nome: Optional[str] = None
    entregador_id: Optional[str] = None
    entregador_nome: Optional[str] = None
    data_hora: Optional[datetime] = None
    gps_lat: Optional[float] = None
    gps_lng: Optional[float] = None
    user_id: str

    class Config:
        from_attributes = True


class ConfirmacoesListResponse(BaseModel):
    """List response schema"""
    items: List[ConfirmacoesResponse]
    total: int
    skip: int
    limit: int


class ConfirmacoesBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[ConfirmacoesData]


class ConfirmacoesBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: ConfirmacoesUpdateData


class ConfirmacoesBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[ConfirmacoesBatchUpdateItem]


class ConfirmacoesBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=ConfirmacoesListResponse)
async def query_confirmacoess(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Query confirmacoess with filtering, sorting, and pagination (user can only see their own records)"""
    logger.debug(f"Querying confirmacoess: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = ConfirmacoesService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
            user_id=str(current_user.id),
        )
        logger.debug(f"Found {result['total']} confirmacoess")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying confirmacoess: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=ConfirmacoesListResponse)
async def query_confirmacoess_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query confirmacoess with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying confirmacoess: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = ConfirmacoesService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} confirmacoess")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying confirmacoess: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=ConfirmacoesResponse)
async def get_confirmacoes(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get a single confirmacoes by ID (user can only see their own records)"""
    logger.debug(f"Fetching confirmacoes with id: {id}, fields={fields}")
    
    service = ConfirmacoesService(db)
    try:
        result = await service.get_by_id(id, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Confirmacoes with id {id} not found")
            raise HTTPException(status_code=404, detail="Confirmacoes not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching confirmacoes {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=ConfirmacoesResponse, status_code=201)
async def create_confirmacoes(
    data: ConfirmacoesData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a new confirmacoes"""
    logger.debug(f"Creating new confirmacoes with data: {data}")
    
    service = ConfirmacoesService(db)
    try:
        result = await service.create(data.model_dump(), user_id=str(current_user.id))
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create confirmacoes")
        
        logger.info(f"Confirmacoes created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating confirmacoes: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating confirmacoes: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[ConfirmacoesResponse], status_code=201)
async def create_confirmacoess_batch(
    request: ConfirmacoesBatchCreateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create multiple confirmacoess in a single request"""
    logger.debug(f"Batch creating {len(request.items)} confirmacoess")
    
    service = ConfirmacoesService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump(), user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} confirmacoess successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[ConfirmacoesResponse])
async def update_confirmacoess_batch(
    request: ConfirmacoesBatchUpdateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update multiple confirmacoess in a single request (requires ownership)"""
    logger.debug(f"Batch updating {len(request.items)} confirmacoess")
    
    service = ConfirmacoesService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict, user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} confirmacoess successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=ConfirmacoesResponse)
async def update_confirmacoes(
    id: int,
    data: ConfirmacoesUpdateData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update an existing confirmacoes (requires ownership)"""
    logger.debug(f"Updating confirmacoes {id} with data: {data}")

    service = ConfirmacoesService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Confirmacoes with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Confirmacoes not found")
        
        logger.info(f"Confirmacoes {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating confirmacoes {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating confirmacoes {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_confirmacoess_batch(
    request: ConfirmacoesBatchDeleteRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple confirmacoess by their IDs (requires ownership)"""
    logger.debug(f"Batch deleting {len(request.ids)} confirmacoess")
    
    service = ConfirmacoesService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id, user_id=str(current_user.id))
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} confirmacoess successfully")
        return {"message": f"Successfully deleted {deleted_count} confirmacoess", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_confirmacoes(
    id: int,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete a single confirmacoes by ID (requires ownership)"""
    logger.debug(f"Deleting confirmacoes with id: {id}")
    
    service = ConfirmacoesService(db)
    try:
        success = await service.delete(id, user_id=str(current_user.id))
        if not success:
            logger.warning(f"Confirmacoes with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Confirmacoes not found")
        
        logger.info(f"Confirmacoes {id} deleted successfully")
        return {"message": "Confirmacoes deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting confirmacoes {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")