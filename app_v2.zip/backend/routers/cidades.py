import json
import logging
from typing import List, Optional

from datetime import datetime, date

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.cidades import CidadesService

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/cidades", tags=["cidades"])


# ---------- Pydantic Schemas ----------
class CidadesData(BaseModel):
    """Entity data schema (for create/update)"""
    nome: str
    entregador_padrao_id: str = None
    entregador_padrao_nome: str = None
    motorista_id: str = None
    motorista_nome: str = None
    veiculo_tipo: str = None
    status: str
    created_at: Optional[datetime] = None


class CidadesUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    nome: Optional[str] = None
    entregador_padrao_id: Optional[str] = None
    entregador_padrao_nome: Optional[str] = None
    motorista_id: Optional[str] = None
    motorista_nome: Optional[str] = None
    veiculo_tipo: Optional[str] = None
    status: Optional[str] = None
    created_at: Optional[datetime] = None


class CidadesResponse(BaseModel):
    """Entity response schema"""
    id: int
    nome: str
    entregador_padrao_id: Optional[str] = None
    entregador_padrao_nome: Optional[str] = None
    motorista_id: Optional[str] = None
    motorista_nome: Optional[str] = None
    veiculo_tipo: Optional[str] = None
    status: str
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class CidadesListResponse(BaseModel):
    """List response schema"""
    items: List[CidadesResponse]
    total: int
    skip: int
    limit: int


class CidadesBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[CidadesData]


class CidadesBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: CidadesUpdateData


class CidadesBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[CidadesBatchUpdateItem]


class CidadesBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=CidadesListResponse)
async def query_cidadess(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Query cidadess with filtering, sorting, and pagination"""
    logger.debug(f"Querying cidadess: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = CidadesService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
        )
        logger.debug(f"Found {result['total']} cidadess")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying cidadess: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=CidadesListResponse)
async def query_cidadess_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query cidadess with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying cidadess: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = CidadesService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} cidadess")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying cidadess: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=CidadesResponse)
async def get_cidades(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Get a single cidades by ID"""
    logger.debug(f"Fetching cidades with id: {id}, fields={fields}")
    
    service = CidadesService(db)
    try:
        result = await service.get_by_id(id)
        if not result:
            logger.warning(f"Cidades with id {id} not found")
            raise HTTPException(status_code=404, detail="Cidades not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching cidades {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=CidadesResponse, status_code=201)
async def create_cidades(
    data: CidadesData,
    db: AsyncSession = Depends(get_db),
):
    """Create a new cidades"""
    logger.debug(f"Creating new cidades with data: {data}")
    
    service = CidadesService(db)
    try:
        result = await service.create(data.model_dump())
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create cidades")
        
        logger.info(f"Cidades created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating cidades: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating cidades: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[CidadesResponse], status_code=201)
async def create_cidadess_batch(
    request: CidadesBatchCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create multiple cidadess in a single request"""
    logger.debug(f"Batch creating {len(request.items)} cidadess")
    
    service = CidadesService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump())
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} cidadess successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[CidadesResponse])
async def update_cidadess_batch(
    request: CidadesBatchUpdateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Update multiple cidadess in a single request"""
    logger.debug(f"Batch updating {len(request.items)} cidadess")
    
    service = CidadesService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} cidadess successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=CidadesResponse)
async def update_cidades(
    id: int,
    data: CidadesUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing cidades"""
    logger.debug(f"Updating cidades {id} with data: {data}")

    service = CidadesService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict)
        if not result:
            logger.warning(f"Cidades with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Cidades not found")
        
        logger.info(f"Cidades {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating cidades {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating cidades {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_cidadess_batch(
    request: CidadesBatchDeleteRequest,
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple cidadess by their IDs"""
    logger.debug(f"Batch deleting {len(request.ids)} cidadess")
    
    service = CidadesService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id)
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} cidadess successfully")
        return {"message": f"Successfully deleted {deleted_count} cidadess", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_cidades(
    id: int,
    db: AsyncSession = Depends(get_db),
):
    """Delete a single cidades by ID"""
    logger.debug(f"Deleting cidades with id: {id}")
    
    service = CidadesService(db)
    try:
        success = await service.delete(id)
        if not success:
            logger.warning(f"Cidades with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Cidades not found")
        
        logger.info(f"Cidades {id} deleted successfully")
        return {"message": "Cidades deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting cidades {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")