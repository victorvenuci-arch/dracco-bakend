import json
import logging
from typing import List, Optional

from datetime import datetime, date

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.transferencias import TransferenciasService
from dependencies.auth import get_current_user
from schemas.auth import UserResponse

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/transferencias", tags=["transferencias"])


# ---------- Pydantic Schemas ----------
class TransferenciasData(BaseModel):
    """Entity data schema (for create/update)"""
    codigo_rastreio: str
    cidade_id: int
    cidade_nome: str = None
    motorista_id: str = None
    motorista_nome: str = None
    data_hora: Optional[datetime] = None
    gps_lat: float = None
    gps_lng: float = None


class TransferenciasUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    codigo_rastreio: Optional[str] = None
    cidade_id: Optional[int] = None
    cidade_nome: Optional[str] = None
    motorista_id: Optional[str] = None
    motorista_nome: Optional[str] = None
    data_hora: Optional[datetime] = None
    gps_lat: Optional[float] = None
    gps_lng: Optional[float] = None


class TransferenciasResponse(BaseModel):
    """Entity response schema"""
    id: int
    codigo_rastreio: str
    cidade_id: int
    cidade_nome: Optional[str] = None
    motorista_id: Optional[str] = None
    motorista_nome: Optional[str] = None
    data_hora: Optional[datetime] = None
    gps_lat: Optional[float] = None
    gps_lng: Optional[float] = None
    user_id: str

    class Config:
        from_attributes = True


class TransferenciasListResponse(BaseModel):
    """List response schema"""
    items: List[TransferenciasResponse]
    total: int
    skip: int
    limit: int


class TransferenciasBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[TransferenciasData]


class TransferenciasBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: TransferenciasUpdateData


class TransferenciasBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[TransferenciasBatchUpdateItem]


class TransferenciasBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=TransferenciasListResponse)
async def query_transferenciass(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Query transferenciass with filtering, sorting, and pagination (user can only see their own records)"""
    logger.debug(f"Querying transferenciass: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = TransferenciasService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
            user_id=str(current_user.id),
        )
        logger.debug(f"Found {result['total']} transferenciass")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying transferenciass: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=TransferenciasListResponse)
async def query_transferenciass_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query transferenciass with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying transferenciass: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = TransferenciasService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} transferenciass")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying transferenciass: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=TransferenciasResponse)
async def get_transferencias(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get a single transferencias by ID (user can only see their own records)"""
    logger.debug(f"Fetching transferencias with id: {id}, fields={fields}")
    
    service = TransferenciasService(db)
    try:
        result = await service.get_by_id(id, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Transferencias with id {id} not found")
            raise HTTPException(status_code=404, detail="Transferencias not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching transferencias {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=TransferenciasResponse, status_code=201)
async def create_transferencias(
    data: TransferenciasData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a new transferencias"""
    logger.debug(f"Creating new transferencias with data: {data}")
    
    service = TransferenciasService(db)
    try:
        result = await service.create(data.model_dump(), user_id=str(current_user.id))
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create transferencias")
        
        logger.info(f"Transferencias created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating transferencias: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating transferencias: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[TransferenciasResponse], status_code=201)
async def create_transferenciass_batch(
    request: TransferenciasBatchCreateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create multiple transferenciass in a single request"""
    logger.debug(f"Batch creating {len(request.items)} transferenciass")
    
    service = TransferenciasService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump(), user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} transferenciass successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[TransferenciasResponse])
async def update_transferenciass_batch(
    request: TransferenciasBatchUpdateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update multiple transferenciass in a single request (requires ownership)"""
    logger.debug(f"Batch updating {len(request.items)} transferenciass")
    
    service = TransferenciasService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict, user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} transferenciass successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=TransferenciasResponse)
async def update_transferencias(
    id: int,
    data: TransferenciasUpdateData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update an existing transferencias (requires ownership)"""
    logger.debug(f"Updating transferencias {id} with data: {data}")

    service = TransferenciasService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Transferencias with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Transferencias not found")
        
        logger.info(f"Transferencias {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating transferencias {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating transferencias {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_transferenciass_batch(
    request: TransferenciasBatchDeleteRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple transferenciass by their IDs (requires ownership)"""
    logger.debug(f"Batch deleting {len(request.ids)} transferenciass")
    
    service = TransferenciasService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id, user_id=str(current_user.id))
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} transferenciass successfully")
        return {"message": f"Successfully deleted {deleted_count} transferenciass", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_transferencias(
    id: int,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete a single transferencias by ID (requires ownership)"""
    logger.debug(f"Deleting transferencias with id: {id}")
    
    service = TransferenciasService(db)
    try:
        success = await service.delete(id, user_id=str(current_user.id))
        if not success:
            logger.warning(f"Transferencias with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Transferencias not found")
        
        logger.info(f"Transferencias {id} deleted successfully")
        return {"message": "Transferencias deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting transferencias {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")