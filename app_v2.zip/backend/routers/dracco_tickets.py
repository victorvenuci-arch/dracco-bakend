import logging
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update

from core.database import get_db
from models.tickets import Tickets
from services.dracco_auth import validate_token

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/dracco/tickets", tags=["dracco-tickets"])


class CreateTicketRequest(BaseModel):
    token: str
    tbr: str
    motivo: str
    base_code: str


class UpdateTicketRequest(BaseModel):
    token: str
    ticket_id: int
    status: str


class ListTicketsRequest(BaseModel):
    token: str
    base_code: Optional[str] = None


def _get_caller(token: str) -> dict:
    user_data = validate_token(token)
    if not user_data:
        raise HTTPException(status_code=401, detail="Sessão expirada")
    return user_data


@router.post("/create")
async def create_ticket(data: CreateTicketRequest, db: AsyncSession = Depends(get_db)):
    """Create a new ticket (usually auto-created by motorista on return)."""
    caller = _get_caller(data.token)

    ticket = Tickets(
        tbr=data.tbr,
        motivo=data.motivo,
        base_code=data.base_code,
        created_by=caller["nome"],
        status="ABERTO",
        created_at=datetime.now(timezone.utc),
    )
    db.add(ticket)
    await db.commit()
    await db.refresh(ticket)

    return {
        "id": ticket.id,
        "tbr": ticket.tbr,
        "motivo": ticket.motivo,
        "base_code": ticket.base_code,
        "status": ticket.status,
    }


@router.post("/list")
async def list_tickets(data: ListTicketsRequest, db: AsyncSession = Depends(get_db)):
    """List tickets. Admin sees all, Gerente sees own base + SJN9 can see PIG1."""
    caller = _get_caller(data.token)

    query = select(Tickets).order_by(Tickets.created_at.desc())

    # Filter by base for non-admin users
    if caller["level"] < 100:
        if caller["base_code"] == "SJN9":
            # SJN9 can see all
            pass
        else:
            query = query.where(Tickets.base_code == caller["base_code"])

    if data.base_code:
        query = query.where(Tickets.base_code == data.base_code)

    result = await db.execute(query.limit(200))
    tickets = result.scalars().all()

    return {
        "tickets": [
            {
                "id": t.id,
                "tbr": t.tbr,
                "motivo": t.motivo,
                "base_code": t.base_code or "",
                "created_by": t.created_by or "",
                "status": t.status or "ABERTO",
                "created_at": t.created_at.isoformat() if t.created_at else None,
            }
            for t in tickets
        ]
    }


@router.post("/update")
async def update_ticket(data: UpdateTicketRequest, db: AsyncSession = Depends(get_db)):
    """Update ticket status."""
    caller = _get_caller(data.token)

    if caller["level"] < 60:
        raise HTTPException(status_code=403, detail="Sem permissão")

    result = await db.execute(select(Tickets).where(Tickets.id == data.ticket_id))
    ticket = result.scalar_one_or_none()
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket não encontrado")

    await db.execute(
        update(Tickets).where(Tickets.id == data.ticket_id).values(status=data.status)
    )
    await db.commit()

    return {"status": "updated", "ticket_id": data.ticket_id}