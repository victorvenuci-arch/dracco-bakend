import json
import logging
from typing import List, Optional


from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.perfis_usuarios import Perfis_usuariosService
from dependencies.auth import get_current_user
from schemas.auth import UserResponse

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/perfis_usuarios", tags=["perfis_usuarios"])


# ---------- Pydantic Schemas ----------
class Perfis_usuariosData(BaseModel):
    """Entity data schema (for create/update)"""
    nome: str
    perfil: str
    cidade_vinculada_id: int = None
    cidade_vinculada_nome: str = None
    ativo: bool = None


class Perfis_usuariosUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    nome: Optional[str] = None
    perfil: Optional[str] = None
    cidade_vinculada_id: Optional[int] = None
    cidade_vinculada_nome: Optional[str] = None
    ativo: Optional[bool] = None


class Perfis_usuariosResponse(BaseModel):
    """Entity response schema"""
    id: int
    user_id: str
    nome: str
    perfil: str
    cidade_vinculada_id: Optional[int] = None
    cidade_vinculada_nome: Optional[str] = None
    ativo: Optional[bool] = None

    class Config:
        from_attributes = True


class Perfis_usuariosListResponse(BaseModel):
    """List response schema"""
    items: List[Perfis_usuariosResponse]
    total: int
    skip: int
    limit: int


class Perfis_usuariosBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[Perfis_usuariosData]


class Perfis_usuariosBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: Perfis_usuariosUpdateData


class Perfis_usuariosBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[Perfis_usuariosBatchUpdateItem]


class Perfis_usuariosBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=Perfis_usuariosListResponse)
async def query_perfis_usuarioss(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Query perfis_usuarioss with filtering, sorting, and pagination (user can only see their own records)"""
    logger.debug(f"Querying perfis_usuarioss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = Perfis_usuariosService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
            user_id=str(current_user.id),
        )
        logger.debug(f"Found {result['total']} perfis_usuarioss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying perfis_usuarioss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=Perfis_usuariosListResponse)
async def query_perfis_usuarioss_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query perfis_usuarioss with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying perfis_usuarioss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = Perfis_usuariosService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} perfis_usuarioss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying perfis_usuarioss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=Perfis_usuariosResponse)
async def get_perfis_usuarios(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get a single perfis_usuarios by ID (user can only see their own records)"""
    logger.debug(f"Fetching perfis_usuarios with id: {id}, fields={fields}")
    
    service = Perfis_usuariosService(db)
    try:
        result = await service.get_by_id(id, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Perfis_usuarios with id {id} not found")
            raise HTTPException(status_code=404, detail="Perfis_usuarios not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching perfis_usuarios {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=Perfis_usuariosResponse, status_code=201)
async def create_perfis_usuarios(
    data: Perfis_usuariosData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a new perfis_usuarios"""
    logger.debug(f"Creating new perfis_usuarios with data: {data}")
    
    service = Perfis_usuariosService(db)
    try:
        result = await service.create(data.model_dump(), user_id=str(current_user.id))
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create perfis_usuarios")
        
        logger.info(f"Perfis_usuarios created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating perfis_usuarios: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating perfis_usuarios: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[Perfis_usuariosResponse], status_code=201)
async def create_perfis_usuarioss_batch(
    request: Perfis_usuariosBatchCreateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create multiple perfis_usuarioss in a single request"""
    logger.debug(f"Batch creating {len(request.items)} perfis_usuarioss")
    
    service = Perfis_usuariosService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump(), user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} perfis_usuarioss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[Perfis_usuariosResponse])
async def update_perfis_usuarioss_batch(
    request: Perfis_usuariosBatchUpdateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update multiple perfis_usuarioss in a single request (requires ownership)"""
    logger.debug(f"Batch updating {len(request.items)} perfis_usuarioss")
    
    service = Perfis_usuariosService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict, user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} perfis_usuarioss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=Perfis_usuariosResponse)
async def update_perfis_usuarios(
    id: int,
    data: Perfis_usuariosUpdateData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update an existing perfis_usuarios (requires ownership)"""
    logger.debug(f"Updating perfis_usuarios {id} with data: {data}")

    service = Perfis_usuariosService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Perfis_usuarios with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Perfis_usuarios not found")
        
        logger.info(f"Perfis_usuarios {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating perfis_usuarios {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating perfis_usuarios {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_perfis_usuarioss_batch(
    request: Perfis_usuariosBatchDeleteRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple perfis_usuarioss by their IDs (requires ownership)"""
    logger.debug(f"Batch deleting {len(request.ids)} perfis_usuarioss")
    
    service = Perfis_usuariosService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id, user_id=str(current_user.id))
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} perfis_usuarioss successfully")
        return {"message": f"Successfully deleted {deleted_count} perfis_usuarioss", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_perfis_usuarios(
    id: int,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete a single perfis_usuarios by ID (requires ownership)"""
    logger.debug(f"Deleting perfis_usuarios with id: {id}")
    
    service = Perfis_usuariosService(db)
    try:
        success = await service.delete(id, user_id=str(current_user.id))
        if not success:
            logger.warning(f"Perfis_usuarios with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Perfis_usuarios not found")
        
        logger.info(f"Perfis_usuarios {id} deleted successfully")
        return {"message": "Perfis_usuarios deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting perfis_usuarios {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")