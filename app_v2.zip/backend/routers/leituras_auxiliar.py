import json
import logging
from typing import List, Optional

from datetime import datetime, date

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.leituras_auxiliar import Leituras_auxiliarService
from dependencies.auth import get_current_user
from schemas.auth import UserResponse

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/leituras_auxiliar", tags=["leituras_auxiliar"])


# ---------- Pydantic Schemas ----------
class Leituras_auxiliarData(BaseModel):
    """Entity data schema (for create/update)"""
    codigo_rastreio: str
    cidade_id: int
    cidade_nome: str
    data_vencimento: str = None
    auxiliar_nome: str = None
    created_at: Optional[datetime] = None


class Leituras_auxiliarUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    codigo_rastreio: Optional[str] = None
    cidade_id: Optional[int] = None
    cidade_nome: Optional[str] = None
    data_vencimento: Optional[str] = None
    auxiliar_nome: Optional[str] = None
    created_at: Optional[datetime] = None


class Leituras_auxiliarResponse(BaseModel):
    """Entity response schema"""
    id: int
    codigo_rastreio: str
    cidade_id: int
    cidade_nome: str
    data_vencimento: Optional[str] = None
    auxiliar_nome: Optional[str] = None
    user_id: str
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class Leituras_auxiliarListResponse(BaseModel):
    """List response schema"""
    items: List[Leituras_auxiliarResponse]
    total: int
    skip: int
    limit: int


class Leituras_auxiliarBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[Leituras_auxiliarData]


class Leituras_auxiliarBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: Leituras_auxiliarUpdateData


class Leituras_auxiliarBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[Leituras_auxiliarBatchUpdateItem]


class Leituras_auxiliarBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=Leituras_auxiliarListResponse)
async def query_leituras_auxiliars(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Query leituras_auxiliars with filtering, sorting, and pagination (user can only see their own records)"""
    logger.debug(f"Querying leituras_auxiliars: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = Leituras_auxiliarService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
            user_id=str(current_user.id),
        )
        logger.debug(f"Found {result['total']} leituras_auxiliars")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying leituras_auxiliars: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=Leituras_auxiliarListResponse)
async def query_leituras_auxiliars_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query leituras_auxiliars with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying leituras_auxiliars: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = Leituras_auxiliarService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} leituras_auxiliars")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying leituras_auxiliars: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=Leituras_auxiliarResponse)
async def get_leituras_auxiliar(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get a single leituras_auxiliar by ID (user can only see their own records)"""
    logger.debug(f"Fetching leituras_auxiliar with id: {id}, fields={fields}")
    
    service = Leituras_auxiliarService(db)
    try:
        result = await service.get_by_id(id, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Leituras_auxiliar with id {id} not found")
            raise HTTPException(status_code=404, detail="Leituras_auxiliar not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching leituras_auxiliar {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=Leituras_auxiliarResponse, status_code=201)
async def create_leituras_auxiliar(
    data: Leituras_auxiliarData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a new leituras_auxiliar"""
    logger.debug(f"Creating new leituras_auxiliar with data: {data}")
    
    service = Leituras_auxiliarService(db)
    try:
        result = await service.create(data.model_dump(), user_id=str(current_user.id))
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create leituras_auxiliar")
        
        logger.info(f"Leituras_auxiliar created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating leituras_auxiliar: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating leituras_auxiliar: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[Leituras_auxiliarResponse], status_code=201)
async def create_leituras_auxiliars_batch(
    request: Leituras_auxiliarBatchCreateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create multiple leituras_auxiliars in a single request"""
    logger.debug(f"Batch creating {len(request.items)} leituras_auxiliars")
    
    service = Leituras_auxiliarService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump(), user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} leituras_auxiliars successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[Leituras_auxiliarResponse])
async def update_leituras_auxiliars_batch(
    request: Leituras_auxiliarBatchUpdateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update multiple leituras_auxiliars in a single request (requires ownership)"""
    logger.debug(f"Batch updating {len(request.items)} leituras_auxiliars")
    
    service = Leituras_auxiliarService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict, user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} leituras_auxiliars successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=Leituras_auxiliarResponse)
async def update_leituras_auxiliar(
    id: int,
    data: Leituras_auxiliarUpdateData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update an existing leituras_auxiliar (requires ownership)"""
    logger.debug(f"Updating leituras_auxiliar {id} with data: {data}")

    service = Leituras_auxiliarService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Leituras_auxiliar with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Leituras_auxiliar not found")
        
        logger.info(f"Leituras_auxiliar {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating leituras_auxiliar {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating leituras_auxiliar {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_leituras_auxiliars_batch(
    request: Leituras_auxiliarBatchDeleteRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple leituras_auxiliars by their IDs (requires ownership)"""
    logger.debug(f"Batch deleting {len(request.ids)} leituras_auxiliars")
    
    service = Leituras_auxiliarService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id, user_id=str(current_user.id))
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} leituras_auxiliars successfully")
        return {"message": f"Successfully deleted {deleted_count} leituras_auxiliars", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_leituras_auxiliar(
    id: int,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete a single leituras_auxiliar by ID (requires ownership)"""
    logger.debug(f"Deleting leituras_auxiliar with id: {id}")
    
    service = Leituras_auxiliarService(db)
    try:
        success = await service.delete(id, user_id=str(current_user.id))
        if not success:
            logger.warning(f"Leituras_auxiliar with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Leituras_auxiliar not found")
        
        logger.info(f"Leituras_auxiliar {id} deleted successfully")
        return {"message": "Leituras_auxiliar deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting leituras_auxiliar {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")