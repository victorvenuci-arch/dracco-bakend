import logging
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update

from core.database import get_db
from models.dracco_users import Dracco_users
from services.dracco_auth import (
    hash_password,
    verify_password,
    create_token,
    validate_token,
    invalidate_token,
    get_roles_for_level,
    get_level_label,
    get_all_online_tokens,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/dracco", tags=["dracco-auth"])


class Step1Request(BaseModel):
    login: str


class Step1Response(BaseModel):
    user_id: int
    nome: str
    level: int
    level_label: str
    base_code: str
    roles: list[str]


class Step3Request(BaseModel):
    login: str
    role: str
    senha: str


class LoginResponse(BaseModel):
    token: str
    user_id: int
    nome: str
    login: str
    level: int
    level_label: str
    base_code: str
    role: str
    permissions: str


class HeartbeatRequest(BaseModel):
    token: str


class TokenRequest(BaseModel):
    token: str


@router.post("/login/step1", response_model=Step1Response)
async def login_step1(data: Step1Request, db: AsyncSession = Depends(get_db)):
    """Step 1: Verify username exists, return available roles."""
    result = await db.execute(
        select(Dracco_users).where(
            Dracco_users.login == data.login,
            Dracco_users.is_active == True,
        )
    )
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="Usuário não encontrado ou inativo")

    roles = get_roles_for_level(user.level)
    return Step1Response(
        user_id=user.id,
        nome=user.nome,
        level=user.level,
        level_label=get_level_label(user.level),
        base_code=user.base_code or "",
        roles=roles,
    )


@router.post("/login/step3", response_model=LoginResponse)
async def login_step3(data: Step3Request, db: AsyncSession = Depends(get_db)):
    """Step 3: Verify password and create session."""
    result = await db.execute(
        select(Dracco_users).where(
            Dracco_users.login == data.login,
            Dracco_users.is_active == True,
        )
    )
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")

    if not verify_password(data.senha, user.senha_hash):
        raise HTTPException(status_code=401, detail="Senha incorreta")

    roles = get_roles_for_level(user.level)
    if data.role not in roles:
        raise HTTPException(status_code=403, detail="Função não permitida para este nível")

    user_data = {
        "user_id": user.id,
        "nome": user.nome,
        "login": user.login,
        "level": user.level,
        "level_label": get_level_label(user.level),
        "base_code": user.base_code or "",
        "role": data.role,
        "permissions": user.permissions or "{}",
        "veiculo_tipo": user.veiculo_tipo or "",
        "login_amazon": user.login_amazon or "",
    }

    token = create_token(user.id, user_data)

    # Update online status
    await db.execute(
        update(Dracco_users)
        .where(Dracco_users.id == user.id)
        .values(is_online=True, last_activity=datetime.now(timezone.utc))
    )
    await db.commit()

    return LoginResponse(
        token=token,
        user_id=user.id,
        nome=user.nome,
        login=user.login,
        level=user.level,
        level_label=get_level_label(user.level),
        base_code=user.base_code or "",
        role=data.role,
        permissions=user.permissions or "{}",
    )


@router.post("/heartbeat")
async def heartbeat(data: HeartbeatRequest, db: AsyncSession = Depends(get_db)):
    """Update last_activity for session keep-alive."""
    user_data = validate_token(data.token)
    if not user_data:
        raise HTTPException(status_code=401, detail="Sessão expirada")

    try:
        await db.execute(
            update(Dracco_users)
            .where(Dracco_users.id == user_data["user_id"])
            .values(is_online=True, last_activity=datetime.now(timezone.utc))
        )
        await db.commit()
    except Exception:
        pass

    return {"status": "ok", "user": user_data}


@router.post("/logout")
async def logout(data: TokenRequest, db: AsyncSession = Depends(get_db)):
    """Logout and invalidate session."""
    user_data = validate_token(data.token)
    if user_data:
        try:
            await db.execute(
                update(Dracco_users)
                .where(Dracco_users.id == user_data["user_id"])
                .values(is_online=False)
            )
            await db.commit()
        except Exception:
            pass
    invalidate_token(data.token)
    return {"status": "logged_out"}


@router.post("/validate")
async def validate_session(data: TokenRequest):
    """Validate a session token."""
    user_data = validate_token(data.token)
    if not user_data:
        raise HTTPException(status_code=401, detail="Sessão expirada ou inválida")
    return {"status": "valid", "user": user_data}


@router.get("/online-users")
async def get_online_users():
    """Get all currently online users."""
    return {"users": get_all_online_tokens()}