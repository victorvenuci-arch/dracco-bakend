import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { useDraccoAuth } from '@/hooks/useDraccoAuth';
import LoginPage from './pages/Login';
import AdminMasterPage from './pages/AdminMaster';
import GerenteBasePage from './pages/GerenteBase';
import MotoristaPanelPage from './pages/MotoristaPanel';
import Auxiliar from './pages/Auxiliar';
import Entregador from './pages/Entregador';
import ScannerMotorista from './pages/ScannerMotorista';
import Historico from './pages/Historico';
import NotFound from './pages/NotFound';
import AuthCallback from './pages/AuthCallback';
import { Loader2, Truck } from 'lucide-react';
// MODULE_IMPORTS_START
// MODULE_IMPORTS_END

const queryClient = new QueryClient();

function AppContent() {
  const { user, loading, loginStep1, loginStep3, logout, switchUser } = useDraccoAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#0F172A] via-[#1E293B] to-[#0F172A] flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-emerald-500/25 mx-auto mb-4">
            <Truck className="w-8 h-8 text-white" />
          </div>
          <Loader2 className="w-6 h-6 text-emerald-400 animate-spin mx-auto mb-2" />
          <p className="text-slate-400 text-sm">Carregando DRACCO...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginPage onLoginStep1={loginStep1} onLoginStep3={loginStep3} />;
  }

  // Route based on selected role
  const role = user.role;
  const level = user.level;

  // Admin Master (level 100) or anyone who selected ADMINISTRADOR role
  if (role === 'ADMINISTRADOR' && level >= 100) {
    return <AdminMasterPage currentUser={user} onLogout={logout} onSwitchUser={switchUser} />;
  }

  // Gestor (level 60+) or anyone who selected GESTOR role
  if (role === 'GESTOR') {
    return <GerenteBasePage currentUser={user} onLogout={logout} onSwitchUser={switchUser} />;
  }

  // Motorista
  if (role === 'MOTORISTA') {
    return <MotoristaPanelPage currentUser={user} onLogout={logout} onSwitchUser={switchUser} />;
  }

  // Auxiliar and Entregador still use old pages wrapped with new auth
  // For now, render them inside BrowserRouter with the new header
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={
          role === 'AUXILIAR' ? <Auxiliar /> :
          role === 'ENTREGADOR' ? <Entregador /> :
          <NotFound />
        } />
        <Route path="/auxiliar" element={<Auxiliar />} />
        <Route path="/entregador" element={<Entregador />} />
        <Route path="/scanner" element={<ScannerMotorista />} />
        <Route path="/historico" element={<Historico />} />
        <Route path="/auth/callback" element={<AuthCallback />} />
        <Route path="*" element={<NotFound />} />
        {/* MODULE_ROUTES_START */}
        {/* MODULE_ROUTES_END */}
      </Routes>
    </BrowserRouter>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    {/* MODULE_PROVIDERS_START */}
    {/* MODULE_PROVIDERS_END */}
    <TooltipProvider>
      <Toaster />
      <AppContent />
    </TooltipProvider>
    {/* MODULE_PROVIDERS_CLOSE */}
  </QueryClientProvider>
);

export default App;