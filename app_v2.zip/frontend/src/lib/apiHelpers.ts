import { client } from './api';

/**
 * Helper functions for entity operations that use apiCall.invoke
 * to directly hit backend API endpoints, avoiding SDK proxy issues
 * with entities that have create_only=false (public/non-user-scoped data).
 */

// Generic helper for entity update via direct API call
export async function entityUpdate(
  entityName: string,
  id: number | string,
  data: Record<string, unknown>
) {
  return client.apiCall.invoke({
    url: `/api/v1/entities/${entityName}/${id}`,
    method: 'PUT',
    data,
  });
}

// Generic helper for entity delete via direct API call
export async function entityDelete(
  entityName: string,
  id: number | string
) {
  return client.apiCall.invoke({
    url: `/api/v1/entities/${entityName}/${id}`,
    method: 'DELETE',
    data: {},
  });
}

// Generic helper for entity get by ID via direct API call
export async function entityGetById(
  entityName: string,
  id: number | string
) {
  return client.apiCall.invoke({
    url: `/api/v1/entities/${entityName}/${id}`,
    method: 'GET',
    data: {},
  });
}