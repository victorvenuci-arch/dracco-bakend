import { client } from './api';

// ========== AUTH API ==========

export async function loginStep1(login: string) {
  const res = await client.apiCall.invoke({
    url: '/api/v1/dracco/login/step1',
    method: 'POST',
    data: { login },
  });
  return res.data;
}

export async function loginStep3(login: string, role: string, senha: string) {
  const res = await client.apiCall.invoke({
    url: '/api/v1/dracco/login/step3',
    method: 'POST',
    data: { login, role, senha },
  });
  return res.data;
}

export async function validateSession(token: string) {
  const res = await client.apiCall.invoke({
    url: '/api/v1/dracco/validate',
    method: 'POST',
    data: { token },
  });
  return res.data;
}

export async function heartbeat(token: string) {
  const res = await client.apiCall.invoke({
    url: '/api/v1/dracco/heartbeat',
    method: 'POST',
    data: { token },
  });
  return res.data;
}

export async function logoutSession(token: string) {
  const res = await client.apiCall.invoke({
    url: '/api/v1/dracco/logout',
    method: 'POST',
    data: { token },
  });
  return res.data;
}

export async function getOnlineUsers() {
  const res = await client.apiCall.invoke({
    url: '/api/v1/dracco/online-users',
    method: 'GET',
    data: {},
  });
  return res.data;
}

// ========== USERS API (via auto-generated entity routes) ==========

export async function listUsers(query?: Record<string, unknown>) {
  const res = await client.entities.dracco_users.query({
    query: query || {},
    limit: 200,
    sort: '-created_at',
  });
  return res.data?.items || [];
}

export async function createUser(data: Record<string, unknown>) {
  const res = await client.entities.dracco_users.create({ data });
  return res.data;
}

export async function updateUser(id: number, data: Record<string, unknown>) {
  const res = await client.apiCall.invoke({
    url: `/api/v1/entities/dracco_users/${id}`,
    method: 'PUT',
    data,
  });
  return res.data;
}

export async function deleteUser(id: number) {
  const res = await client.apiCall.invoke({
    url: `/api/v1/entities/dracco_users/${id}`,
    method: 'DELETE',
    data: {},
  });
  return res.data;
}

// ========== BASES API ==========

export async function listBases() {
  const res = await client.entities.bases.query({
    query: {},
    limit: 100,
  });
  return res.data?.items || [];
}

export async function createBase(data: Record<string, unknown>) {
  const res = await client.entities.bases.create({ data });
  return res.data;
}

export async function updateBase(id: number, data: Record<string, unknown>) {
  const res = await client.apiCall.invoke({
    url: `/api/v1/entities/bases/${id}`,
    method: 'PUT',
    data,
  });
  return res.data;
}

// ========== TICKETS API ==========

export async function createTicket(token: string, tbr: string, motivo: string, base_code: string) {
  const res = await client.apiCall.invoke({
    url: '/api/v1/dracco/tickets/create',
    method: 'POST',
    data: { token, tbr, motivo, base_code },
  });
  return res.data;
}

export async function listTickets(token: string, base_code?: string) {
  const res = await client.apiCall.invoke({
    url: '/api/v1/dracco/tickets/list',
    method: 'POST',
    data: { token, base_code: base_code || null },
  });
  return res.data;
}

export async function updateTicket(ticketId: number, status: string) {
  const token = localStorage.getItem('dracco_token') || '';
  const res = await client.apiCall.invoke({
    url: '/api/v1/dracco/tickets/update',
    method: 'POST',
    data: { token, ticket_id: ticketId, status },
  });
  return res.data;
}

export async function updateTicketStatus(token: string, ticket_id: number, status: string) {
  const res = await client.apiCall.invoke({
    url: '/api/v1/dracco/tickets/update',
    method: 'POST',
    data: { token, ticket_id, status },
  });
  return res.data;
}

// ========== CIDADES API (existing) ==========

export async function listCidades() {
  const res = await client.entities.cidades.query({
    query: {},
    limit: 500,
    sort: 'nome',
  });
  return res.data?.items || [];
}