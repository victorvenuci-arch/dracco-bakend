export type UserProfile = 'ADMINISTRADOR' | 'GESTOR' | 'AUXILIAR' | 'MOTORISTA' | 'ENTREGADOR';

export type CidadeStatus =
  | 'AGUARDANDO_DESPACHO'
  | 'EM_ROTA'
  | 'BIPAGEM_EM_ANDAMENTO'
  | 'AGUARDANDO_CONFIRMACAO_ENTREGADOR'
  | 'ENTREGUE_AO_ENTREGADOR';

export type PacoteStatus = 'AGUARDANDO_DESPACHO' | 'BIPADO';

export type VeiculoTipo = 'Van' | 'Fiorino' | 'Carro de passeio';

export interface Cidade {
  id: number;
  nome: string;
  entregador_padrao_id: string;
  entregador_padrao_nome: string;
  motorista_id: string;
  motorista_nome: string;
  veiculo_tipo: string;
  status: CidadeStatus;
  created_at: string;
}

export interface Pacote {
  id: number;
  codigo_rastreio: string;
  cidade_id: number;
  cidade_nome: string;
  data_vencimento: string;
  auxiliar_responsavel: string;
  status: PacoteStatus;
  created_at: string;
}

export interface LeituraAuxiliar {
  id: number;
  codigo_rastreio: string;
  cidade_id: number;
  cidade_nome: string;
  data_vencimento: string;
  auxiliar_nome: string;
  user_id: string;
  created_at: string;
}

export interface Rota {
  id: number;
  motorista_id: string;
  motorista_nome: string;
  veiculo_tipo: string;
  cidades_ids: string;
  cidades_nomes: string;
  status: string;
  user_id: string;
  created_at: string;
}

export interface Transferencia {
  id: number;
  codigo_rastreio: string;
  cidade_id: number;
  cidade_nome: string;
  motorista_id: string;
  motorista_nome: string;
  data_hora: string;
  gps_lat: number;
  gps_lng: number;
  user_id: string;
}

export interface Confirmacao {
  id: number;
  cidade_id: number;
  cidade_nome: string;
  entregador_id: string;
  entregador_nome: string;
  data_hora: string;
  gps_lat: number;
  gps_lng: number;
  user_id: string;
}

export interface PerfilUsuario {
  id: number;
  user_id: string;
  nome: string;
  perfil: UserProfile;
  cidade_vinculada_id: number | null;
  cidade_vinculada_nome: string | null;
  ativo: boolean;
}

export const cidadeStatusLabels: Record<CidadeStatus, string> = {
  AGUARDANDO_DESPACHO: 'Aguardando Despacho',
  EM_ROTA: 'Em Rota',
  BIPAGEM_EM_ANDAMENTO: 'Bipagem em Andamento',
  AGUARDANDO_CONFIRMACAO_ENTREGADOR: 'Aguardando Confirmação',
  ENTREGUE_AO_ENTREGADOR: 'Entregue ao Entregador',
};

export const cidadeStatusColors: Record<CidadeStatus, { bg: string; text: string; dot: string }> = {
  AGUARDANDO_DESPACHO: { bg: 'bg-slate-100', text: 'text-slate-700', dot: 'bg-slate-500' },
  EM_ROTA: { bg: 'bg-blue-100', text: 'text-blue-700', dot: 'bg-blue-500' },
  BIPAGEM_EM_ANDAMENTO: { bg: 'bg-amber-100', text: 'text-amber-700', dot: 'bg-amber-500' },
  AGUARDANDO_CONFIRMACAO_ENTREGADOR: { bg: 'bg-purple-100', text: 'text-purple-700', dot: 'bg-purple-500' },
  ENTREGUE_AO_ENTREGADOR: { bg: 'bg-green-100', text: 'text-green-700', dot: 'bg-green-500' },
};

export const cidadeStatusIcons: Record<CidadeStatus, string> = {
  AGUARDANDO_DESPACHO: '📦',
  EM_ROTA: '🚚',
  BIPAGEM_EM_ANDAMENTO: '📱',
  AGUARDANDO_CONFIRMACAO_ENTREGADOR: '📍',
  ENTREGUE_AO_ENTREGADOR: '✅',
};

export interface ResumoTriagem {
  id: number;
  cidade_id: number;
  cidade_nome: string;
  quantidade_pacotes: number;
  data_vencimento: string;
  auxiliar_responsavel: string;
  status: string;
  user_id: string;
  created_at: string;
}

export const veiculoTipos: VeiculoTipo[] = ['Van', 'Fiorino', 'Carro de passeio'];

// Timeline event types
export type TimelineEventType =
  | 'TRIAGEM_FINALIZADA'
  | 'XLS_IMPORTADO'
  | 'CIDADE_ENVIADA_ROTA'
  | 'MOTORISTA_FINALIZOU'
  | 'ENTREGADOR_CONFIRMOU'
  | 'BIPAGEM_INICIADA';

export interface TimelineEventItem {
  id: string;
  type: TimelineEventType;
  message: string;
  actor: string;
  cidade?: string;
  timestamp: string;
}

export const timelineEventConfig: Record<TimelineEventType, { icon: string; color: string; bgColor: string }> = {
  TRIAGEM_FINALIZADA: { icon: '📋', color: 'text-cyan-600', bgColor: 'bg-cyan-50' },
  XLS_IMPORTADO: { icon: '📊', color: 'text-indigo-600', bgColor: 'bg-indigo-50' },
  CIDADE_ENVIADA_ROTA: { icon: '🚚', color: 'text-amber-600', bgColor: 'bg-amber-50' },
  MOTORISTA_FINALIZOU: { icon: '✅', color: 'text-green-600', bgColor: 'bg-green-50' },
  ENTREGADOR_CONFIRMOU: { icon: '📦', color: 'text-purple-600', bgColor: 'bg-purple-50' },
  BIPAGEM_INICIADA: { icon: '📱', color: 'text-blue-600', bgColor: 'bg-blue-50' },
};