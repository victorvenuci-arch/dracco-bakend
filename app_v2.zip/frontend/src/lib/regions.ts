// Regiões do Ceará - Seletor Regional
export interface Region {
  name: string;
  cities: string[];
}

export const regioesceara: Region[] = [
  {
    name: 'CARIRI',
    cities: [
      'Juazeiro do Norte',
      'Crato',
      'Barbalha',
      'Missão Velha',
      'Nova Olinda',
      'Santana do Cariri',
      'Farias Brito',
      'Jardim',
      'Porteiras',
    ],
  },
  {
    name: 'CENTRO-SUL',
    cities: [
      'Iguatu',
      'Icó',
      'Cedro',
      'Jucás',
      'Cariús',
      'Orós',
      'Quixelô',
      'Baixio',
      'Umari',
    ],
  },
];