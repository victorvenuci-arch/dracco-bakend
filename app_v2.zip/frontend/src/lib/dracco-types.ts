// ========== User & Auth Types ==========

export type UserRole = 'ADMINISTRADOR' | 'GESTOR' | 'AUXILIAR' | 'MOTORISTA' | 'ENTREGADOR';

export interface DraccoUser {
  user_id: number;
  nome: string;
  login: string;
  level: number;
  level_label: string;
  base_code: string;
  role: UserRole;
  permissions: string;
  veiculo_tipo?: string;
  login_amazon?: string;
}

export interface DraccoUserFull {
  id: number;
  nome: string;
  login: string;
  level: number;
  base_code: string;
  permissions?: string;
  is_active: boolean;
  is_online?: boolean;
  last_activity?: string;
  veiculo_tipo?: string;
  login_amazon?: string;
  created_at?: string;
  senha_hash?: string;
}

export interface Step1Result {
  user_id: number;
  nome: string;
  level: number;
  level_label: string;
  base_code: string;
  roles: string[];
}

// Alias for backward compatibility
export type Step1Response = Step1Result;

export interface LoginResult {
  token: string;
  user_id: number;
  nome: string;
  login: string;
  level: number;
  level_label: string;
  base_code: string;
  role: string;
  permissions: string;
}

// Alias for backward compatibility
export type LoginResponse = LoginResult;

// ========== Base ==========

export interface Base {
  id: number;
  code: string;
  nome: string;
  is_active: boolean;
  created_at?: string;
}

// ========== Cidade (re-export for convenience) ==========

export interface Cidade {
  id: number;
  nome: string;
  uf?: string;
  regiao?: string;
  base_code?: string;
}

// ========== Pacote ==========

export interface Pacote {
  id: number;
  tbr: string;
  status?: string;
  cidade_id?: number;
  rota_id?: number;
  base_code?: string;
}

// ========== Ticket ==========

export type TicketMotivo =
  | 'Danificado'
  | '3a_tentativa'
  | 'Recusado_cliente'
  | 'Recusado_entregador'
  | 'Endereco_nao_encontrado';

export type TicketStatus = 'ABERTO' | 'EM_ANDAMENTO' | 'RESOLVIDO' | 'FECHADO';

export interface Ticket {
  id: number;
  tbr: string;
  motivo: string;
  base_code: string;
  created_by: string;
  status: TicketStatus;
  created_at?: string;
}

// ========== Online User ==========

export interface OnlineUser {
  user_id: number;
  nome: string;
  login: string;
  level: number;
  level_label: string;
  base_code: string;
  role: string;
  active_since: string;
  last_activity: string;
}

// ========== Constants ==========

export const LEVEL_MAP: Record<number, string> = {
  100: 'Admin Master',
  80: 'Super Usuário',
  60: 'Gerente de Base',
  40: 'Auxiliar',
  30: 'Motorista',
  20: 'Entregador',
};

// Alias
export const LEVEL_LABELS = LEVEL_MAP;

export const LEVEL_COLORS: Record<number, string> = {
  100: 'text-red-400 bg-red-900/30 border-red-700',
  80: 'text-orange-400 bg-orange-900/30 border-orange-700',
  60: 'text-yellow-400 bg-yellow-900/30 border-yellow-700',
  40: 'text-blue-400 bg-blue-900/30 border-blue-700',
  30: 'text-emerald-400 bg-emerald-900/30 border-emerald-700',
  20: 'text-slate-400 bg-slate-900/30 border-slate-700',
};

export const ROLE_ICONS: Record<string, string> = {
  ADMINISTRADOR: '🛡️',
  GESTOR: '📋',
  AUXILIAR: '📦',
  MOTORISTA: '🚛',
  ENTREGADOR: '🏍️',
};

export const USER_LEVELS = [
  { value: 100, label: 'Admin Master' },
  { value: 80, label: 'Super Usuário' },
  { value: 60, label: 'Gerente de Base' },
  { value: 40, label: 'Auxiliar' },
  { value: 30, label: 'Motorista' },
  { value: 20, label: 'Entregador' },
];

export const TICKET_STATUSES: TicketStatus[] = ['ABERTO', 'EM_ANDAMENTO', 'RESOLVIDO', 'FECHADO'];

export const RETURN_REASONS: TicketMotivo[] = [
  'Danificado',
  '3a_tentativa',
  'Recusado_cliente',
  'Recusado_entregador',
  'Endereco_nao_encontrado',
];

// ========== Helpers ==========

export function getLevelLabel(level: number): string {
  return LEVEL_MAP[level] || `Nível ${level}`;
}

export function getLevelColor(level: number): string {
  if (level >= 100) return 'text-red-400';
  if (level >= 80) return 'text-orange-400';
  if (level >= 60) return 'text-yellow-400';
  if (level >= 40) return 'text-blue-400';
  if (level >= 30) return 'text-emerald-400';
  return 'text-slate-400';
}