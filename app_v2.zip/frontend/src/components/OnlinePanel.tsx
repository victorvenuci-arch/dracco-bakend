import { useState, useEffect, useCallback } from 'react';
import { Wifi, X, Users } from 'lucide-react';
import { cn } from '@/lib/utils';
import { getOnlineUsers } from '@/lib/dracco-api';
import { LEVEL_COLORS } from '@/lib/dracco-types';
import type { OnlineUser } from '@/lib/dracco-types';

interface OnlinePanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function OnlinePanel({ isOpen, onClose }: OnlinePanelProps) {
  const [users, setUsers] = useState<OnlineUser[]>([]);
  const [loading, setLoading] = useState(false);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getOnlineUsers();
      setUsers(data);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (isOpen) {
      refresh();
      const interval = setInterval(refresh, 30_000);
      return () => clearInterval(interval);
    }
  }, [isOpen, refresh]);

  const getActiveTime = (since: string) => {
    try {
      const diff = Date.now() - new Date(since).getTime();
      const mins = Math.floor(diff / 60000);
      if (mins < 1) return 'agora';
      if (mins < 60) return `${mins}min`;
      const hrs = Math.floor(mins / 60);
      return `${hrs}h ${mins % 60}min`;
    } catch {
      return '—';
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed right-0 top-0 h-full w-80 bg-[#0F172A] border-l border-white/10 z-50 shadow-2xl flex flex-col">
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
        <div className="flex items-center gap-2">
          <Wifi className="w-4 h-4 text-emerald-400" />
          <span className="text-sm font-bold text-white">Online</span>
          <span className="text-xs bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full font-semibold">
            {users.length}
          </span>
        </div>
        <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-all">
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {users.length === 0 && !loading && (
          <div className="text-center py-8">
            <Users className="w-8 h-8 text-slate-600 mx-auto mb-2" />
            <p className="text-xs text-slate-500">Nenhum usuário online</p>
          </div>
        )}
        {users.map((u) => {
          const colors = LEVEL_COLORS[u.level] || LEVEL_COLORS[20];
          return (
            <div key={`${u.user_id}-${u.role}`} className="bg-white/5 border border-white/5 rounded-xl p-3">
              <div className="flex items-center gap-2 mb-1">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-sm font-semibold text-white truncate">{u.nome}</span>
              </div>
              <div className="flex items-center gap-2 text-[10px]">
                <span className={cn('px-1.5 py-0.5 rounded-full font-semibold', colors.bg, colors.text)}>
                  {u.level_label}
                </span>
                <span className="text-slate-500">Base {u.base_code}</span>
              </div>
              <div className="flex items-center justify-between mt-1.5">
                <span className="text-[10px] text-slate-500">Função: {u.role}</span>
                <span className="text-[10px] text-emerald-400">{getActiveTime(u.active_since)}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}