import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { transfers, statusLabels, statusColors, type TransferStatus } from '@/lib/data';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import {
  Search,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  Filter,
  Package,
  MapPin,
  Calendar,
} from 'lucide-react';

const filterStatuses: (TransferStatus | 'all')[] = [
  'all',
  'pendiente',
  'en_transito',
  'en_centro',
  'en_camino',
  'entregado',
  'cancelado',
];

const filterLabels: Record<string, string> = {
  all: 'Todos',
  ...statusLabels,
};

type SortField = 'createdAt' | 'trackingNumber' | 'origin' | 'destination' | 'status';
type SortDirection = 'asc' | 'desc';

export default function TransferTable() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<TransferStatus | 'all'>('all');
  const [sortField, setSortField] = useState<SortField>('createdAt');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');

  const filteredTransfers = useMemo(() => {
    let result = [...transfers];

    // Filter by status
    if (statusFilter !== 'all') {
      result = result.filter((t) => t.status === statusFilter);
    }

    // Filter by search
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(
        (t) =>
          t.trackingNumber.toLowerCase().includes(q) ||
          t.origin.toLowerCase().includes(q) ||
          t.destination.toLowerCase().includes(q) ||
          t.products.some((p) => p.name.toLowerCase().includes(q))
      );
    }

    // Sort
    result.sort((a, b) => {
      let valA: string = '';
      let valB: string = '';
      if (sortField === 'createdAt') {
        valA = a.createdAt;
        valB = b.createdAt;
      } else if (sortField === 'trackingNumber') {
        valA = a.trackingNumber;
        valB = b.trackingNumber;
      } else if (sortField === 'origin') {
        valA = a.origin;
        valB = b.origin;
      } else if (sortField === 'destination') {
        valA = a.destination;
        valB = b.destination;
      } else if (sortField === 'status') {
        valA = a.status;
        valB = b.status;
      }
      const cmp = valA.localeCompare(valB);
      return sortDirection === 'asc' ? cmp : -cmp;
    });

    return result;
  }, [search, statusFilter, sortField, sortDirection]);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection((d) => (d === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />;
    return sortDirection === 'asc' ? (
      <ArrowUp className="w-3.5 h-3.5 text-blue-500" />
    ) : (
      <ArrowDown className="w-3.5 h-3.5 text-blue-500" />
    );
  };

  return (
    <div className="space-y-4">
      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input
            placeholder="Buscar por guía, origen, destino o producto..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-white border-slate-200 focus:border-blue-400 focus:ring-blue-400/20"
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-500 flex-shrink-0" />
          <div className="flex gap-1.5 flex-wrap">
            {filterStatuses.map((s) => (
              <Button
                key={s}
                variant={statusFilter === s ? 'default' : 'outline'}
                size="sm"
                onClick={() => setStatusFilter(s)}
                className={cn(
                  'text-xs h-8 px-3 rounded-full transition-all',
                  statusFilter === s
                    ? 'bg-blue-600 text-white hover:bg-blue-700 shadow-md shadow-blue-500/20'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                )}
              >
                {filterLabels[s]}
              </Button>
            ))}
          </div>
        </div>
      </div>

      {/* Results count */}
      <p className="text-sm text-slate-500">
        {filteredTransfers.length} transferencia{filteredTransfers.length !== 1 ? 's' : ''} encontrada{filteredTransfers.length !== 1 ? 's' : ''}
      </p>

      {/* Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                {[
                  { field: 'trackingNumber' as SortField, label: '# Guía' },
                  { field: 'origin' as SortField, label: 'Origen' },
                  { field: 'destination' as SortField, label: 'Destino' },
                  { field: 'status' as SortField, label: 'Estado' },
                  { field: 'createdAt' as SortField, label: 'Fecha' },
                ].map((col) => (
                  <th
                    key={col.field}
                    className="text-left px-5 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider cursor-pointer hover:text-slate-700 transition-colors select-none"
                    onClick={() => handleSort(col.field)}
                  >
                    <div className="flex items-center gap-1.5">
                      {col.label}
                      <SortIcon field={col.field} />
                    </div>
                  </th>
                ))}
                <th className="text-left px-5 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Productos
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredTransfers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-12 text-center">
                    <Package className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                    <p className="text-sm text-slate-500">No se encontraron transferencias</p>
                    <p className="text-xs text-slate-400 mt-1">Intenta con otros filtros o términos de búsqueda</p>
                  </td>
                </tr>
              ) : (
                filteredTransfers.map((transfer) => {
                  const sc = statusColors[transfer.status];
                  return (
                    <tr
                      key={transfer.id}
                      onClick={() => navigate(`/transfer/${transfer.id}`)}
                      className="hover:bg-blue-50/50 cursor-pointer transition-colors group"
                    >
                      <td className="px-5 py-4">
                        <span className="text-sm font-semibold text-blue-600 group-hover:text-blue-700">
                          {transfer.trackingNumber}
                        </span>
                      </td>
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-2">
                          <MapPin className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                          <span className="text-sm text-slate-700">{transfer.origin}</span>
                        </div>
                      </td>
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-2">
                          <MapPin className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                          <span className="text-sm text-slate-700">{transfer.destination}</span>
                        </div>
                      </td>
                      <td className="px-5 py-4">
                        <Badge className={cn('text-xs font-semibold px-2.5 py-1 rounded-full border-0', sc.bg, sc.text)}>
                          {statusLabels[transfer.status]}
                        </Badge>
                      </td>
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                          <span className="text-sm text-slate-600">{transfer.createdAt}</span>
                        </div>
                      </td>
                      <td className="px-5 py-4">
                        <span className="text-sm text-slate-600">
                          {transfer.products.map((p) => p.name).join(', ')}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}