import { useLocation, useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard,
  ScanLine,
  PackageCheck,
  UserCog,
  LogOut,
  History,
  Shield,
  ClipboardList,
  Truck,
} from 'lucide-react';
import type { UserProfile } from '@/lib/types';

interface SidebarProps {
  profileType?: UserProfile | null;
  profileName?: string;
  onLogout?: () => void;
  onSwitchProfile?: () => void;
}

const adminNav = [
  { path: '/administrador', label: 'Painel Admin', icon: Shield },
  { path: '/historico', label: 'Histórico', icon: History },
];

const gestorNav = [
  { path: '/gestor', label: 'Painel Gestor', icon: LayoutDashboard },
  { path: '/historico', label: 'Histórico', icon: History },
];

const auxiliarNav = [
  { path: '/auxiliar', label: 'Scanner & Cadastro', icon: ClipboardList },
];

const motoristaNav = [
  { path: '/scanner', label: 'Scanner', icon: ScanLine },
];

const entregadorNav = [
  { path: '/entregador', label: 'Meus Pacotes', icon: PackageCheck },
];

export default function Sidebar({ profileType, profileName, onLogout, onSwitchProfile }: SidebarProps) {
  const location = useLocation();
  const navigate = useNavigate();

  const navItems =
    profileType === 'ADMINISTRADOR'
      ? adminNav
      : profileType === 'GESTOR'
        ? gestorNav
        : profileType === 'AUXILIAR'
          ? auxiliarNav
          : profileType === 'MOTORISTA'
            ? motoristaNav
            : profileType === 'ENTREGADOR'
              ? entregadorNav
              : gestorNav;

  const profileLabel =
    profileType === 'ADMINISTRADOR'
      ? 'Administrador'
      : profileType === 'GESTOR'
        ? 'Gestor'
        : profileType === 'AUXILIAR'
          ? 'Auxiliar'
          : profileType === 'MOTORISTA'
            ? 'Motorista'
            : profileType === 'ENTREGADOR'
              ? 'Entregador'
              : 'Visitante';

  return (
    <aside className="fixed left-0 top-0 z-40 h-screen w-64 bg-[#0F172A] text-white flex flex-col shadow-2xl">
      {/* Logo */}
      <div className="flex items-center gap-3 px-6 py-6 border-b border-white/10">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-emerald-500/25">
          <Truck className="w-5 h-5 text-white" />
        </div>
        <div>
          <h1 className="text-lg font-bold tracking-tight">DRACCO</h1>
          <p className="text-[11px] text-slate-400 -mt-0.5">Sistema Logístico</p>
        </div>
      </div>

      {/* Profile Badge */}
      <div className="px-4 pt-4 pb-2">
        <div className="bg-white/5 rounded-xl px-4 py-3 border border-white/5">
          <p className="text-xs text-slate-400">Perfil Ativo</p>
          <p className="text-sm font-semibold text-white">{profileLabel}</p>
          {profileName && <p className="text-[11px] text-slate-500 mt-0.5">{profileName}</p>}
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-1">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          const Icon = item.icon;
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={cn(
                'w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200',
                isActive
                  ? 'bg-emerald-600/20 text-emerald-400 shadow-inner'
                  : 'text-slate-400 hover:bg-white/5 hover:text-white'
              )}
            >
              <Icon className="w-5 h-5 flex-shrink-0" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Footer Actions */}
      <div className="px-3 pb-2 space-y-1">
        {onSwitchProfile && (
          <button
            onClick={onSwitchProfile}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-slate-400 hover:bg-white/5 hover:text-white transition-all"
          >
            <UserCog className="w-5 h-5 flex-shrink-0" />
            <span>Trocar Perfil</span>
          </button>
        )}
        {onLogout && (
          <button
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-red-400 hover:bg-red-500/10 hover:text-red-300 transition-all"
          >
            <LogOut className="w-5 h-5 flex-shrink-0" />
            <span>Sair</span>
          </button>
        )}
      </div>

      {/* Footer */}
      <div className="px-4 py-4 border-t border-white/10">
        <div className="flex items-center gap-3 px-2">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-emerald-400 to-cyan-500 flex items-center justify-center">
            <Truck className="w-4 h-4 text-white" />
          </div>
          <div>
            <p className="text-xs font-medium text-slate-300">DRACCO v1.0</p>
            <p className="text-[11px] text-slate-500">Admin → Gestor → Auxiliar → Motorista → Entregador</p>
          </div>
        </div>
      </div>
    </aside>
  );
}