import { cn } from '@/lib/utils';
import { type TimelineEvent, statusColors } from '@/lib/data';
import { Check, Clock, MapPin } from 'lucide-react';

interface StatusTimelineProps {
  events: TimelineEvent[];
  currentStatus: string;
}

const statusOrder = ['pendiente', 'en_transito', 'en_centro', 'en_camino', 'entregado'];

export default function StatusTimeline({ events, currentStatus }: StatusTimelineProps) {
  const currentIndex = currentStatus === 'cancelado' ? 0 : statusOrder.indexOf(currentStatus);

  return (
    <div className="relative">
      {events.map((event, index) => {
        const isCompleted = index <= currentIndex && currentStatus !== 'cancelado';
        const isCurrent = index === currentIndex && currentStatus !== 'cancelado';
        const isCancelled = currentStatus === 'cancelado';
        const isLast = index === events.length - 1;
        const sc = isCompleted ? statusColors[event.status] : { dot: 'bg-slate-300' };

        return (
          <div key={event.id} className="relative flex gap-4">
            {/* Line and Dot */}
            <div className="flex flex-col items-center">
              <div
                className={cn(
                  'w-10 h-10 rounded-full flex items-center justify-center z-10 transition-all duration-300 shadow-sm',
                  isCompleted && !isCancelled
                    ? cn(sc.dot, 'shadow-md')
                    : isCancelled && index === 0
                    ? 'bg-red-500 shadow-md'
                    : 'bg-slate-200'
                )}
              >
                {isCompleted && !isCancelled ? (
                  isCurrent ? (
                    <Clock className="w-4 h-4 text-white animate-pulse" />
                  ) : (
                    <Check className="w-4 h-4 text-white" />
                  )
                ) : (
                  <div className="w-2.5 h-2.5 rounded-full bg-slate-400" />
                )}
              </div>
              {!isLast && (
                <div
                  className={cn(
                    'w-0.5 flex-1 min-h-[60px] transition-colors',
                    isCompleted && index < currentIndex && !isCancelled
                      ? 'bg-blue-400'
                      : 'bg-slate-200'
                  )}
                />
              )}
            </div>

            {/* Content */}
            <div className={cn('pb-8 flex-1', isLast && 'pb-0')}>
              <div
                className={cn(
                  'rounded-xl p-4 transition-all',
                  isCurrent && !isCancelled
                    ? 'bg-blue-50 border border-blue-200 shadow-sm'
                    : isCompleted && !isCancelled
                    ? 'bg-white'
                    : 'bg-slate-50 opacity-60'
                )}
              >
                <div className="flex items-center justify-between mb-1">
                  <h4
                    className={cn(
                      'text-sm font-semibold',
                      isCompleted && !isCancelled ? 'text-slate-800' : 'text-slate-400'
                    )}
                  >
                    {event.label}
                  </h4>
                  {isCompleted && !isCancelled && (
                    <span className="text-xs text-slate-500">
                      {event.date} · {event.time}
                    </span>
                  )}
                </div>
                <p
                  className={cn(
                    'text-xs',
                    isCompleted && !isCancelled ? 'text-slate-600' : 'text-slate-400'
                  )}
                >
                  {event.description}
                </p>
                {isCompleted && !isCancelled && (
                  <div className="flex items-center gap-1 mt-2">
                    <MapPin className="w-3 h-3 text-slate-400" />
                    <span className="text-xs text-slate-500">{event.location}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}