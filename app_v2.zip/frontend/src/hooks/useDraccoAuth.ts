import { useState, useEffect, useCallback, useRef } from 'react';
import type { DraccoUser, Step1Result } from '@/lib/dracco-types';
import {
  loginStep1 as apiLoginStep1,
  loginStep3 as apiLoginStep3,
  validateSession,
  heartbeat as apiHeartbeat,
  logoutSession,
} from '@/lib/dracco-api';

const TOKEN_KEY = 'dracco_token';
const USER_KEY = 'dracco_user';
const HEARTBEAT_INTERVAL = 30_000; // 30s

export function useDraccoAuth() {
  const [user, setUser] = useState<DraccoUser | null>(null);
  const [loading, setLoading] = useState(true);
  const heartbeatRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Restore session on mount
  useEffect(() => {
    const restore = async () => {
      const token = localStorage.getItem(TOKEN_KEY);
      const savedUser = localStorage.getItem(USER_KEY);
      if (token && savedUser) {
        try {
          const res = await validateSession(token);
          if (res?.status === 'valid' && res.user) {
            const u = res.user as DraccoUser;
            setUser(u);
            startHeartbeat(token);
          } else {
            clearSession();
          }
        } catch {
          clearSession();
        }
      }
      setLoading(false);
    };
    restore();

    return () => {
      if (heartbeatRef.current) clearInterval(heartbeatRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const startHeartbeat = useCallback((token: string) => {
    if (heartbeatRef.current) clearInterval(heartbeatRef.current);
    heartbeatRef.current = setInterval(async () => {
      try {
        await apiHeartbeat(token);
      } catch {
        // Session expired
        clearSession();
        setUser(null);
      }
    }, HEARTBEAT_INTERVAL);
  }, []);

  const clearSession = () => {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    if (heartbeatRef.current) clearInterval(heartbeatRef.current);
  };

  const loginStep1 = useCallback(async (login: string): Promise<Step1Result> => {
    const res = await apiLoginStep1(login);
    return res as Step1Result;
  }, []);

  const loginStep3 = useCallback(
    async (login: string, role: string, senha: string): Promise<DraccoUser> => {
      const res = await apiLoginStep3(login, role, senha);
      const token = res.token as string;
      const u: DraccoUser = {
        user_id: res.user_id as number,
        nome: res.nome as string,
        login: res.login as string,
        level: res.level as number,
        level_label: res.level_label as string,
        base_code: res.base_code as string,
        role: res.role as DraccoUser['role'],
        permissions: res.permissions as string,
      };
      localStorage.setItem(TOKEN_KEY, token);
      localStorage.setItem(USER_KEY, JSON.stringify(u));
      setUser(u);
      startHeartbeat(token);
      return u;
    },
    [startHeartbeat]
  );

  const logout = useCallback(async () => {
    const token = localStorage.getItem(TOKEN_KEY);
    if (token) {
      try {
        await logoutSession(token);
      } catch {
        // ignore
      }
    }
    clearSession();
    setUser(null);
  }, []);

  const switchUser = useCallback(async () => {
    await logout();
  }, [logout]);

  const getToken = useCallback(() => {
    return localStorage.getItem(TOKEN_KEY) || '';
  }, []);

  return {
    user,
    loading,
    loginStep1,
    loginStep3,
    logout,
    switchUser,
    getToken,
  };
}