import { useState, useEffect, useCallback, useRef } from 'react';
import { client } from '@/lib/api';
import { entityDelete } from '@/lib/apiHelpers';
import type { PerfilUsuario, UserProfile } from '@/lib/types';

interface AuthUser {
  id: string;
  email: string;
  name?: string;
}

export function useProfile() {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [profile, setProfile] = useState<PerfilUsuario | null>(null);
  const [loading, setLoading] = useState(true);
  const authChecked = useRef(false);

  const checkAuth = useCallback(async () => {
    // Prevent duplicate auth checks (avoids re-fetching on every mount)
    if (authChecked.current) return;
    authChecked.current = true;

    try {
      setLoading(true);
      const res = await client.auth.me();
      if (res?.data?.id) {
        setUser(res.data as AuthUser);
        const profileRes = await client.entities.perfis_usuarios.query({ query: {} });
        const items = profileRes?.data?.items || [];
        if (items.length > 0) {
          setProfile(items[0] as PerfilUsuario);
        } else {
          setProfile(null);
        }
      } else {
        setUser(null);
        setProfile(null);
      }
    } catch {
      setUser(null);
      setProfile(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    checkAuth();
  }, [checkAuth]);

  const login = async () => {
    await client.auth.toLogin();
  };

  const logout = async () => {
    await client.auth.logout();
    setUser(null);
    setProfile(null);
  };

  const selectProfile = async (
    nome: string,
    perfil: UserProfile,
    cidadeId?: number,
    cidadeNome?: string
  ) => {
    if (!user) return;
    // Delete old profile in background (don't block UI)
    if (profile) {
      const oldId = profile.id;
      entityDelete('perfis_usuarios', oldId).catch(() => {});
    }
    const res = await client.entities.perfis_usuarios.create({
      data: {
        nome,
        perfil,
        cidade_vinculada_id: cidadeId || 0,
        cidade_vinculada_nome: cidadeNome || '',
        ativo: true,
      },
    });
    if (res?.data) {
      setProfile(res.data as PerfilUsuario);
    }
  };

  const clearProfile = async () => {
    // Immediately clear profile state for instant UI response
    const oldProfile = profile;
    setProfile(null);

    // Delete old profile in background (don't block navigation)
    if (oldProfile) {
      entityDelete('perfis_usuarios', oldProfile.id).catch(() => {});
    }

    // Allow re-checking auth on next mount
    authChecked.current = false;
  };

  return { user, profile, loading, login, logout, selectProfile, clearProfile, refetch: checkAuth };
}