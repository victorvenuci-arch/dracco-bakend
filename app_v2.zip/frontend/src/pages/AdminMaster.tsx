import { useState, useEffect, useCallback } from 'react';
import { cn } from '@/lib/utils';
import { client } from '@/lib/api';
import { toast } from 'sonner';
import { listUsers, createUser, updateUser, listTickets, updateTicket, getOnlineUsers } from '@/lib/dracco-api';
import { LEVEL_LABELS, LEVEL_COLORS, TICKET_STATUSES, USER_LEVELS } from '@/lib/dracco-types';
import type { DraccoUserFull, Ticket, OnlineUser, LoginResponse, Base, Cidade, Pacote } from '@/lib/dracco-types';
import type { Cidade as CidadeType } from '@/lib/types';
import { entityUpdate, entityDelete } from '@/lib/apiHelpers';
import { regioesceara } from '@/lib/regions';
import {
  Shield, Users, MapPin, Loader2, RefreshCw, Truck, Plus, Trash2, Save, Globe,
  CheckSquare, Wifi, AlertTriangle, Eye, EyeOff, UserPlus, TicketIcon, Building2,
} from 'lucide-react';

type AdminTab = 'usuarios' | 'bases' | 'online' | 'cidades' | 'regioes' | 'tickets';

interface AdminMasterProps {
  currentUser: LoginResponse;
  onLogout: () => void;
  onSwitchUser: () => void;
}

export default function AdminMasterPage({ currentUser, onLogout, onSwitchUser }: AdminMasterProps) {
  const [activeTab, setActiveTab] = useState<AdminTab>('usuarios');
  const [loadingData, setLoadingData] = useState(false);

  // Users
  const [users, setUsers] = useState<DraccoUserFull[]>([]);
  const [showCreateUser, setShowCreateUser] = useState(false);
  const [newUser, setNewUser] = useState({ nome: '', login: '', senha: '', level: 60, base_code: 'SJN9', veiculo_tipo: '', login_amazon: '' });
  const [savingUser, setSavingUser] = useState(false);

  // Bases
  const [bases, setBases] = useState<Base[]>([]);

  // Online
  const [onlineUsers, setOnlineUsers] = useState<OnlineUser[]>([]);

  // Cidades
  const [cidades, setCidades] = useState<CidadeType[]>([]);
  const [newCidadeNome, setNewCidadeNome] = useState('');
  const [addingCity, setAddingCity] = useState(false);
  const [selectedRegionCities, setSelectedRegionCities] = useState<string[]>([]);
  const [addingRegion, setAddingRegion] = useState(false);
  const [selectedCidade, setSelectedCidade] = useState<CidadeType | null>(null);
  const [cidadePacotes, setCidadePacotes] = useState<any[]>([]);

  // Tickets
  const [tickets, setTickets] = useState<Ticket[]>([]);

  const loadData = useCallback(async () => {
    setLoadingData(true);
    try {
      const [usersData, cidadesRes, ticketsData, basesRes] = await Promise.all([
        listUsers(),
        client.entities.cidades.query({ query: {}, limit: 200 }),
        listTickets(),
        client.entities.bases.query({ query: {}, limit: 50 }),
      ]);
      setUsers(usersData);
      setCidades((cidadesRes?.data?.items || []) as CidadeType[]);
      setTickets(ticketsData);
      setBases((basesRes?.data?.items || []) as Base[]);
    } catch {
      // ignore
    } finally {
      setLoadingData(false);
    }
  }, []);

  const loadOnline = useCallback(async () => {
    try {
      const data = await getOnlineUsers();
      setOnlineUsers(data);
    } catch { /* ignore */ }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  useEffect(() => {
    if (activeTab === 'online') {
      loadOnline();
      const interval = setInterval(loadOnline, 30_000);
      return () => clearInterval(interval);
    }
  }, [activeTab, loadOnline]);

  const handleCreateUser = async () => {
    if (!newUser.nome.trim() || !newUser.login.trim() || !newUser.senha.trim()) return;
    setSavingUser(true);
    try {
      await createUser({
        nome: newUser.nome.trim(),
        login: newUser.login.trim(),
        senha: newUser.senha,
        level: newUser.level,
        base_code: newUser.base_code,
        veiculo_tipo: newUser.veiculo_tipo,
        login_amazon: newUser.login_amazon,
      });
      toast.success(`Usuário "${newUser.nome}" criado`);
      setNewUser({ nome: '', login: '', senha: '', level: 60, base_code: 'SJN9', veiculo_tipo: '', login_amazon: '' });
      setShowCreateUser(false);
      await loadData();
    } catch (err: any) {
      const detail = err?.data?.detail || err?.response?.data?.detail || err?.message || 'Erro ao criar usuário';
      toast.error(detail);
    } finally {
      setSavingUser(false);
    }
  };

  const handleToggleActive = async (u: DraccoUserFull) => {
    try {
      await updateUser({ user_id: u.id, is_active: !u.is_active });
      toast.success(`Usuário "${u.nome}" ${!u.is_active ? 'ativado' : 'desativado'}`);
      await loadData();
    } catch (err: any) {
      toast.error(err?.data?.detail || 'Erro ao atualizar');
    }
  };

  const handleAddCity = async () => {
    if (!newCidadeNome.trim()) return;
    if (cidades.some((c) => c.nome.toLowerCase() === newCidadeNome.trim().toLowerCase())) {
      toast.error('Cidade já cadastrada!');
      return;
    }
    setAddingCity(true);
    try {
      await client.entities.cidades.create({
        data: { nome: newCidadeNome.trim(), entregador_padrao_id: '', entregador_padrao_nome: '', motorista_id: '', motorista_nome: '', veiculo_tipo: '', status: 'AGUARDANDO_DESPACHO', created_at: new Date().toISOString() },
      });
      toast.success(`Cidade "${newCidadeNome}" adicionada`);
      setNewCidadeNome('');
      await loadData();
    } catch { toast.error('Erro ao adicionar cidade'); }
    finally { setAddingCity(false); }
  };

  const handleRemoveCity = async (id: number, nome: string) => {
    if (!confirm(`Remover cidade "${nome}"?`)) return;
    try {
      await entityDelete('cidades', id);
      toast.success(`Cidade "${nome}" removida`);
      await loadData();
    } catch { toast.error('Erro ao remover'); }
  };

  const handleCidadeClick = async (c: CidadeType) => {
    setSelectedCidade(c);
    try {
      const res = await client.entities.pacotes.query({ query: { cidade_id: c.id }, limit: 500 });
      setCidadePacotes(res?.data?.items || []);
    } catch { setCidadePacotes([]); }
  };

  const toggleRegionCity = (city: string) => {
    setSelectedRegionCities((prev) => prev.includes(city) ? prev.filter((c) => c !== city) : [...prev, city]);
  };

  const handleImportRegionCities = async () => {
    if (selectedRegionCities.length === 0) return;
    setAddingRegion(true);
    let created = 0;
    for (const cityName of selectedRegionCities) {
      if (cidades.some((c) => c.nome.toLowerCase() === cityName.toLowerCase())) continue;
      try {
        await client.entities.cidades.create({
          data: { nome: cityName, entregador_padrao_id: '', entregador_padrao_nome: '', motorista_id: '', motorista_nome: '', veiculo_tipo: '', status: 'AGUARDANDO_DESPACHO', created_at: new Date().toISOString() },
        });
        created++;
      } catch { /* skip */ }
    }
    toast.success(`${created} cidades importadas`);
    setSelectedRegionCities([]);
    setAddingRegion(false);
    await loadData();
  };

  const handleTicketStatusChange = async (ticketId: number, status: string) => {
    try {
      await updateTicket(ticketId, status);
      toast.success('Ticket atualizado');
      await loadData();
    } catch { toast.error('Erro ao atualizar ticket'); }
  };

  const existingCityNames = cidades.map((c) => c.nome.toLowerCase());

  const tabs: { key: AdminTab; label: string; icon: typeof Shield }[] = [
    { key: 'usuarios', label: 'Usuários', icon: Users },
    { key: 'bases', label: 'Bases', icon: Building2 },
    { key: 'online', label: 'Online', icon: Wifi },
    { key: 'cidades', label: 'Cidades', icon: MapPin },
    { key: 'regioes', label: 'Regiões CE', icon: Globe },
    { key: 'tickets', label: 'Chamados', icon: TicketIcon },
  ];

  const getActiveTime = (since: string) => {
    try {
      const diff = Date.now() - new Date(since).getTime();
      const mins = Math.floor(diff / 60000);
      if (mins < 1) return 'agora';
      if (mins < 60) return `${mins}min`;
      return `${Math.floor(mins / 60)}h ${mins % 60}min`;
    } catch { return '—'; }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#0F172A] to-[#1E293B] px-4 sm:px-8 py-4 sm:py-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg sm:text-2xl font-bold text-white">Admin Master</h1>
              <p className="text-slate-400 text-xs">{currentUser.nome} · Base {currentUser.base_code}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={loadData} disabled={loadingData} className="flex items-center gap-1 px-3 py-2 rounded-xl bg-white/10 text-white text-xs hover:bg-white/20">
              <RefreshCw className={cn('w-3.5 h-3.5', loadingData && 'animate-spin')} /> Atualizar
            </button>
            <button onClick={onSwitchUser} className="px-3 py-2 rounded-xl bg-white/10 text-slate-300 text-xs hover:bg-white/20">Trocar</button>
            <button onClick={onLogout} className="px-3 py-2 rounded-xl bg-red-500/20 text-red-300 text-xs hover:bg-red-500/30">Sair</button>
          </div>
        </div>
        <div className="flex gap-1 bg-white/5 rounded-xl p-1 overflow-x-auto">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button key={tab.key} onClick={() => setActiveTab(tab.key)}
                className={cn('flex-1 flex items-center justify-center gap-1.5 px-2 py-2.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap',
                  activeTab === tab.key ? 'bg-white/15 text-white shadow-sm' : 'text-slate-400 hover:text-white hover:bg-white/5')}>
                <Icon className="w-3.5 h-3.5" /><span className="hidden sm:inline">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="px-4 sm:px-8 py-6">
        {/* USUARIOS TAB */}
        {activeTab === 'usuarios' && (
          <div className="max-w-3xl">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-slate-800">Usuários ({users.length})</h2>
              <button onClick={() => setShowCreateUser(!showCreateUser)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 text-white text-sm font-bold hover:bg-emerald-700">
                <UserPlus className="w-4 h-4" /> Novo Usuário
              </button>
            </div>

            {showCreateUser && (
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 mb-6">
                <h3 className="text-sm font-semibold text-slate-800 mb-4">Criar Usuário</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
                  <input type="text" placeholder="Nome" value={newUser.nome} onChange={(e) => setNewUser({ ...newUser, nome: e.target.value })}
                    className="px-3 py-2.5 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50" />
                  <input type="text" placeholder="Login" value={newUser.login} onChange={(e) => setNewUser({ ...newUser, login: e.target.value })}
                    className="px-3 py-2.5 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50" />
                  <input type="password" placeholder="Senha" value={newUser.senha} onChange={(e) => setNewUser({ ...newUser, senha: e.target.value })}
                    className="px-3 py-2.5 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50" />
                  <select value={newUser.level} onChange={(e) => setNewUser({ ...newUser, level: Number(e.target.value) })}
                    className="px-3 py-2.5 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50">
                    <option value={80}>Super Usuário (80)</option>
                    <option value={60}>Gerente de Base (60)</option>
                    <option value={40}>Auxiliar (40)</option>
                    <option value={30}>Motorista (30)</option>
                    <option value={20}>Entregador (20)</option>
                  </select>
                  <select value={newUser.base_code} onChange={(e) => setNewUser({ ...newUser, base_code: e.target.value })}
                    className="px-3 py-2.5 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50">
                    {bases.map((b) => <option key={b.code || b.id} value={b.code}>{b.code} — {b.nome}</option>)}
                    {bases.length === 0 && <><option value="SJN9">SJN9 — Base Mãe</option><option value="PIG1">PIG1 — Iguatu</option></>}
                  </select>
                  {newUser.level === 30 && (
                    <>
                      <input type="text" placeholder="Tipo Veículo" value={newUser.veiculo_tipo} onChange={(e) => setNewUser({ ...newUser, veiculo_tipo: e.target.value })}
                        className="px-3 py-2.5 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50" />
                      <input type="text" placeholder="Login Amazon" value={newUser.login_amazon} onChange={(e) => setNewUser({ ...newUser, login_amazon: e.target.value })}
                        className="px-3 py-2.5 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50" />
                    </>
                  )}
                </div>
                <button onClick={handleCreateUser} disabled={savingUser || !newUser.nome.trim() || !newUser.login.trim() || !newUser.senha.trim()}
                  className={cn('w-full py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all',
                    newUser.nome.trim() && newUser.login.trim() && newUser.senha.trim() && !savingUser
                      ? 'bg-emerald-600 text-white hover:bg-emerald-700' : 'bg-slate-100 text-slate-400 cursor-not-allowed')}>
                  {savingUser ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                  {savingUser ? 'Criando...' : 'Criar Usuário'}
                </button>
              </div>
            )}

            <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
              <div className="space-y-2 max-h-[500px] overflow-y-auto">
                {users.map((u) => {
                  const colors = LEVEL_COLORS[u.level] || LEVEL_COLORS[20];
                  return (
                    <div key={u.id} className="flex items-center justify-between py-3 px-4 rounded-lg bg-slate-50">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-medium text-slate-800 truncate">{u.nome}</p>
                          {u.is_online && <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />}
                        </div>
                        <p className="text-xs text-slate-500">
                          @{u.login} · {u.level_label} · Base {u.base_code}
                          {u.veiculo_tipo ? ` · ${u.veiculo_tipo}` : ''}
                        </p>
                      </div>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        <button onClick={() => handleToggleActive(u)}
                          className={cn('text-xs font-semibold px-2 py-1 rounded-full cursor-pointer transition-colors',
                            u.is_active ? 'bg-green-100 text-green-700 hover:bg-green-200' : 'bg-red-100 text-red-700 hover:bg-red-200')}>
                          {u.is_active ? 'Ativo' : 'Inativo'}
                        </button>
                      </div>
                    </div>
                  );
                })}
                {users.length === 0 && <p className="text-sm text-slate-500 text-center py-4">Nenhum usuário</p>}
              </div>
            </div>
          </div>
        )}

        {/* BASES TAB */}
        {activeTab === 'bases' && (
          <div className="max-w-2xl">
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
              <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                <Building2 className="w-5 h-5 text-blue-500" /> Bases Operacionais
              </h2>
              <div className="space-y-3">
                {bases.map((b) => (
                  <div key={b.id} className="flex items-center justify-between py-3 px-4 rounded-lg bg-slate-50">
                    <div>
                      <p className="text-sm font-bold text-slate-800">{b.code}</p>
                      <p className="text-xs text-slate-500">{b.nome}</p>
                    </div>
                    <span className={cn('text-xs font-semibold px-2 py-1 rounded-full', b.is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700')}>
                      {b.is_active ? 'Ativa' : 'Inativa'}
                    </span>
                  </div>
                ))}
                {bases.length === 0 && (
                  <div className="text-center py-4">
                    <p className="text-sm text-slate-500">Bases SJN9 e PIG1 serão criadas automaticamente</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ONLINE TAB */}
        {activeTab === 'online' && (
          <div className="max-w-2xl">
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
              <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                <Wifi className="w-5 h-5 text-emerald-500" /> Usuários Online ({onlineUsers.length})
              </h2>
              <div className="space-y-2">
                {onlineUsers.map((u) => {
                  const colors = LEVEL_COLORS[u.level] || LEVEL_COLORS[20];
                  return (
                    <div key={`${u.user_id}-${u.role}`} className="flex items-center justify-between py-3 px-4 rounded-lg bg-slate-50">
                      <div className="flex items-center gap-3">
                        <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                        <div>
                          <p className="text-sm font-medium text-slate-800">{u.nome}</p>
                          <p className="text-xs text-slate-500">{u.level_label} · Base {u.base_code} · {u.role}</p>
                        </div>
                      </div>
                      <span className="text-xs text-emerald-600 font-semibold">{getActiveTime(u.active_since)}</span>
                    </div>
                  );
                })}
                {onlineUsers.length === 0 && <p className="text-sm text-slate-500 text-center py-4">Nenhum usuário online</p>}
              </div>
            </div>
          </div>
        )}

        {/* CIDADES TAB */}
        {activeTab === 'cidades' && (
          <div className="max-w-2xl">
            {selectedCidade ? (
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
                <button onClick={() => setSelectedCidade(null)} className="text-sm text-blue-600 hover:text-blue-700 mb-4">← Voltar</button>
                <h2 className="text-lg font-semibold text-slate-800 mb-2">{selectedCidade.nome}</h2>
                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="bg-slate-50 rounded-lg p-3"><p className="text-xs text-slate-500">Status</p><p className="text-sm font-bold">{selectedCidade.status}</p></div>
                  <div className="bg-slate-50 rounded-lg p-3"><p className="text-xs text-slate-500">Motorista</p><p className="text-sm font-bold">{selectedCidade.motorista_nome || '—'}</p></div>
                  <div className="bg-slate-50 rounded-lg p-3"><p className="text-xs text-slate-500">Entregador</p><p className="text-sm font-bold">{selectedCidade.entregador_padrao_nome || '—'}</p></div>
                  <div className="bg-slate-50 rounded-lg p-3"><p className="text-xs text-slate-500">Pacotes</p><p className="text-sm font-bold">{cidadePacotes.length}</p></div>
                </div>
                <h3 className="text-sm font-semibold text-slate-700 mb-2">TBRs ({cidadePacotes.length})</h3>
                <div className="max-h-64 overflow-y-auto space-y-1">
                  {cidadePacotes.map((p: any) => (
                    <div key={p.id} className="flex items-center justify-between py-2 px-3 rounded-lg bg-slate-50 text-xs">
                      <span className="font-mono">{p.codigo_rastreio}</span>
                      <span className={cn('px-2 py-0.5 rounded-full font-semibold', p.status === 'BIPADO' ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-600')}>{p.status}</span>
                    </div>
                  ))}
                  {cidadePacotes.length === 0 && <p className="text-xs text-slate-500 text-center py-4">Nenhum pacote</p>}
                </div>
              </div>
            ) : (
              <>
                <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 mb-6">
                  <h2 className="text-lg font-semibold text-slate-800 mb-4">Adicionar Cidade</h2>
                  <div className="flex gap-3">
                    <input type="text" value={newCidadeNome} onChange={(e) => setNewCidadeNome(e.target.value)} placeholder="Nome da cidade..."
                      className="flex-1 px-4 py-2.5 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50" />
                    <button onClick={handleAddCity} disabled={addingCity || !newCidadeNome.trim()}
                      className={cn('px-6 py-2.5 rounded-lg font-bold text-sm flex items-center gap-2 transition-all',
                        newCidadeNome.trim() && !addingCity ? 'bg-emerald-600 text-white hover:bg-emerald-700' : 'bg-slate-100 text-slate-400 cursor-not-allowed')}>
                      {addingCity ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />} Adicionar
                    </button>
                  </div>
                </div>
                <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
                  <h3 className="text-sm font-semibold text-slate-700 mb-3">Cidades ({cidades.length})</h3>
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {cidades.map((c) => (
                      <div key={c.id} className="flex items-center justify-between py-3 px-4 rounded-lg bg-slate-50 cursor-pointer hover:bg-slate-100" onClick={() => handleCidadeClick(c)}>
                        <div><p className="text-sm font-medium text-slate-800">{c.nome}</p><p className="text-xs text-slate-500">Status: {c.status}</p></div>
                        <div className="flex items-center gap-2">
                          <Eye className="w-4 h-4 text-slate-400" />
                          <button onClick={(e) => { e.stopPropagation(); handleRemoveCity(c.id, c.nome); }} className="p-2 rounded-lg text-red-500 hover:bg-red-50"><Trash2 className="w-4 h-4" /></button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>
        )}

        {/* REGIOES TAB */}
        {activeTab === 'regioes' && (
          <div className="max-w-2xl">
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
              <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                <Globe className="w-5 h-5 text-green-500" /> Seletor Regional — Ceará
              </h2>
              {regioesceara.map((region) => (
                <div key={region.name} className="mb-6">
                  <h3 className="text-sm font-bold text-slate-700 mb-2">Região {region.name}</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                    {region.cities.map((city) => {
                      const exists = existingCityNames.includes(city.toLowerCase());
                      const selected = selectedRegionCities.includes(city);
                      return (
                        <button key={city} onClick={() => !exists && toggleRegionCity(city)} disabled={exists}
                          className={cn('flex items-center gap-2 py-2 px-3 rounded-lg border text-xs font-medium transition-all text-left',
                            exists ? 'bg-green-50 border-green-200 text-green-600 cursor-not-allowed'
                              : selected ? 'bg-emerald-50 border-emerald-300 text-emerald-700' : 'bg-slate-50 border-slate-200 text-slate-700 hover:border-slate-300')}>
                          <div className={cn('w-4 h-4 rounded border-2 flex items-center justify-center flex-shrink-0',
                            exists ? 'bg-green-500 border-green-500' : selected ? 'bg-emerald-500 border-emerald-500' : 'border-slate-300')}>
                            {(exists || selected) && <CheckSquare className="w-3 h-3 text-white" />}
                          </div>
                          <span className="truncate">{city}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
              <button onClick={handleImportRegionCities} disabled={addingRegion || selectedRegionCities.length === 0}
                className={cn('w-full py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all',
                  selectedRegionCities.length > 0 && !addingRegion ? 'bg-emerald-600 text-white hover:bg-emerald-700' : 'bg-slate-100 text-slate-400 cursor-not-allowed')}>
                {addingRegion ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                Importar {selectedRegionCities.length} Cidade(s)
              </button>
            </div>
          </div>
        )}

        {/* TICKETS TAB */}
        {activeTab === 'tickets' && (
          <div className="max-w-3xl">
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
              <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-500" /> Chamados ({tickets.length})
              </h2>
              <div className="space-y-2 max-h-[500px] overflow-y-auto">
                {tickets.map((t) => (
                  <div key={t.id} className="flex items-center justify-between py-3 px-4 rounded-lg bg-slate-50">
                    <div>
                      <p className="text-sm font-medium text-slate-800">TBR: <span className="font-mono">{t.tbr}</span></p>
                      <p className="text-xs text-slate-500">{t.motivo} · Base {t.base_code} · Por {t.created_by}</p>
                    </div>
                    <select value={t.status} onChange={(e) => handleTicketStatusChange(t.id, e.target.value)}
                      className="text-xs px-2 py-1 rounded-lg border border-slate-200 focus:outline-none">
                      {TICKET_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                ))}
                {tickets.length === 0 && <p className="text-sm text-slate-500 text-center py-4">Nenhum chamado</p>}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}