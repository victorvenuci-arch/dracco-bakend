import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import Sidebar from '@/components/Sidebar';
import { notifications as initialNotifications, notificationTypeConfig } from '@/lib/data';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { Bell, BellOff, Filter, CheckCheck, ExternalLink } from 'lucide-react';

const BANNER_IMG = 'https://mgx-backend-cdn.metadl.com/generate/images/980143/2026-02-20/07065f97-714c-4d62-a5e6-d19084f94e27.png';

type NotificationType = 'all' | 'status_change' | 'delay' | 'incident' | 'delivered';

const typeLabels: Record<NotificationType, string> = {
  all: 'Todas',
  status_change: 'Cambios de Estado',
  delay: 'Retrasos',
  incident: 'Incidencias',
  delivered: 'Entregas',
};

export default function NotificationsPage() {
  const navigate = useNavigate();
  const [notifs, setNotifs] = useState(initialNotifications);
  const [typeFilter, setTypeFilter] = useState<NotificationType>('all');

  const filteredNotifs = useMemo(() => {
    let result = [...notifs];
    if (typeFilter !== 'all') {
      result = result.filter((n) => n.type === typeFilter);
    }
    // Sort by date desc, unread first
    result.sort((a, b) => {
      if (a.read !== b.read) return a.read ? 1 : -1;
      return `${b.date} ${b.time}`.localeCompare(`${a.date} ${a.time}`);
    });
    return result;
  }, [notifs, typeFilter]);

  const unreadCount = notifs.filter((n) => !n.read).length;

  const markAsRead = (id: string) => {
    setNotifs((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const markAllAsRead = () => {
    setNotifs((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      <Sidebar />
      <main className="ml-64">
        {/* Banner */}
        <div className="relative h-40 overflow-hidden">
          <img src={BANNER_IMG} alt="Notifications banner" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0F172A]/90 to-[#0F172A]/60" />
          <div className="absolute inset-0 flex items-center px-8">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-sm flex items-center justify-center">
                <Bell className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">Notificaciones</h1>
                <p className="text-slate-300 text-sm">
                  {unreadCount > 0
                    ? `${unreadCount} notificación${unreadCount > 1 ? 'es' : ''} sin leer`
                    : 'Todas las notificaciones leídas'}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="px-8 py-6">
          {/* Filters */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-slate-500" />
              <div className="flex gap-1.5 flex-wrap">
                {(Object.keys(typeLabels) as NotificationType[]).map((type) => (
                  <Button
                    key={type}
                    variant={typeFilter === type ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setTypeFilter(type)}
                    className={cn(
                      'text-xs h-8 px-3 rounded-full transition-all',
                      typeFilter === type
                        ? 'bg-blue-600 text-white hover:bg-blue-700 shadow-md shadow-blue-500/20'
                        : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                    )}
                  >
                    {typeLabels[type]}
                  </Button>
                ))}
              </div>
            </div>
            {unreadCount > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={markAllAsRead}
                className="text-xs h-8 gap-1.5 text-blue-600 border-blue-200 hover:bg-blue-50"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                Marcar todas como leídas
              </Button>
            )}
          </div>

          {/* Notification List */}
          <div className="space-y-3">
            {filteredNotifs.length === 0 ? (
              <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
                <BellOff className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                <p className="text-sm text-slate-500">No hay notificaciones</p>
                <p className="text-xs text-slate-400 mt-1">
                  Las alertas sobre tus envíos aparecerán aquí
                </p>
              </div>
            ) : (
              filteredNotifs.map((notif) => {
                const config = notificationTypeConfig[notif.type];
                return (
                  <div
                    key={notif.id}
                    className={cn(
                      'bg-white rounded-xl border shadow-sm p-5 transition-all duration-200 hover:shadow-md cursor-pointer group',
                      notif.read ? 'border-slate-200' : 'border-blue-200 bg-blue-50/30'
                    )}
                    onClick={() => markAsRead(notif.id)}
                  >
                    <div className="flex items-start gap-4">
                      {/* Icon */}
                      <div
                        className={cn(
                          'w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 text-lg',
                          config.bgColor
                        )}
                      >
                        {config.icon}
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h4
                            className={cn(
                              'text-sm font-semibold',
                              notif.read ? 'text-slate-700' : 'text-slate-900'
                            )}
                          >
                            {notif.title}
                          </h4>
                          {!notif.read && (
                            <div className="w-2 h-2 rounded-full bg-blue-500 flex-shrink-0" />
                          )}
                        </div>
                        <p className="text-sm text-slate-600 mb-2">{notif.message}</p>
                        <div className="flex items-center gap-4">
                          <span className="text-xs text-slate-400">
                            {notif.date} · {notif.time}
                          </span>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              const transfer = initialNotifications.find(
                                (n) => n.id === notif.id
                              );
                              if (transfer) {
                                navigate(`/transfer/${notif.transferId}`);
                              }
                            }}
                            className="text-xs text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            Ver envío
                            <ExternalLink className="w-3 h-3" />
                          </button>
                        </div>
                      </div>

                      {/* Tracking Number */}
                      <span className="text-xs font-mono text-slate-400 bg-slate-100 px-2 py-1 rounded flex-shrink-0">
                        {notif.trackingNumber}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </main>
    </div>
  );
}