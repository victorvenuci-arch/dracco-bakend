import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import Sidebar from '@/components/Sidebar';
import { useProfile } from '@/hooks/useProfile';
import { client } from '@/lib/api';
import { cn } from '@/lib/utils';
import { regioesceara } from '@/lib/regions';
import type { Cidade, PerfilUsuario, ResumoTriagem, Rota } from '@/lib/types';
import { entityUpdate, entityDelete } from '@/lib/apiHelpers';
import { toast } from 'sonner';
import {
  Shield,
  MapPin,
  Loader2,
  RefreshCw,
  Truck,
  Plus,
  Trash2,
  Users,
  UserPlus,
  Save,
  Globe,
  CheckSquare,
  ClipboardList,
  Send,
  AlertTriangle,
} from 'lucide-react';

type AdminTab = 'cidades' | 'regioes' | 'gestores' | 'entregadores' | 'motoristas' | 'usuarios' | 'excluir';

export default function AdministradorPage() {
  const navigate = useNavigate();
  const { user, profile, loading, logout, clearProfile } = useProfile();
  const [cidades, setCidades] = useState<Cidade[]>([]);
  const [allProfiles, setAllProfiles] = useState<PerfilUsuario[]>([]);
  const [resumos, setResumos] = useState<ResumoTriagem[]>([]);
  const [rotas, setRotas] = useState<Rota[]>([]);
  const [loadingData, setLoadingData] = useState(false);
  const [activeTab, setActiveTab] = useState<AdminTab>('cidades');

  // Add city
  const [newCidadeNome, setNewCidadeNome] = useState('');
  const [addingCity, setAddingCity] = useState(false);

  // Region selector
  const [selectedRegionCities, setSelectedRegionCities] = useState<string[]>([]);
  const [addingRegion, setAddingRegion] = useState(false);

  // Gestor creation
  const [gestorNome, setGestorNome] = useState('');
  const [savingGestor, setSavingGestor] = useState(false);

  // Entregador assignment
  const [entregadorNome, setEntregadorNome] = useState('');
  const [entregadorCidade, setEntregadorCidade] = useState<number | ''>('');
  const [savingEntregador, setSavingEntregador] = useState(false);

  // Motorista
  const [motoristaNome, setMotoristaNome] = useState('');
  const [savingMotorista, setSavingMotorista] = useState(false);

  // Delete operations
  const [deletingId, setDeletingId] = useState<number | null>(null);

  const loadData = useCallback(async () => {
    setLoadingData(true);
    try {
      const [cidadesRes, profilesRes, resumosRes, rotasRes] = await Promise.all([
        client.entities.cidades.query({ query: {}, limit: 50 }),
        client.entities.perfis_usuarios.queryAll({ query: {}, limit: 200 }),
        client.entities.resumos_triagem.queryAll({ query: {}, limit: 100, sort: '-created_at' }),
        client.entities.rotas.queryAll({ query: {}, limit: 50, sort: '-created_at' }),
      ]);
      setCidades((cidadesRes?.data?.items || []) as Cidade[]);
      setAllProfiles((profilesRes?.data?.items || []) as PerfilUsuario[]);
      setResumos((resumosRes?.data?.items || []) as ResumoTriagem[]);
      setRotas((rotasRes?.data?.items || []) as Rota[]);
    } catch {
      // ignore
    } finally {
      setLoadingData(false);
    }
  }, []);

  useEffect(() => {
    if (user && profile) loadData();
  }, [user, profile, loadData]);

  useEffect(() => {
    if (!loading && user && !profile) {
      navigate('/', { replace: true });
    } else if (!loading && user && profile && profile.perfil !== 'ADMINISTRADOR') {
      navigate('/', { replace: true });
    }
  }, [loading, user, profile, navigate]);

  const handleAddCity = async () => {
    if (!newCidadeNome.trim()) return;
    // Check duplicate
    if (cidades.some((c) => c.nome.toLowerCase() === newCidadeNome.trim().toLowerCase())) {
      toast.error('Cidade já cadastrada!');
      return;
    }
    setAddingCity(true);
    try {
      await client.entities.cidades.create({
        data: {
          nome: newCidadeNome.trim(),
          entregador_padrao_id: '',
          entregador_padrao_nome: '',
          motorista_id: '',
          motorista_nome: '',
          veiculo_tipo: '',
          status: 'AGUARDANDO_DESPACHO',
          created_at: new Date().toISOString(),
        },
      });
      toast.success(`Cidade "${newCidadeNome}" adicionada`);
      setNewCidadeNome('');
      await loadData();
    } catch {
      toast.error('Erro ao adicionar cidade');
    } finally {
      setAddingCity(false);
    }
  };

  const handleRemoveCity = async (id: number, nome: string) => {
    if (!confirm(`Remover cidade "${nome}"? Isso é irreversível.`)) return;
    try {
      await entityDelete('cidades', id);
      toast.success(`Cidade "${nome}" removida`);
      await loadData();
    } catch {
      toast.error('Erro ao remover cidade');
    }
  };

  // Region import
  const toggleRegionCity = (city: string) => {
    setSelectedRegionCities((prev) =>
      prev.includes(city) ? prev.filter((c) => c !== city) : [...prev, city]
    );
  };

  const selectAllRegion = (regionName: string) => {
    const region = regioesceara.find((r) => r.name === regionName);
    if (!region) return;
    const existingNames = cidades.map((c) => c.nome.toLowerCase());
    const newCities = region.cities.filter((c) => !existingNames.includes(c.toLowerCase()));
    setSelectedRegionCities((prev) => {
      const allSelected = newCities.every((c) => prev.includes(c));
      if (allSelected) {
        return prev.filter((c) => !newCities.includes(c));
      }
      return [...new Set([...prev, ...newCities])];
    });
  };

  const handleImportRegionCities = async () => {
    if (selectedRegionCities.length === 0) return;
    setAddingRegion(true);
    let created = 0;
    let skipped = 0;
    for (const cityName of selectedRegionCities) {
      if (cidades.some((c) => c.nome.toLowerCase() === cityName.toLowerCase())) {
        skipped++;
        continue;
      }
      try {
        await client.entities.cidades.create({
          data: {
            nome: cityName,
            entregador_padrao_id: '',
            entregador_padrao_nome: '',
            motorista_id: '',
            motorista_nome: '',
            veiculo_tipo: '',
            status: 'AGUARDANDO_DESPACHO',
            created_at: new Date().toISOString(),
          },
        });
        created++;
      } catch {
        skipped++;
      }
    }
    toast.success(`${created} cidades importadas${skipped > 0 ? `, ${skipped} já existentes` : ''}`);
    setSelectedRegionCities([]);
    setAddingRegion(false);
    await loadData();
  };

  // Gestor creation
  const handleAddGestor = async () => {
    if (!gestorNome.trim()) return;
    setSavingGestor(true);
    try {
      await client.entities.perfis_usuarios.create({
        data: { nome: gestorNome.trim(), perfil: 'GESTOR', cidade_vinculada_id: 0, cidade_vinculada_nome: '', ativo: true },
      });
      toast.success(`Gestor "${gestorNome}" cadastrado`);
      setGestorNome('');
      await loadData();
    } catch {
      toast.error('Erro ao cadastrar gestor');
    } finally {
      setSavingGestor(false);
    }
  };

  const handleAssignEntregador = async () => {
    if (!entregadorNome.trim() || !entregadorCidade) return;
    setSavingEntregador(true);
    try {
      const cidadeId = Number(entregadorCidade);
      const cidade = cidades.find((c) => c.id === cidadeId);
      if (!cidade) return;
      await entityUpdate('cidades', cidadeId, {
        entregador_padrao_nome: entregadorNome.trim(),
        entregador_padrao_id: entregadorNome.trim().toLowerCase().replace(/\s+/g, '_'),
      });
      toast.success(`Entregador "${entregadorNome}" vinculado a ${cidade.nome}`);
      setEntregadorNome('');
      setEntregadorCidade('');
      await loadData();
    } catch {
      toast.error('Erro ao vincular entregador');
    } finally {
      setSavingEntregador(false);
    }
  };

  const handleRemoveEntregador = async (cidadeId: number) => {
    try {
      await entityUpdate('cidades', cidadeId, {
        entregador_padrao_nome: '',
        entregador_padrao_id: '',
      });
      toast.success('Entregador removido');
      await loadData();
    } catch {
      toast.error('Erro ao remover entregador');
    }
  };

  const handleAddMotorista = async () => {
    if (!motoristaNome.trim()) return;
    setSavingMotorista(true);
    try {
      await client.entities.perfis_usuarios.create({
        data: { nome: motoristaNome.trim(), perfil: 'MOTORISTA', cidade_vinculada_id: 0, cidade_vinculada_nome: '', ativo: true },
      });
      toast.success(`Motorista "${motoristaNome}" cadastrado`);
      setMotoristaNome('');
      await loadData();
    } catch {
      toast.error('Erro ao cadastrar motorista');
    } finally {
      setSavingMotorista(false);
    }
  };

  const handleToggleUserActive = async (p: PerfilUsuario) => {
    try {
      await entityUpdate('perfis_usuarios', p.id, { ativo: !p.ativo });
      toast.success(`Usuário "${p.nome}" ${!p.ativo ? 'ativado' : 'desativado'}`);
      await loadData();
    } catch {
      toast.error('Erro ao atualizar usuário');
    }
  };

  const handleDeleteUser = async (p: PerfilUsuario) => {
    if (!confirm(`EXCLUIR usuário "${p.nome}" (${p.perfil})? Isso é irreversível.`)) return;
    setDeletingId(p.id);
    try {
      await entityDelete('perfis_usuarios', p.id);
      toast.success(`Usuário "${p.nome}" excluído`);
      await loadData();
    } catch {
      toast.error('Erro ao excluir usuário');
    } finally {
      setDeletingId(null);
    }
  };

  const handleDeleteTriagem = async (r: ResumoTriagem) => {
    if (!confirm(`EXCLUIR triagem de "${r.cidade_nome}" (${r.quantidade_pacotes} pacotes)? Pacotes AGUARDANDO_DESPACHO serão removidos.`)) return;
    setDeletingId(r.id);
    try {
      // Delete associated pacotes with AGUARDANDO_DESPACHO status
      const pacotesRes = await client.entities.pacotes.query({
        query: { cidade_id: r.cidade_id, status: 'AGUARDANDO_DESPACHO' },
        limit: 500,
      });
      const pkgs = (pacotesRes?.data?.items || []) as { id: number }[];
      for (const pkg of pkgs) {
        try {
          await entityDelete('pacotes', pkg.id);
        } catch {
          // ignore individual delete errors
        }
      }
      await entityDelete('resumos_triagem', r.id);
      toast.success(`Triagem de "${r.cidade_nome}" excluída com ${pkgs.length} pacotes`);
      await loadData();
    } catch {
      toast.error('Erro ao excluir triagem');
    } finally {
      setDeletingId(null);
    }
  };

  const handleDeleteRota = async (r: Rota) => {
    if (!confirm(`EXCLUIR rota de "${r.motorista_nome}" (${r.cidades_nomes})? Cidades voltarão para AGUARDANDO_DESPACHO.`)) return;
    setDeletingId(r.id);
    try {
      // Reset cities to AGUARDANDO_DESPACHO
      const cidadeIds = r.cidades_ids.split(',').map((id) => id.trim()).filter(Boolean);
      for (const cidadeId of cidadeIds) {
        try {
          await entityUpdate('cidades', cidadeId, {
            status: 'AGUARDANDO_DESPACHO',
            motorista_id: '',
            motorista_nome: '',
            veiculo_tipo: '',
          });
        } catch {
          // ignore
        }
      }
      await entityDelete('rotas', r.id);
      toast.success(`Rota de "${r.motorista_nome}" excluída`);
      await loadData();
    } catch {
      toast.error('Erro ao excluir rota');
    } finally {
      setDeletingId(null);
    }
  };

  if (loading || !user || !profile) {
    return (
      <div className="min-h-screen bg-[#0F172A] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
      </div>
    );
  }

  const motoristas = allProfiles.filter((p) => p.perfil === 'MOTORISTA');
  const gestores = allProfiles.filter((p) => p.perfil === 'GESTOR');
  const existingCityNames = cidades.map((c) => c.nome.toLowerCase());

  const tabs: { key: AdminTab; label: string; icon: typeof Shield }[] = [
    { key: 'cidades', label: 'Cidades', icon: MapPin },
    { key: 'regioes', label: 'Regiões CE', icon: Globe },
    { key: 'gestores', label: 'Gestores', icon: Shield },
    { key: 'entregadores', label: 'Entregadores', icon: Users },
    { key: 'motoristas', label: 'Motoristas', icon: Truck },
    { key: 'usuarios', label: 'Usuários', icon: UserPlus },
    { key: 'excluir', label: 'Exclusões', icon: Trash2 },
  ];

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      <Sidebar profileType={profile.perfil} profileName={profile.nome} onLogout={logout} onSwitchProfile={clearProfile} />
      <main className="ml-64">
        <div className="bg-gradient-to-r from-[#0F172A] to-[#1E293B] px-8 py-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-sm flex items-center justify-center">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">Painel Administrador</h1>
                <p className="text-slate-400 text-sm">DRACCO — Poder Supremo</p>
              </div>
            </div>
            <button onClick={loadData} disabled={loadingData} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/10 text-white text-sm hover:bg-white/20 transition-all">
              <RefreshCw className={cn('w-4 h-4', loadingData && 'animate-spin')} />
              Atualizar
            </button>
          </div>
          <div className="flex gap-1 bg-white/5 rounded-xl p-1 overflow-x-auto">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  className={cn(
                    'flex-1 flex items-center justify-center gap-1.5 px-2 py-2.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap',
                    activeTab === tab.key ? 'bg-white/15 text-white shadow-sm' : 'text-slate-400 hover:text-white hover:bg-white/5'
                  )}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span className="hidden xl:inline">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="px-8 py-6">
          {/* CIDADES TAB */}
          {activeTab === 'cidades' && (
            <div className="max-w-2xl">
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 mb-6">
                <h2 className="text-lg font-semibold text-slate-800 mb-4">Adicionar Cidade</h2>
                <div className="flex gap-3">
                  <input type="text" value={newCidadeNome} onChange={(e) => setNewCidadeNome(e.target.value)} placeholder="Nome da cidade..." className="flex-1 px-4 py-2.5 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50" />
                  <button onClick={handleAddCity} disabled={addingCity || !newCidadeNome.trim()} className={cn('px-6 py-2.5 rounded-lg font-bold text-sm flex items-center gap-2 transition-all', newCidadeNome.trim() && !addingCity ? 'bg-emerald-600 text-white hover:bg-emerald-700' : 'bg-slate-100 text-slate-400 cursor-not-allowed')}>
                    {addingCity ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                    Adicionar
                  </button>
                </div>
              </div>
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
                <h3 className="text-sm font-semibold text-slate-700 mb-3">Cidades Cadastradas ({cidades.length})</h3>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {cidades.map((c) => (
                    <div key={c.id} className="flex items-center justify-between py-3 px-4 rounded-lg bg-slate-50">
                      <div>
                        <p className="text-sm font-medium text-slate-800">{c.nome}</p>
                        <p className="text-xs text-slate-500">Entregador: {c.entregador_padrao_nome || '—'} | Status: {c.status}</p>
                      </div>
                      <button onClick={() => handleRemoveCity(c.id, c.nome)} className="p-2 rounded-lg text-red-500 hover:bg-red-50 transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* REGIÕES CEARÁ TAB */}
          {activeTab === 'regioes' && (
            <div className="max-w-2xl">
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 mb-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center">
                    <Globe className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h2 className="text-lg font-semibold text-slate-800">Seletor Regional — Ceará</h2>
                    <p className="text-xs text-slate-500">País: Brasil | Estado: Ceará</p>
                  </div>
                </div>

                {regioesceara.map((region) => (
                  <div key={region.name} className="mb-6">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-sm font-bold text-slate-700">Região {region.name}</h3>
                      <button
                        onClick={() => selectAllRegion(region.name)}
                        className="text-xs text-emerald-600 hover:text-emerald-700 font-medium"
                      >
                        Selecionar/Desmarcar Todas
                      </button>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                      {region.cities.map((city) => {
                        const alreadyExists = existingCityNames.includes(city.toLowerCase());
                        const isSelected = selectedRegionCities.includes(city);
                        return (
                          <button
                            key={city}
                            onClick={() => !alreadyExists && toggleRegionCity(city)}
                            disabled={alreadyExists}
                            className={cn(
                              'flex items-center gap-2 py-2.5 px-3 rounded-lg border text-left text-xs font-medium transition-all',
                              alreadyExists
                                ? 'bg-green-50 border-green-200 text-green-600 cursor-not-allowed'
                                : isSelected
                                  ? 'bg-emerald-50 border-emerald-300 text-emerald-700 shadow-sm'
                                  : 'bg-slate-50 border-slate-200 text-slate-700 hover:border-slate-300'
                            )}
                          >
                            <div className={cn('w-4 h-4 rounded border-2 flex items-center justify-center flex-shrink-0', alreadyExists ? 'bg-green-500 border-green-500' : isSelected ? 'bg-emerald-500 border-emerald-500' : 'border-slate-300')}>
                              {(alreadyExists || isSelected) && (
                                <CheckSquare className="w-3 h-3 text-white" />
                              )}
                            </div>
                            <span className="truncate">{city}</span>
                            {alreadyExists && <span className="text-[9px] text-green-500 ml-auto">✓</span>}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}

                <button
                  onClick={handleImportRegionCities}
                  disabled={addingRegion || selectedRegionCities.length === 0}
                  className={cn(
                    'w-full py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all',
                    selectedRegionCities.length > 0 && !addingRegion
                      ? 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-lg shadow-emerald-500/20'
                      : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  )}
                >
                  {addingRegion ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                  {addingRegion ? 'Importando...' : `Importar ${selectedRegionCities.length} Cidade(s)`}
                </button>
              </div>
            </div>
          )}

          {/* GESTORES TAB */}
          {activeTab === 'gestores' && (
            <div className="max-w-2xl">
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 mb-6">
                <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                  <Shield className="w-5 h-5 text-blue-500" />
                  Criar Gestor
                </h2>
                <p className="text-xs text-slate-500 mb-4">Apenas o Administrador pode criar Gestores. Gestores podem criar Auxiliares, Motoristas e Entregadores.</p>
                <div className="flex gap-3">
                  <input type="text" value={gestorNome} onChange={(e) => setGestorNome(e.target.value)} placeholder="Nome do gestor..." className="flex-1 px-4 py-2.5 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50" />
                  <button onClick={handleAddGestor} disabled={savingGestor || !gestorNome.trim()} className={cn('px-6 py-2.5 rounded-lg font-bold text-sm flex items-center gap-2 transition-all', gestorNome.trim() && !savingGestor ? 'bg-blue-600 text-white hover:bg-blue-700' : 'bg-slate-100 text-slate-400 cursor-not-allowed')}>
                    {savingGestor ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                    Criar Gestor
                  </button>
                </div>
              </div>
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
                <h3 className="text-sm font-semibold text-slate-700 mb-3">Gestores Cadastrados ({gestores.length})</h3>
                <div className="space-y-2">
                  {gestores.map((g) => (
                    <div key={g.id} className="flex items-center justify-between py-3 px-4 rounded-lg bg-slate-50">
                      <div>
                        <p className="text-sm font-medium text-slate-800">{g.nome}</p>
                        <p className="text-xs text-slate-500">Perfil: Gestor</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button onClick={() => handleToggleUserActive(g)} className={cn('text-xs font-semibold px-2 py-1 rounded-full cursor-pointer transition-colors', g.ativo !== false ? 'bg-green-100 text-green-700 hover:bg-green-200' : 'bg-red-100 text-red-700 hover:bg-red-200')}>
                          {g.ativo !== false ? 'Ativo' : 'Inativo'}
                        </button>
                        <button onClick={() => handleDeleteUser(g)} disabled={deletingId === g.id} className="p-1.5 rounded-lg text-red-500 hover:bg-red-50 transition-colors">
                          {deletingId === g.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>
                  ))}
                  {gestores.length === 0 && <p className="text-sm text-slate-500 text-center py-4">Nenhum gestor cadastrado</p>}
                </div>
              </div>
            </div>
          )}

          {/* ENTREGADORES TAB */}
          {activeTab === 'entregadores' && (
            <div className="max-w-2xl">
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 mb-6">
                <h2 className="text-lg font-semibold text-slate-800 mb-4">Alterar Entregador Padrão</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">Nome do Entregador</label>
                    <input type="text" value={entregadorNome} onChange={(e) => setEntregadorNome(e.target.value)} placeholder="Nome..." className="w-full px-3 py-2.5 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">Cidade</label>
                    <select value={entregadorCidade} onChange={(e) => setEntregadorCidade(Number(e.target.value) || '')} className="w-full px-3 py-2.5 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50">
                      <option value="">Selecione...</option>
                      {cidades.map((c) => (<option key={c.id} value={c.id}>{c.nome}</option>))}
                    </select>
                  </div>
                </div>
                <button onClick={handleAssignEntregador} disabled={savingEntregador || !entregadorNome.trim() || !entregadorCidade} className={cn('w-full py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all', entregadorNome.trim() && entregadorCidade && !savingEntregador ? 'bg-emerald-600 text-white hover:bg-emerald-700' : 'bg-slate-100 text-slate-400 cursor-not-allowed')}>
                  {savingEntregador ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                  Vincular Entregador
                </button>
              </div>
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
                <h3 className="text-sm font-semibold text-slate-700 mb-3">Entregadores por Cidade</h3>
                <div className="space-y-2">
                  {cidades.map((c) => (
                    <div key={c.id} className="flex items-center justify-between py-3 px-4 rounded-lg bg-slate-50">
                      <div>
                        <p className="text-sm font-medium text-slate-800">{c.nome}</p>
                        <p className="text-xs text-slate-500">{c.entregador_padrao_nome ? `Entregador: ${c.entregador_padrao_nome}` : 'Sem entregador'}</p>
                      </div>
                      {c.entregador_padrao_nome && (
                        <button onClick={() => handleRemoveEntregador(c.id)} className="p-2 rounded-lg text-red-500 hover:bg-red-50 transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* MOTORISTAS TAB */}
          {activeTab === 'motoristas' && (
            <div className="max-w-2xl">
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 mb-6">
                <h2 className="text-lg font-semibold text-slate-800 mb-4">Cadastrar Motorista</h2>
                <div className="flex gap-3">
                  <input type="text" value={motoristaNome} onChange={(e) => setMotoristaNome(e.target.value)} placeholder="Nome do motorista..." className="flex-1 px-4 py-2.5 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50" />
                  <button onClick={handleAddMotorista} disabled={savingMotorista || !motoristaNome.trim()} className={cn('px-6 py-2.5 rounded-lg font-bold text-sm flex items-center gap-2 transition-all', motoristaNome.trim() && !savingMotorista ? 'bg-emerald-600 text-white hover:bg-emerald-700' : 'bg-slate-100 text-slate-400 cursor-not-allowed')}>
                    {savingMotorista ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                    Cadastrar
                  </button>
                </div>
              </div>
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
                <h3 className="text-sm font-semibold text-slate-700 mb-3">Motoristas Cadastrados ({motoristas.length})</h3>
                <div className="space-y-2">
                  {motoristas.map((m) => (
                    <div key={m.id} className="flex items-center justify-between py-3 px-4 rounded-lg bg-slate-50">
                      <div>
                        <p className="text-sm font-medium text-slate-800">{m.nome}</p>
                        <p className="text-xs text-slate-500">Perfil: Motorista</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={cn('text-xs font-semibold px-2 py-1 rounded-full', m.ativo ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700')}>
                          {m.ativo ? 'Ativo' : 'Inativo'}
                        </span>
                        <button onClick={() => handleDeleteUser(m)} disabled={deletingId === m.id} className="p-1.5 rounded-lg text-red-500 hover:bg-red-50 transition-colors">
                          {deletingId === m.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>
                  ))}
                  {motoristas.length === 0 && <p className="text-sm text-slate-500 text-center py-4">Nenhum motorista cadastrado</p>}
                </div>
              </div>
            </div>
          )}

          {/* USUARIOS TAB */}
          {activeTab === 'usuarios' && (
            <div className="max-w-2xl">
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
                <h2 className="text-lg font-semibold text-slate-800 mb-4">Todos os Usuários ({allProfiles.length})</h2>
                <div className="space-y-2 max-h-[500px] overflow-y-auto">
                  {allProfiles.map((p) => (
                    <div key={p.id} className="flex items-center justify-between py-3 px-4 rounded-lg bg-slate-50">
                      <div>
                        <p className="text-sm font-medium text-slate-800">{p.nome}</p>
                        <p className="text-xs text-slate-500">
                          Perfil: {p.perfil} {p.cidade_vinculada_nome ? `| Cidade: ${p.cidade_vinculada_nome}` : ''}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button onClick={() => handleToggleUserActive(p)} className={cn('text-xs font-semibold px-3 py-1.5 rounded-full transition-colors cursor-pointer', p.ativo !== false ? 'bg-green-100 text-green-700 hover:bg-green-200' : 'bg-red-100 text-red-700 hover:bg-red-200')}>
                          {p.ativo !== false ? 'Ativo' : 'Inativo'}
                        </button>
                        <button onClick={() => handleDeleteUser(p)} disabled={deletingId === p.id} className="p-1.5 rounded-lg text-red-500 hover:bg-red-50 transition-colors">
                          {deletingId === p.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* EXCLUSÕES TAB */}
          {activeTab === 'excluir' && (
            <div className="max-w-3xl space-y-6">
              <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-red-800">Zona de Exclusão — Administrador</p>
                  <p className="text-xs text-red-600">Ações irreversíveis. Use com cuidado. O Administrador ignora restrições operacionais.</p>
                </div>
              </div>

              {/* Delete Triagens */}
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
                <h3 className="text-sm font-semibold text-slate-800 mb-4 flex items-center gap-2">
                  <ClipboardList className="w-4 h-4 text-red-500" />
                  Excluir Triagens ({resumos.length})
                </h3>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {resumos.map((r) => (
                    <div key={r.id} className="flex items-center justify-between py-2.5 px-4 rounded-lg bg-slate-50">
                      <div>
                        <p className="text-sm font-medium text-slate-800">{r.cidade_nome} — {r.quantidade_pacotes} pacotes</p>
                        <p className="text-xs text-slate-500">{r.auxiliar_responsavel} | {r.status}</p>
                      </div>
                      <button onClick={() => handleDeleteTriagem(r)} disabled={deletingId === r.id} className="p-2 rounded-lg text-red-500 hover:bg-red-50 transition-colors">
                        {deletingId === r.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                      </button>
                    </div>
                  ))}
                  {resumos.length === 0 && <p className="text-xs text-slate-500 text-center py-4">Nenhuma triagem</p>}
                </div>
              </div>

              {/* Delete Rotas */}
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
                <h3 className="text-sm font-semibold text-slate-800 mb-4 flex items-center gap-2">
                  <Send className="w-4 h-4 text-red-500" />
                  Excluir Rotas ({rotas.length})
                </h3>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {rotas.map((r) => (
                    <div key={r.id} className="flex items-center justify-between py-2.5 px-4 rounded-lg bg-slate-50">
                      <div>
                        <p className="text-sm font-medium text-slate-800">{r.motorista_nome} — {r.veiculo_tipo}</p>
                        <p className="text-xs text-slate-500">{r.cidades_nomes} | {r.status}</p>
                      </div>
                      <button onClick={() => handleDeleteRota(r)} disabled={deletingId === r.id} className="p-2 rounded-lg text-red-500 hover:bg-red-50 transition-colors">
                        {deletingId === r.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                      </button>
                    </div>
                  ))}
                  {rotas.length === 0 && <p className="text-xs text-slate-500 text-center py-4">Nenhuma rota</p>}
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}