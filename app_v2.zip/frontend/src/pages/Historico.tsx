import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import Sidebar from '@/components/Sidebar';
import { useProfile } from '@/hooks/useProfile';
import { client } from '@/lib/api';
import { cn } from '@/lib/utils';
import type { Transferencia, Confirmacao, LeituraAuxiliar, Rota } from '@/lib/types';
import {
  History,
  Loader2,
  RefreshCw,
  ScanLine,
  CheckCircle2,
  ClipboardList,
  Truck,
  MapPin,
} from 'lucide-react';

type HistTab = 'leituras' | 'rotas' | 'transferencias' | 'confirmacoes';

export default function HistoricoPage() {
  const navigate = useNavigate();
  const { user, profile, loading, logout, clearProfile } = useProfile();
  const [loadingData, setLoadingData] = useState(false);
  const [activeTab, setActiveTab] = useState<HistTab>('leituras');

  const [leituras, setLeituras] = useState<LeituraAuxiliar[]>([]);
  const [rotas, setRotas] = useState<Rota[]>([]);
  const [transferencias, setTransferencias] = useState<Transferencia[]>([]);
  const [confirmacoes, setConfirmacoes] = useState<Confirmacao[]>([]);

  const loadData = useCallback(async () => {
    setLoadingData(true);
    try {
      const [leitRes, rotasRes, transRes, confRes] = await Promise.all([
        client.entities.leituras_auxiliar.queryAll({ query: {}, limit: 200, sort: '-created_at' }),
        client.entities.rotas.queryAll({ query: {}, limit: 200, sort: '-created_at' }),
        client.entities.transferencias.queryAll({ query: {}, limit: 200, sort: '-data_hora' }),
        client.entities.confirmacoes.queryAll({ query: {}, limit: 200, sort: '-data_hora' }),
      ]);
      setLeituras((leitRes?.data?.items || []) as LeituraAuxiliar[]);
      setRotas((rotasRes?.data?.items || []) as Rota[]);
      setTransferencias((transRes?.data?.items || []) as Transferencia[]);
      setConfirmacoes((confRes?.data?.items || []) as Confirmacao[]);
    } catch {
      // ignore
    } finally {
      setLoadingData(false);
    }
  }, []);

  useEffect(() => {
    if (user && profile) loadData();
  }, [user, profile, loadData]);

  useEffect(() => {
    if (!loading && user && !profile) {
      navigate('/', { replace: true });
    } else if (!loading && user && profile && profile.perfil !== 'ADMINISTRADOR' && profile.perfil !== 'GESTOR') {
      navigate('/', { replace: true });
    }
  }, [loading, user, profile, navigate]);

  if (loading || !user || !profile) {
    return (
      <div className="min-h-screen bg-[#0F172A] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
      </div>
    );
  }

  const formatDate = (d: string) => {
    if (!d) return '—';
    try {
      return new Date(d).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
    } catch {
      return d;
    }
  };

  // Filter last 30 days
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  const filterDate = (dateStr: string) => {
    if (!dateStr) return true;
    try { return new Date(dateStr) >= thirtyDaysAgo; } catch { return true; }
  };

  const filteredLeituras = leituras.filter((l) => filterDate(l.created_at));
  const filteredRotas = rotas.filter((r) => filterDate(r.created_at));
  const filteredTransferencias = transferencias.filter((t) => filterDate(t.data_hora));
  const filteredConfirmacoes = confirmacoes.filter((c) => filterDate(c.data_hora));

  const tabs: { key: HistTab; label: string; icon: typeof History; count: number }[] = [
    { key: 'leituras', label: 'Leituras Auxiliar', icon: ClipboardList, count: filteredLeituras.length },
    { key: 'rotas', label: 'Rotas', icon: Truck, count: filteredRotas.length },
    { key: 'transferencias', label: 'Transferências', icon: ScanLine, count: filteredTransferencias.length },
    { key: 'confirmacoes', label: 'Confirmações', icon: CheckCircle2, count: filteredConfirmacoes.length },
  ];

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      <Sidebar profileType={profile.perfil} profileName={profile.nome} onLogout={logout} onSwitchProfile={clearProfile} />
      <main className="ml-64">
        <div className="bg-gradient-to-r from-[#0F172A] to-[#1E293B] px-8 py-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-sm flex items-center justify-center">
                <History className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">Histórico — 30 Dias</h1>
                <p className="text-slate-400 text-sm">DRACCO — Leituras, rotas, transferências e confirmações</p>
              </div>
            </div>
            <button onClick={loadData} disabled={loadingData} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/10 text-white text-sm hover:bg-white/20 transition-all">
              <RefreshCw className={cn('w-4 h-4', loadingData && 'animate-spin')} />
              Atualizar
            </button>
          </div>
          <div className="flex gap-1 bg-white/5 rounded-xl p-1">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  className={cn(
                    'flex-1 flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium transition-all',
                    activeTab === tab.key ? 'bg-white/15 text-white shadow-sm' : 'text-slate-400 hover:text-white hover:bg-white/5'
                  )}
                >
                  <Icon className="w-4 h-4" />
                  {tab.label}
                  <span className="text-[10px] bg-white/10 px-1.5 py-0.5 rounded-full">{tab.count}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="px-8 py-6">
          {loadingData ? (
            <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 text-emerald-500 animate-spin" /></div>
          ) : (
            <>
              {/* LEITURAS */}
              {activeTab === 'leituras' && (
                <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="bg-slate-50 border-b border-slate-200">
                        <tr>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">Código</th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">Cidade</th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">Vencimento</th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">Auxiliar</th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">Data</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredLeituras.map((l) => (
                          <tr key={l.id} className="border-b border-slate-100 hover:bg-slate-50">
                            <td className="px-4 py-3 font-mono text-xs">{l.codigo_rastreio}</td>
                            <td className="px-4 py-3 text-xs">{l.cidade_nome}</td>
                            <td className="px-4 py-3 text-xs">{l.data_vencimento || '—'}</td>
                            <td className="px-4 py-3 text-xs">{l.auxiliar_nome}</td>
                            <td className="px-4 py-3 text-xs text-slate-500">{formatDate(l.created_at)}</td>
                          </tr>
                        ))}
                        {filteredLeituras.length === 0 && (
                          <tr><td colSpan={5} className="px-4 py-8 text-center text-slate-500">Nenhuma leitura nos últimos 30 dias</td></tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* ROTAS */}
              {activeTab === 'rotas' && (
                <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="bg-slate-50 border-b border-slate-200">
                        <tr>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">Motorista</th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">Veículo</th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">Cidades</th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">Status</th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">Data</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredRotas.map((r) => (
                          <tr key={r.id} className="border-b border-slate-100 hover:bg-slate-50">
                            <td className="px-4 py-3 text-xs">{r.motorista_nome}</td>
                            <td className="px-4 py-3 text-xs">{r.veiculo_tipo}</td>
                            <td className="px-4 py-3 text-xs">{r.cidades_nomes}</td>
                            <td className="px-4 py-3 text-xs"><span className="bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full text-[10px] font-semibold">{r.status}</span></td>
                            <td className="px-4 py-3 text-xs text-slate-500">{formatDate(r.created_at)}</td>
                          </tr>
                        ))}
                        {filteredRotas.length === 0 && (
                          <tr><td colSpan={5} className="px-4 py-8 text-center text-slate-500">Nenhuma rota nos últimos 30 dias</td></tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TRANSFERENCIAS */}
              {activeTab === 'transferencias' && (
                <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="bg-slate-50 border-b border-slate-200">
                        <tr>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">Código</th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">Cidade</th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">Motorista</th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">GPS</th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">Data/Hora</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredTransferencias.map((t) => (
                          <tr key={t.id} className="border-b border-slate-100 hover:bg-slate-50">
                            <td className="px-4 py-3 font-mono text-xs">{t.codigo_rastreio}</td>
                            <td className="px-4 py-3 text-xs">{t.cidade_nome}</td>
                            <td className="px-4 py-3 text-xs">{t.motorista_nome}</td>
                            <td className="px-4 py-3 text-xs text-slate-500">
                              {t.gps_lat && t.gps_lng ? `${t.gps_lat.toFixed(4)}, ${t.gps_lng.toFixed(4)}` : '—'}
                            </td>
                            <td className="px-4 py-3 text-xs text-slate-500">{formatDate(t.data_hora)}</td>
                          </tr>
                        ))}
                        {filteredTransferencias.length === 0 && (
                          <tr><td colSpan={5} className="px-4 py-8 text-center text-slate-500">Nenhuma transferência nos últimos 30 dias</td></tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* CONFIRMACOES */}
              {activeTab === 'confirmacoes' && (
                <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="bg-slate-50 border-b border-slate-200">
                        <tr>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">Cidade</th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">Entregador</th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">GPS</th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">Data/Hora</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredConfirmacoes.map((c) => (
                          <tr key={c.id} className="border-b border-slate-100 hover:bg-slate-50">
                            <td className="px-4 py-3 text-xs">{c.cidade_nome}</td>
                            <td className="px-4 py-3 text-xs">{c.entregador_nome}</td>
                            <td className="px-4 py-3 text-xs text-slate-500">
                              {c.gps_lat && c.gps_lng ? `${c.gps_lat.toFixed(4)}, ${c.gps_lng.toFixed(4)}` : '—'}
                            </td>
                            <td className="px-4 py-3 text-xs text-slate-500">{formatDate(c.data_hora)}</td>
                          </tr>
                        ))}
                        {filteredConfirmacoes.length === 0 && (
                          <tr><td colSpan={4} className="px-4 py-8 text-center text-slate-500">Nenhuma confirmação nos últimos 30 dias</td></tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </main>
    </div>
  );
}