import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import Sidebar from '@/components/Sidebar';
import { useProfile } from '@/hooks/useProfile';
import { client } from '@/lib/api';
import { cn } from '@/lib/utils';
import { cidadeStatusLabels, cidadeStatusColors } from '@/lib/types';
import type { Cidade, Pacote, CidadeStatus } from '@/lib/types';
import { entityUpdate } from '@/lib/apiHelpers';
import { toast } from 'sonner';
import {
  PackageCheck,
  Loader2,
  MapPin,
  CheckCircle2,
  Package,
  Truck,
} from 'lucide-react';

export default function EntregadorPage() {
  const navigate = useNavigate();
  const { user, profile, loading, logout, clearProfile } = useProfile();
  const [cidades, setCidades] = useState<Cidade[]>([]);
  const [pacotes, setPacotes] = useState<Pacote[]>([]);
  const [loadingData, setLoadingData] = useState(false);
  const [confirming, setConfirming] = useState(false);

  const loadData = useCallback(async () => {
    setLoadingData(true);
    try {
      const [cidadesRes, pacotesRes] = await Promise.all([
        client.entities.cidades.query({ query: {}, limit: 50 }),
        client.entities.pacotes.query({ query: {}, limit: 500 }),
      ]);
      setCidades((cidadesRes?.data?.items || []) as Cidade[]);
      setPacotes((pacotesRes?.data?.items || []) as Pacote[]);
    } catch {
      // ignore
    } finally {
      setLoadingData(false);
    }
  }, []);

  useEffect(() => {
    if (user && profile) loadData();
  }, [user, profile, loadData]);

  useEffect(() => {
    if (!loading && user && !profile) {
      navigate('/', { replace: true });
    } else if (!loading && user && profile && profile.perfil !== 'ENTREGADOR') {
      navigate('/', { replace: true });
    }
  }, [loading, user, profile, navigate]);

  const getGPS = (): Promise<{ lat: number; lng: number }> =>
    new Promise((resolve) => {
      if (!navigator.geolocation) return resolve({ lat: 0, lng: 0 });
      navigator.geolocation.getCurrentPosition(
        (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        () => resolve({ lat: 0, lng: 0 }),
        { timeout: 5000 }
      );
    });

  const minhaCidade = cidades.find((c) => c.id === profile?.cidade_vinculada_id);
  const meusPacotes = minhaCidade ? pacotes.filter((p) => p.cidade_id === minhaCidade.id) : [];
  const canConfirm = minhaCidade?.status === 'AGUARDANDO_CONFIRMACAO_ENTREGADOR';

  const handleConfirm = async () => {
    if (!minhaCidade || !canConfirm) return;
    setConfirming(true);
    try {
      const gps = await getGPS();
      await client.entities.confirmacoes.create({
        data: {
          cidade_id: minhaCidade.id,
          cidade_nome: minhaCidade.nome,
          entregador_id: profile?.user_id || user?.id || '',
          entregador_nome: profile?.nome || '',
          data_hora: new Date().toISOString(),
          gps_lat: gps.lat,
          gps_lng: gps.lng,
        },
      });
      await entityUpdate('cidades', minhaCidade.id, { status: 'ENTREGUE_AO_ENTREGADOR' });
      toast.success('Recebimento confirmado com sucesso!');
      await loadData();
    } catch {
      toast.error('Erro ao confirmar recebimento');
    } finally {
      setConfirming(false);
    }
  };

  if (loading || !user || !profile) {
    return (
      <div className="min-h-screen bg-[#0F172A] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      <Sidebar profileType={profile.perfil} profileName={profile.nome} onLogout={logout} onSwitchProfile={clearProfile} />
      <main className="ml-64">
        <div className="bg-gradient-to-r from-[#0F172A] to-[#1E293B] px-8 py-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-sm flex items-center justify-center">
              <PackageCheck className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">Minha Cidade</h1>
              <p className="text-slate-400 text-sm">DRACCO — Confirmação de recebimento</p>
            </div>
          </div>
        </div>

        <div className="px-8 py-6">
          <div className="max-w-xl mx-auto">
            {!minhaCidade ? (
              <div className="text-center py-12">
                <Truck className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                <p className="text-slate-500">Nenhuma cidade vinculada ao seu perfil</p>
                <p className="text-xs text-slate-400 mt-1">Cidade: {profile.cidade_vinculada_nome || 'Não definida'}</p>
              </div>
            ) : (
              <>
                {/* City Info */}
                <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 mb-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center">
                        <MapPin className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h2 className="text-lg font-semibold text-slate-800">{minhaCidade.nome}</h2>
                        <p className="text-xs text-slate-500">Entregador: {profile.nome}</p>
                      </div>
                    </div>
                    {(() => {
                      const sc = cidadeStatusColors[minhaCidade.status as CidadeStatus] || cidadeStatusColors.AGUARDANDO_DESPACHO;
                      return (
                        <span className={cn('text-[10px] font-semibold px-2 py-1 rounded-full', sc.bg, sc.text)}>
                          {cidadeStatusLabels[minhaCidade.status as CidadeStatus] || minhaCidade.status}
                        </span>
                      );
                    })()}
                  </div>

                  {/* Packages count */}
                  <div className="flex items-center justify-center py-6 bg-slate-50 rounded-xl mb-4">
                    <div className="text-center">
                      <p className="text-4xl font-bold text-slate-800">{meusPacotes.length}</p>
                      <p className="text-sm text-slate-500">pacotes nesta cidade</p>
                    </div>
                  </div>

                  {/* Status message */}
                  {minhaCidade.status === 'ENTREGUE_AO_ENTREGADOR' && (
                    <div className="bg-green-50 border border-green-200 rounded-xl p-4 mb-4 flex items-center gap-3">
                      <CheckCircle2 className="w-6 h-6 text-green-600 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-semibold text-green-800">Recebimento Confirmado</p>
                        <p className="text-xs text-green-600">Pacotes entregues com sucesso</p>
                      </div>
                    </div>
                  )}

                  {minhaCidade.status === 'AGUARDANDO_CONFIRMACAO_ENTREGADOR' && (
                    <div className="bg-purple-50 border border-purple-200 rounded-xl p-4 mb-4 flex items-center gap-3">
                      <Package className="w-6 h-6 text-purple-600 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-semibold text-purple-800">Pacotes Aguardando Confirmação</p>
                        <p className="text-xs text-purple-600">Confirme o recebimento dos pacotes abaixo</p>
                      </div>
                    </div>
                  )}

                  {(minhaCidade.status !== 'AGUARDANDO_CONFIRMACAO_ENTREGADOR' && minhaCidade.status !== 'ENTREGUE_AO_ENTREGADOR') && (
                    <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-4 flex items-center gap-3">
                      <Package className="w-6 h-6 text-amber-600 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-semibold text-amber-800">Aguardando Bipagem</p>
                        <p className="text-xs text-amber-600">O motorista ainda está realizando a bipagem dos pacotes</p>
                      </div>
                    </div>
                  )}

                  {/* Confirm Button */}
                  <button
                    onClick={handleConfirm}
                    disabled={!canConfirm || confirming}
                    className={cn(
                      'w-full py-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all',
                      canConfirm && !confirming
                        ? 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-lg shadow-emerald-500/20'
                        : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                    )}
                  >
                    {confirming ? (
                      <Loader2 className="w-5 h-5 animate-spin" />
                    ) : (
                      <CheckCircle2 className="w-5 h-5" />
                    )}
                    {confirming ? 'Confirmando...' : 'Confirmar Recebimento'}
                  </button>
                </div>

                {/* Package List */}
                <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
                  <h3 className="text-sm font-semibold text-slate-700 mb-3">Pacotes ({meusPacotes.length})</h3>
                  <div className="max-h-64 overflow-y-auto space-y-1">
                    {meusPacotes.map((p) => (
                      <div key={p.id} className="flex items-center justify-between py-2 px-3 rounded-lg bg-slate-50">
                        <div className="flex items-center gap-2">
                          <Package className="w-3.5 h-3.5 text-slate-400" />
                          <span className="text-xs font-mono text-slate-700">{p.codigo_rastreio}</span>
                        </div>
                        <span className={cn('text-[10px] font-semibold px-2 py-0.5 rounded-full', p.status === 'BIPADO' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-600')}>
                          {p.status}
                        </span>
                      </div>
                    ))}
                    {meusPacotes.length === 0 && (
                      <p className="text-xs text-slate-500 text-center py-4">Nenhum pacote registrado</p>
                    )}
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}