import { useState, useEffect, useCallback } from 'react';
import { cn } from '@/lib/utils';
import { client } from '@/lib/api';
import { toast } from 'sonner';
import { createTicket } from '@/lib/dracco-api';
import { RETURN_REASONS } from '@/lib/dracco-types';
import type { LoginResponse } from '@/lib/dracco-types';
import type { Cidade, Pacote, Rota } from '@/lib/types';
import {
  Truck, Loader2, RefreshCw, Search, Package, AlertTriangle,
  MapPin, CheckCircle2,
} from 'lucide-react';

type MotoristaTab = 'rotas' | 'busca' | 'retorno';

interface MotoristaPanelProps {
  currentUser: LoginResponse;
  onLogout: () => void;
  onSwitchUser: () => void;
}

export default function MotoristaPanelPage({ currentUser, onLogout, onSwitchUser }: MotoristaPanelProps) {
  const [activeTab, setActiveTab] = useState<MotoristaTab>('rotas');
  const [loadingData, setLoadingData] = useState(false);
  const [cidades, setCidades] = useState<Cidade[]>([]);
  const [rotas, setRotas] = useState<Rota[]>([]);

  // TBR search
  const [tbrQuery, setTbrQuery] = useState('');
  const [tbrResults, setTbrResults] = useState<Pacote[]>([]);
  const [tbrSearched, setTbrSearched] = useState(false);
  const [searchingTbr, setSearchingTbr] = useState(false);

  // Return classification
  const [returnTbr, setReturnTbr] = useState('');
  const [returnMotivo, setReturnMotivo] = useState('');
  const [submittingReturn, setSubmittingReturn] = useState(false);

  const loadData = useCallback(async () => {
    setLoadingData(true);
    try {
      const [cidadesRes, rotasRes] = await Promise.all([
        client.entities.cidades.query({ query: {}, limit: 200 }),
        client.entities.rotas.queryAll({ query: {}, limit: 50, sort: '-created_at' }),
      ]);
      setCidades((cidadesRes?.data?.items || []) as Cidade[]);
      setRotas((rotasRes?.data?.items || []) as Rota[]);
    } catch { /* ignore */ }
    finally { setLoadingData(false); }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const handleSearchTbr = async () => {
    if (!tbrQuery.trim()) return;
    setSearchingTbr(true);
    setTbrSearched(true);
    try {
      const res = await client.entities.pacotes.query({ query: { codigo_rastreio: tbrQuery.trim() }, limit: 10 });
      setTbrResults((res?.data?.items || []) as Pacote[]);
    } catch { setTbrResults([]); }
    finally { setSearchingTbr(false); }
  };

  const handleSubmitReturn = async () => {
    if (!returnTbr.trim() || !returnMotivo) return;
    setSubmittingReturn(true);
    try {
      await createTicket({
        tbr: returnTbr.trim(),
        motivo: returnMotivo,
        base_code: currentUser.base_code,
      });
      toast.success(`Retorno registrado e chamado criado para TBR: ${returnTbr}`);
      setReturnTbr('');
      setReturnMotivo('');
    } catch (err: any) {
      toast.error(err?.data?.detail || 'Erro ao registrar retorno');
    } finally {
      setSubmittingReturn(false);
    }
  };

  const myRotas = rotas.filter((r) => r.motorista_nome?.toLowerCase() === currentUser.nome.toLowerCase());

  const tabs: { key: MotoristaTab; label: string; icon: typeof Truck }[] = [
    { key: 'rotas', label: 'Minhas Rotas', icon: MapPin },
    { key: 'busca', label: 'Consultar TBR', icon: Search },
    { key: 'retorno', label: 'Registrar Retorno', icon: AlertTriangle },
  ];

  return (
    <div className="min-h-screen bg-[#0F172A]">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-[#0F172A]/95 backdrop-blur-sm border-b border-white/10 px-4 py-3">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center shadow-lg shadow-amber-500/25">
              <Truck className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white">Motorista</h1>
              <p className="text-slate-400 text-xs">{currentUser.nome} · Base {currentUser.base_code}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={loadData} disabled={loadingData} className="p-2 rounded-xl bg-white/10 text-white hover:bg-white/20">
              <RefreshCw className={cn('w-4 h-4', loadingData && 'animate-spin')} />
            </button>
            <button onClick={onSwitchUser} className="px-3 py-2 rounded-xl bg-white/10 text-slate-300 text-xs hover:bg-white/20">Trocar</button>
            <button onClick={onLogout} className="px-3 py-2 rounded-xl bg-red-500/20 text-red-300 text-xs hover:bg-red-500/30">Sair</button>
          </div>
        </div>

        <div className="flex gap-1 bg-white/5 rounded-xl p-1">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button key={tab.key} onClick={() => setActiveTab(tab.key)}
                className={cn('flex-1 flex items-center justify-center gap-1.5 px-2 py-2.5 rounded-lg text-xs font-medium transition-all',
                  activeTab === tab.key ? 'bg-white/15 text-white shadow-sm' : 'text-slate-400 hover:text-white hover:bg-white/5')}>
                <Icon className="w-3.5 h-3.5" /> {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      <div className="px-4 py-6">
        {/* ROTAS */}
        {activeTab === 'rotas' && (
          <div className="space-y-3">
            <h2 className="text-sm font-semibold text-slate-300">Minhas Rotas ({myRotas.length})</h2>
            {myRotas.map((r) => (
              <div key={r.id} className="bg-white/5 border border-white/10 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Truck className="w-4 h-4 text-amber-400" />
                  <span className="text-sm font-bold text-white">{r.veiculo_tipo}</span>
                  <span className={cn('text-xs px-2 py-0.5 rounded-full font-semibold',
                    r.status === 'EM_ROTA' ? 'bg-blue-500/20 text-blue-400' : 'bg-green-500/20 text-green-400')}>
                    {r.status}
                  </span>
                </div>
                <p className="text-xs text-slate-400">Cidades: {r.cidades_nomes}</p>
              </div>
            ))}
            {myRotas.length === 0 && (
              <div className="text-center py-12">
                <MapPin className="w-10 h-10 text-slate-600 mx-auto mb-3" />
                <p className="text-sm text-slate-500">Nenhuma rota atribuída</p>
              </div>
            )}
          </div>
        )}

        {/* BUSCA TBR */}
        {activeTab === 'busca' && (
          <div className="space-y-4">
            <div className="flex gap-2">
              <input type="text" value={tbrQuery} onChange={(e) => setTbrQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearchTbr()}
                placeholder="Código TBR..."
                className="flex-1 px-4 py-3 rounded-xl bg-white/10 border border-white/10 text-white placeholder-slate-500 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-amber-500/50" />
              <button onClick={handleSearchTbr} disabled={searchingTbr || !tbrQuery.trim()}
                className={cn('px-5 py-3 rounded-xl font-bold text-sm flex items-center gap-2',
                  tbrQuery.trim() ? 'bg-amber-600 text-white hover:bg-amber-700' : 'bg-white/10 text-slate-500 cursor-not-allowed')}>
                {searchingTbr ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
              </button>
            </div>

            {tbrSearched && tbrResults.length === 0 && (
              <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4 text-center">
                <Package className="w-8 h-8 text-amber-400 mx-auto mb-2" />
                <p className="text-sm text-amber-300 font-semibold">Pacote não encontrado</p>
              </div>
            )}

            {tbrResults.map((p) => (
              <div key={p.id} className="bg-white/5 border border-white/10 rounded-xl p-4">
                <p className="text-sm font-bold text-white font-mono">{p.codigo_rastreio}</p>
                <p className="text-xs text-slate-400 mt-1">
                  Cidade: {p.cidade_nome} · Status: {p.status} · Vencimento: {p.data_vencimento}
                </p>
              </div>
            ))}
          </div>
        )}

        {/* RETORNO */}
        {activeTab === 'retorno' && (
          <div className="space-y-4">
            <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="w-5 h-5 text-amber-400" />
                <h3 className="text-sm font-bold text-amber-300">Registrar Retorno</h3>
              </div>
              <p className="text-xs text-amber-400/70">
                Ao registrar um retorno, um chamado será criado automaticamente para a base.
              </p>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Código TBR</label>
              <input type="text" value={returnTbr} onChange={(e) => setReturnTbr(e.target.value)}
                placeholder="Digite o TBR..."
                className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/10 text-white placeholder-slate-500 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-amber-500/50" />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Motivo do Retorno</label>
              <div className="space-y-2">
                {RETURN_REASONS.map((reason) => (
                  <button key={reason.value} onClick={() => setReturnMotivo(reason.value)}
                    className={cn('w-full flex items-center gap-3 p-3 rounded-xl border text-left transition-all',
                      returnMotivo === reason.value
                        ? 'bg-amber-500/15 border-amber-500/40 text-amber-300'
                        : 'bg-white/5 border-white/5 text-slate-300 hover:bg-white/10')}>
                    <div className={cn('w-5 h-5 rounded-full border-2 flex items-center justify-center',
                      returnMotivo === reason.value ? 'border-amber-500 bg-amber-500' : 'border-slate-500')}>
                      {returnMotivo === reason.value && <div className="w-2 h-2 rounded-full bg-white" />}
                    </div>
                    <span className="text-sm">{reason.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <button onClick={handleSubmitReturn}
              disabled={submittingReturn || !returnTbr.trim() || !returnMotivo}
              className={cn('w-full py-4 rounded-xl font-bold text-base flex items-center justify-center gap-2 transition-all',
                returnTbr.trim() && returnMotivo && !submittingReturn
                  ? 'bg-amber-600 text-white hover:bg-amber-700 shadow-lg shadow-amber-500/30'
                  : 'bg-white/10 text-slate-500 cursor-not-allowed')}>
              {submittingReturn ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle2 className="w-5 h-5" />}
              {submittingReturn ? 'Registrando...' : 'Registrar Retorno'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}