import { useState } from 'react';
import { Truck, ArrowRight, ArrowLeft, Loader2, Lock, User, Shield, LayoutDashboard, ClipboardList, ScanLine, PackageCheck, Eye, EyeOff } from 'lucide-react';
import { cn } from '@/lib/utils';
import { LEVEL_COLORS, ROLE_ICONS } from '@/lib/dracco-types';
import type { Step1Response, LoginResponse } from '@/lib/dracco-types';

const ROLE_CONFIG: Record<string, { label: string; desc: string; icon: typeof Shield; color: string; shadow: string }> = {
  ADMINISTRADOR: { label: 'Administrador', desc: 'Gerenciar estrutura do sistema', icon: Shield, color: 'from-red-500 to-rose-600', shadow: 'shadow-red-500/30' },
  GESTOR: { label: 'Gestor', desc: 'Gerenciar rotas e despachos', icon: LayoutDashboard, color: 'from-blue-500 to-indigo-600', shadow: 'shadow-blue-500/30' },
  AUXILIAR: { label: 'Auxiliar', desc: 'Escanear e cadastrar pacotes', icon: ClipboardList, color: 'from-cyan-500 to-teal-600', shadow: 'shadow-cyan-500/30' },
  MOTORISTA: { label: 'Motorista', desc: 'Escanear pacotes nas cidades', icon: ScanLine, color: 'from-amber-500 to-orange-600', shadow: 'shadow-amber-500/30' },
  ENTREGADOR: { label: 'Entregador', desc: 'Confirmar recebimento', icon: PackageCheck, color: 'from-green-500 to-emerald-600', shadow: 'shadow-green-500/30' },
};

interface LoginProps {
  onLoginStep1: (login: string) => Promise<Step1Response>;
  onLoginStep3: (login: string, role: string, senha: string) => Promise<LoginResponse>;
}

export default function LoginPage({ onLoginStep1, onLoginStep3 }: LoginProps) {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [login, setLogin] = useState('');
  const [step1Data, setStep1Data] = useState<Step1Response | null>(null);
  const [selectedRole, setSelectedRole] = useState('');
  const [senha, setSenha] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleStep1 = async () => {
    if (!login.trim()) return;
    setLoading(true);
    setError('');
    try {
      const data = await onLoginStep1(login.trim());
      setStep1Data(data);
      setStep(2);
    } catch (err: any) {
      const detail = err?.data?.detail || err?.response?.data?.detail || err?.message || 'Usuário não encontrado';
      setError(detail);
    } finally {
      setLoading(false);
    }
  };

  const handleStep2 = (role: string) => {
    setSelectedRole(role);
    setStep(3);
    setError('');
  };

  const handleStep3 = async () => {
    if (!senha) return;
    setLoading(true);
    setError('');
    try {
      await onLoginStep3(login.trim(), selectedRole, senha);
    } catch (err: any) {
      const detail = err?.data?.detail || err?.response?.data?.detail || err?.message || 'Erro ao fazer login';
      setError(detail);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent, action: () => void) => {
    if (e.key === 'Enter') action();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0F172A] via-[#1E293B] to-[#0F172A] flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="flex items-center justify-center gap-3 mb-8">
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-emerald-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-emerald-500/25">
            <Truck className="w-7 h-7 text-white" />
          </div>
        </div>
        <h1 className="text-3xl font-bold text-white text-center mb-1">DRACCO</h1>
        <p className="text-slate-400 text-center text-sm mb-8">Sistema Logístico Corporativo</p>

        {/* Step indicators */}
        <div className="flex items-center justify-center gap-2 mb-8">
          {[1, 2, 3].map((s) => (
            <div key={s} className="flex items-center gap-2">
              <div className={cn(
                'w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all',
                step >= s ? 'bg-emerald-500 text-white' : 'bg-white/10 text-slate-500'
              )}>
                {s}
              </div>
              {s < 3 && <div className={cn('w-8 h-0.5 transition-all', step > s ? 'bg-emerald-500' : 'bg-white/10')} />}
            </div>
          ))}
        </div>

        {/* STEP 1: Username */}
        {step === 1 && (
          <div className="space-y-4">
            <div>
              <label className="flex items-center gap-2 text-sm font-medium text-slate-300 mb-2">
                <User className="w-4 h-4" />
                Nome de Usuário
              </label>
              <input
                type="text"
                value={login}
                onChange={(e) => setLogin(e.target.value)}
                onKeyDown={(e) => handleKeyDown(e, handleStep1)}
                placeholder="Digite seu login..."
                autoFocus
                className="w-full px-4 py-3.5 rounded-xl bg-white/10 border border-white/10 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 text-base"
              />
            </div>
            {error && <p className="text-red-400 text-sm text-center">{error}</p>}
            <button
              onClick={handleStep1}
              disabled={loading || !login.trim()}
              className={cn(
                'w-full py-4 rounded-xl font-bold text-base flex items-center justify-center gap-2 transition-all',
                login.trim() && !loading
                  ? 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-lg shadow-emerald-500/30'
                  : 'bg-white/10 text-slate-500 cursor-not-allowed'
              )}
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <ArrowRight className="w-5 h-5" />}
              {loading ? 'Verificando...' : 'Continuar'}
            </button>
          </div>
        )}

        {/* STEP 2: Role Selection */}
        {step === 2 && step1Data && (
          <div className="space-y-4">
            <div className="bg-white/5 border border-white/10 rounded-xl p-4 mb-2">
              <p className="text-xs text-slate-400">Bem-vindo,</p>
              <p className="text-lg font-bold text-white">{step1Data.nome}</p>
              <p className="text-xs text-slate-500">
                {step1Data.level_label} · Base {step1Data.base_code}
              </p>
            </div>

            <p className="text-sm text-slate-300 font-medium">Selecione sua função:</p>

            <div className="space-y-2">
              {step1Data.roles.map((role) => {
                const config = ROLE_CONFIG[role];
                if (!config) return null;
                const Icon = config.icon;
                return (
                  <button
                    key={role}
                    onClick={() => handleStep2(role)}
                    className="w-full flex items-center gap-4 p-4 rounded-xl border border-white/5 bg-white/5 hover:bg-white/10 hover:border-white/10 transition-all text-left"
                  >
                    <div className={cn('w-12 h-12 rounded-xl flex items-center justify-center shadow-lg bg-gradient-to-br', config.color, config.shadow)}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-white">{config.label}</p>
                      <p className="text-xs text-slate-400">{config.desc}</p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-500" />
                  </button>
                );
              })}
            </div>

            <button
              onClick={() => { setStep(1); setError(''); }}
              className="w-full py-3 rounded-xl text-sm text-slate-400 hover:text-white hover:bg-white/5 transition-all flex items-center justify-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Voltar
            </button>
          </div>
        )}

        {/* STEP 3: Password */}
        {step === 3 && step1Data && (
          <div className="space-y-4">
            <div className="bg-white/5 border border-white/10 rounded-xl p-4 mb-2">
              <p className="text-xs text-slate-400">{step1Data.nome}</p>
              <p className="text-sm font-bold text-white">
                {ROLE_CONFIG[selectedRole]?.label || selectedRole}
              </p>
              <p className="text-xs text-slate-500">Base {step1Data.base_code}</p>
            </div>

            <div>
              <label className="flex items-center gap-2 text-sm font-medium text-slate-300 mb-2">
                <Lock className="w-4 h-4" />
                Senha
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={senha}
                  onChange={(e) => setSenha(e.target.value)}
                  onKeyDown={(e) => handleKeyDown(e, handleStep3)}
                  placeholder="Digite sua senha..."
                  autoFocus
                  className="w-full px-4 py-3.5 pr-12 rounded-xl bg-white/10 border border-white/10 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 text-base"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            {error && <p className="text-red-400 text-sm text-center">{error}</p>}

            <button
              onClick={handleStep3}
              disabled={loading || !senha}
              className={cn(
                'w-full py-4 rounded-xl font-bold text-base flex items-center justify-center gap-2 transition-all',
                senha && !loading
                  ? 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-lg shadow-emerald-500/30'
                  : 'bg-white/10 text-slate-500 cursor-not-allowed'
              )}
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Lock className="w-5 h-5" />}
              {loading ? 'Entrando...' : 'Entrar'}
            </button>

            <button
              onClick={() => { setStep(2); setSenha(''); setError(''); }}
              className="w-full py-3 rounded-xl text-sm text-slate-400 hover:text-white hover:bg-white/5 transition-all flex items-center justify-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Voltar
            </button>
          </div>
        )}
      </div>
    </div>
  );
}