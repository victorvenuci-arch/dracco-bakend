import { useParams, useNavigate } from 'react-router-dom';
import Sidebar from '@/components/Sidebar';
import StatusTimeline from '@/components/StatusTimeline';
import { transfers, statusLabels, statusColors } from '@/lib/data';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import {
  ArrowLeft,
  MapPin,
  Package,
  Weight,
  Calendar,
  Truck,
  ArrowRight,
} from 'lucide-react';

const MAP_IMG = 'https://mgx-backend-cdn.metadl.com/generate/images/980143/2026-02-20/b6676ceb-a46a-4992-871f-5d642c80e671.png';
const TRUCK_IMG = 'https://mgx-backend-cdn.metadl.com/generate/images/980143/2026-02-20/3dbd21ba-908a-4138-9d17-3285d0109bbc.png';

export default function TransferDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const transfer = transfers.find((t) => t.id === id);

  if (!transfer) {
    return (
      <div className="min-h-screen bg-[#F8FAFC]">
        <Sidebar />
        <main className="ml-64 flex items-center justify-center min-h-screen">
          <div className="text-center">
            <Package className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-slate-700 mb-2">Transferencia no encontrada</h2>
            <p className="text-sm text-slate-500 mb-4">La transferencia que buscas no existe.</p>
            <Button onClick={() => navigate('/')} variant="outline">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Volver a la lista
            </Button>
          </div>
        </main>
      </div>
    );
  }

  const sc = statusColors[transfer.status];

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      <Sidebar />
      <main className="ml-64">
        {/* Header */}
        <div className="bg-white border-b border-slate-200 px-8 py-5">
          <div className="flex items-center gap-4 mb-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/')}
              className="text-slate-500 hover:text-slate-700"
            >
              <ArrowLeft className="w-4 h-4 mr-1" />
              Volver
            </Button>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-3 mb-1">
                <h1 className="text-2xl font-bold text-slate-800">{transfer.trackingNumber}</h1>
                <Badge className={cn('text-xs font-semibold px-3 py-1 rounded-full border-0', sc.bg, sc.text)}>
                  {statusLabels[transfer.status]}
                </Badge>
              </div>
              <p className="text-sm text-slate-500">ID: {transfer.id} · Transportista: {transfer.carrier}</p>
            </div>
          </div>
        </div>

        <div className="px-8 py-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - Info */}
            <div className="lg:col-span-1 space-y-6">
              {/* Route Card */}
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                <div className="relative h-36">
                  <img src={MAP_IMG} alt="Route map" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute bottom-3 left-4 right-4">
                    <div className="flex items-center gap-2 text-white">
                      <span className="text-sm font-semibold">{transfer.origin}</span>
                      <ArrowRight className="w-4 h-4 flex-shrink-0" />
                      <span className="text-sm font-semibold">{transfer.destination}</span>
                    </div>
                  </div>
                </div>
                <div className="p-5 space-y-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-2 h-2 rounded-full bg-blue-500" />
                      <span className="text-xs font-semibold text-slate-500 uppercase">Origen</span>
                    </div>
                    <p className="text-sm font-medium text-slate-800 ml-4">{transfer.origin}</p>
                    <p className="text-xs text-slate-500 ml-4">{transfer.originAddress}</p>
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-2 h-2 rounded-full bg-green-500" />
                      <span className="text-xs font-semibold text-slate-500 uppercase">Destino</span>
                    </div>
                    <p className="text-sm font-medium text-slate-800 ml-4">{transfer.destination}</p>
                    <p className="text-xs text-slate-500 ml-4">{transfer.destinationAddress}</p>
                  </div>
                </div>
              </div>

              {/* Details Card */}
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5 space-y-4">
                <h3 className="text-sm font-semibold text-slate-800 flex items-center gap-2">
                  <Package className="w-4 h-4 text-blue-500" />
                  Detalles del Envío
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-500 flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5" />
                      Fecha de Creación
                    </span>
                    <span className="text-sm font-medium text-slate-700">{transfer.createdAt}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-500 flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5" />
                      Entrega Estimada
                    </span>
                    <span className="text-sm font-medium text-slate-700">{transfer.estimatedDelivery}</span>
                  </div>
                  {transfer.actualDelivery && (
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-slate-500 flex items-center gap-2">
                        <Calendar className="w-3.5 h-3.5" />
                        Entrega Real
                      </span>
                      <span className="text-sm font-medium text-green-600">{transfer.actualDelivery}</span>
                    </div>
                  )}
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-500 flex items-center gap-2">
                      <Weight className="w-3.5 h-3.5" />
                      Peso Total
                    </span>
                    <span className="text-sm font-medium text-slate-700">{transfer.totalWeight} kg</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-500 flex items-center gap-2">
                      <Truck className="w-3.5 h-3.5" />
                      Transportista
                    </span>
                    <span className="text-sm font-medium text-slate-700">{transfer.carrier}</span>
                  </div>
                </div>
              </div>

              {/* Products Card */}
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
                <h3 className="text-sm font-semibold text-slate-800 mb-4 flex items-center gap-2">
                  <Package className="w-4 h-4 text-blue-500" />
                  Productos ({transfer.products.length})
                </h3>
                <div className="space-y-3">
                  {transfer.products.map((product, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between p-3 bg-slate-50 rounded-lg"
                    >
                      <div>
                        <p className="text-sm font-medium text-slate-700">{product.name}</p>
                        <p className="text-xs text-slate-500">Cantidad: {product.quantity}</p>
                      </div>
                      <span className="text-xs font-medium text-slate-600 bg-white px-2.5 py-1 rounded-full border border-slate-200">
                        {product.weight} kg
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Column - Timeline */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-semibold text-slate-800">Historial de Movimientos</h3>
                  <img
                    src={TRUCK_IMG}
                    alt="Delivery truck"
                    className="w-20 h-12 object-cover rounded-lg opacity-80"
                  />
                </div>

                {/* Progress Bar */}
                <div className="mb-8">
                  <div className="flex items-center justify-between mb-2">
                    {['Recogido', 'En Tránsito', 'Centro Dist.', 'En Camino', 'Entregado'].map(
                      (label, idx) => {
                        const statusOrder = ['pendiente', 'en_transito', 'en_centro', 'en_camino', 'entregado'];
                        const currentIdx =
                          transfer.status === 'cancelado' ? -1 : statusOrder.indexOf(transfer.status);
                        const isActive = idx <= currentIdx;
                        return (
                          <div key={label} className="flex flex-col items-center flex-1">
                            <div
                              className={cn(
                                'w-3 h-3 rounded-full mb-1 transition-all',
                                isActive ? 'bg-blue-500 shadow-md shadow-blue-500/30' : 'bg-slate-200'
                              )}
                            />
                            <span
                              className={cn(
                                'text-[10px] font-medium text-center',
                                isActive ? 'text-blue-600' : 'text-slate-400'
                              )}
                            >
                              {label}
                            </span>
                          </div>
                        );
                      }
                    )}
                  </div>
                  <div className="relative h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="absolute left-0 top-0 h-full bg-gradient-to-r from-blue-500 to-blue-400 rounded-full transition-all duration-500"
                      style={{
                        width:
                          transfer.status === 'cancelado'
                            ? '0%'
                            : `${
                                (['pendiente', 'en_transito', 'en_centro', 'en_camino', 'entregado'].indexOf(
                                  transfer.status
                                ) /
                                  4) *
                                100
                              }%`,
                      }}
                    />
                  </div>
                </div>

                {/* Timeline */}
                <StatusTimeline events={transfer.timeline} currentStatus={transfer.status} />
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}