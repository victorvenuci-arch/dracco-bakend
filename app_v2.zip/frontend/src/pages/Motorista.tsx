import { useState } from 'react';
import Sidebar from '@/components/Sidebar';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { Search, Phone, MapPin, Truck, Star, UserCircle } from 'lucide-react';

interface Driver {
  id: string;
  name: string;
  photo: string;
  phone: string;
  license: string;
  vehicle: string;
  vehiclePlate: string;
  status: 'disponible' | 'en_ruta' | 'descanso' | 'inactivo';
  rating: number;
  totalDeliveries: number;
  currentRoute?: string;
  location: string;
}

const statusLabels: Record<string, string> = {
  disponible: 'Disponible',
  en_ruta: 'En Ruta',
  descanso: 'Descanso',
  inactivo: 'Inactivo',
};

const statusColors: Record<string, { bg: string; text: string }> = {
  disponible: { bg: 'bg-green-100', text: 'text-green-700' },
  en_ruta: { bg: 'bg-blue-100', text: 'text-blue-700' },
  descanso: { bg: 'bg-amber-100', text: 'text-amber-700' },
  inactivo: { bg: 'bg-slate-100', text: 'text-slate-500' },
};

const drivers: Driver[] = [
  {
    id: 'DRV-001',
    name: 'Carlos Hernández',
    photo: '',
    phone: '+52 55 1234 5678',
    license: 'LIC-MX-4521',
    vehicle: 'Kenworth T680',
    vehiclePlate: 'ABC-123-MX',
    status: 'en_ruta',
    rating: 4.8,
    totalDeliveries: 342,
    currentRoute: 'Monterrey → Puebla',
    location: 'San Luis Potosí',
  },
  {
    id: 'DRV-002',
    name: 'María López García',
    photo: '',
    phone: '+52 33 9876 5432',
    license: 'LIC-MX-7832',
    vehicle: 'Freightliner Cascadia',
    vehiclePlate: 'DEF-456-MX',
    status: 'disponible',
    rating: 4.9,
    totalDeliveries: 518,
    location: 'Ciudad de México',
  },
  {
    id: 'DRV-003',
    name: 'Roberto Martínez',
    photo: '',
    phone: '+52 81 5555 1234',
    license: 'LIC-MX-3219',
    vehicle: 'International LT',
    vehiclePlate: 'GHI-789-MX',
    status: 'en_ruta',
    rating: 4.6,
    totalDeliveries: 275,
    currentRoute: 'Tijuana → Cancún',
    location: 'Guadalajara',
  },
  {
    id: 'DRV-004',
    name: 'Ana Sofía Ramírez',
    photo: '',
    phone: '+52 222 3333 4444',
    license: 'LIC-MX-9045',
    vehicle: 'Volvo VNL 860',
    vehiclePlate: 'JKL-012-MX',
    status: 'descanso',
    rating: 4.7,
    totalDeliveries: 189,
    location: 'Querétaro',
  },
  {
    id: 'DRV-005',
    name: 'José Antonio Pérez',
    photo: '',
    phone: '+52 614 7777 8888',
    license: 'LIC-MX-1567',
    vehicle: 'Peterbilt 579',
    vehiclePlate: 'MNO-345-MX',
    status: 'en_ruta',
    rating: 4.5,
    totalDeliveries: 410,
    currentRoute: 'Hermosillo → Chihuahua',
    location: 'Delicias',
  },
  {
    id: 'DRV-006',
    name: 'Fernando Díaz',
    photo: '',
    phone: '+52 477 2222 3333',
    license: 'LIC-MX-6789',
    vehicle: 'Mack Anthem',
    vehiclePlate: 'PQR-678-MX',
    status: 'inactivo',
    rating: 4.3,
    totalDeliveries: 156,
    location: 'León',
  },
];

export default function MotoristaPage() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const filteredDrivers = drivers.filter((d) => {
    const matchesSearch =
      !search.trim() ||
      d.name.toLowerCase().includes(search.toLowerCase()) ||
      d.vehiclePlate.toLowerCase().includes(search.toLowerCase()) ||
      d.location.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === 'all' || d.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const stats = [
    { label: 'Total', value: drivers.length, color: 'from-blue-500 to-blue-600' },
    { label: 'En Ruta', value: drivers.filter((d) => d.status === 'en_ruta').length, color: 'from-indigo-500 to-blue-500' },
    { label: 'Disponibles', value: drivers.filter((d) => d.status === 'disponible').length, color: 'from-green-500 to-emerald-500' },
    { label: 'Descanso', value: drivers.filter((d) => d.status === 'descanso').length, color: 'from-amber-500 to-orange-500' },
  ];

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      <Sidebar />
      <main className="ml-64">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#0F172A] to-[#1E293B] px-8 py-8">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-sm flex items-center justify-center">
              <UserCircle className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">Motoristas</h1>
              <p className="text-slate-400 text-sm">Gestión y seguimiento de conductores</p>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {stats.map((stat) => (
              <div
                key={stat.label}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/5"
              >
                <p className="text-2xl font-bold text-white">{stat.value}</p>
                <p className="text-xs text-slate-400">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="px-8 py-6">
          {/* Search and Filters */}
          <div className="flex flex-col sm:flex-row gap-3 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Buscar por nombre, placa o ubicación..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10 bg-white border-slate-200 focus:border-blue-400 focus:ring-blue-400/20"
              />
            </div>
            <div className="flex gap-1.5 flex-wrap">
              {['all', 'disponible', 'en_ruta', 'descanso', 'inactivo'].map((s) => (
                <button
                  key={s}
                  onClick={() => setStatusFilter(s)}
                  className={cn(
                    'text-xs h-8 px-3 rounded-full font-medium transition-all border',
                    statusFilter === s
                      ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-500/20'
                      : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                  )}
                >
                  {s === 'all' ? 'Todos' : statusLabels[s]}
                </button>
              ))}
            </div>
          </div>

          {/* Driver Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredDrivers.length === 0 ? (
              <div className="col-span-full bg-white rounded-xl border border-slate-200 p-12 text-center">
                <UserCircle className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                <p className="text-sm text-slate-500">No se encontraron motoristas</p>
              </div>
            ) : (
              filteredDrivers.map((driver) => {
                const sc = statusColors[driver.status];
                return (
                  <div
                    key={driver.id}
                    className="bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-all duration-200 hover:-translate-y-0.5 overflow-hidden"
                  >
                    <div className="p-5">
                      <div className="flex items-start gap-4 mb-4">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center flex-shrink-0 shadow-md">
                          <span className="text-white font-bold text-sm">
                            {driver.name
                              .split(' ')
                              .map((n) => n[0])
                              .slice(0, 2)
                              .join('')}
                          </span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="text-sm font-semibold text-slate-800 truncate">
                            {driver.name}
                          </h3>
                          <p className="text-xs text-slate-500">{driver.id} · {driver.license}</p>
                        </div>
                        <Badge
                          className={cn(
                            'text-[10px] font-semibold px-2 py-0.5 rounded-full border-0 flex-shrink-0',
                            sc.bg,
                            sc.text
                          )}
                        >
                          {statusLabels[driver.status]}
                        </Badge>
                      </div>

                      <div className="space-y-2.5">
                        <div className="flex items-center gap-2 text-xs text-slate-600">
                          <Truck className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                          <span>
                            {driver.vehicle} · <span className="font-mono">{driver.vehiclePlate}</span>
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-slate-600">
                          <Phone className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                          <span>{driver.phone}</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-slate-600">
                          <MapPin className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                          <span>{driver.location}</span>
                        </div>
                        {driver.currentRoute && (
                          <div className="bg-blue-50 rounded-lg px-3 py-2 text-xs text-blue-700 font-medium">
                            🚛 Ruta: {driver.currentRoute}
                          </div>
                        )}
                      </div>

                      <div className="flex items-center justify-between mt-4 pt-3 border-t border-slate-100">
                        <div className="flex items-center gap-1">
                          <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                          <span className="text-xs font-semibold text-slate-700">{driver.rating}</span>
                        </div>
                        <span className="text-xs text-slate-500">
                          {driver.totalDeliveries} entregas
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </main>
    </div>
  );
}