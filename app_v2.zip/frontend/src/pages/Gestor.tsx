import { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import Sidebar from '@/components/Sidebar';
import { useProfile } from '@/hooks/useProfile';
import { client } from '@/lib/api';
import { cn } from '@/lib/utils';
import { cidadeStatusLabels, cidadeStatusColors, cidadeStatusIcons, veiculoTipos, timelineEventConfig } from '@/lib/types';
import type { Cidade, Pacote, CidadeStatus, PerfilUsuario, VeiculoTipo, ResumoTriagem, Rota, TimelineEventItem, TimelineEventType } from '@/lib/types';
import { entityUpdate, entityDelete } from '@/lib/apiHelpers';
import { toast } from 'sonner';
import {
  LayoutDashboard,
  MapPin,
  Loader2,
  RefreshCw,
  Truck,
  CheckCircle2,
  ScanLine,
  Users,
  Send,
  Package,
  Plus,
  AlertCircle,
  UserPlus,
  ClipboardList,
  UserCheck,
  Eye,
  Image,
  Upload,
  X,
  Activity,
  Trash2,
} from 'lucide-react';

type GestorTab = 'dashboard' | 'resumos' | 'auxiliares' | 'entregadores' | 'rota' | 'importar';

export default function GestorPage() {
  const navigate = useNavigate();
  const { user, profile, loading, logout, clearProfile } = useProfile();
  const [cidades, setCidades] = useState<Cidade[]>([]);
  const [pacotes, setPacotes] = useState<Pacote[]>([]);
  const [allProfiles, setAllProfiles] = useState<PerfilUsuario[]>([]);
  const [resumos, setResumos] = useState<ResumoTriagem[]>([]);
  const [rotas, setRotas] = useState<Rota[]>([]);
  const [loadingData, setLoadingData] = useState(false);
  const [activeTab, setActiveTab] = useState<GestorTab>('dashboard');

  // Timeline
  const [timelineEvents, setTimelineEvents] = useState<TimelineEventItem[]>([]);

  // Auxiliar
  const [auxiliarNome, setAuxiliarNome] = useState('');
  const [savingAuxiliar, setSavingAuxiliar] = useState(false);

  // Entregador
  const [entregadorNome, setEntregadorNome] = useState('');
  const [entregadorCidade, setEntregadorCidade] = useState<number | ''>('');
  const [savingEntregador, setSavingEntregador] = useState(false);

  // Motorista
  const [motoristaNome, setMotoristaNome] = useState('');
  const [savingMotorista, setSavingMotorista] = useState(false);

  // Rota
  const [selectedMotorista, setSelectedMotorista] = useState('');
  const [selectedMotoristaNome, setSelectedMotoristaNome] = useState('');
  const [selectedVeiculo, setSelectedVeiculo] = useState<VeiculoTipo | ''>('');
  const [selectedCidadesRota, setSelectedCidadesRota] = useState<number[]>([]);
  const [dispatching, setDispatching] = useState(false);

  // VER PACOTES modal
  const [viewingResumo, setViewingResumo] = useState<ResumoTriagem | null>(null);
  const [resumoPacotes, setResumoPacotes] = useState<Pacote[]>([]);
  const [loadingResumoPacotes, setLoadingResumoPacotes] = useState(false);

  // GERAR IMAGEM
  const imageRef = useRef<HTMLDivElement>(null);
  const [generatingImage, setGeneratingImage] = useState(false);

  // XLS Import
  const [importingXls, setImportingXls] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Delete
  const [deletingId, setDeletingId] = useState<number | null>(null);

  const addTimelineEvent = useCallback((type: TimelineEventType, message: string, actor: string, cidade?: string) => {
    const evt: TimelineEventItem = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      type,
      message,
      actor,
      cidade,
      timestamp: new Date().toISOString(),
    };
    setTimelineEvents((prev) => [evt, ...prev].slice(0, 50));
  }, []);

  const loadData = useCallback(async () => {
    setLoadingData(true);
    try {
      const [cidadesRes, pacotesRes, profilesRes, resumosRes, rotasRes] = await Promise.all([
        client.entities.cidades.query({ query: {}, limit: 50 }),
        client.entities.pacotes.query({ query: {}, limit: 500 }),
        client.entities.perfis_usuarios.queryAll({ query: {}, limit: 200 }),
        client.entities.resumos_triagem.queryAll({ query: {}, limit: 100, sort: '-created_at' }),
        client.entities.rotas.queryAll({ query: {}, limit: 50, sort: '-created_at' }),
      ]);
      setCidades((cidadesRes?.data?.items || []) as Cidade[]);
      setPacotes((pacotesRes?.data?.items || []) as Pacote[]);
      setAllProfiles((profilesRes?.data?.items || []) as PerfilUsuario[]);
      setResumos((resumosRes?.data?.items || []) as ResumoTriagem[]);
      setRotas((rotasRes?.data?.items || []) as Rota[]);
    } catch {
      // ignore
    } finally {
      setLoadingData(false);
    }
  }, []);

  // Auto-refresh every 30 seconds
  useEffect(() => {
    if (user && profile) {
      loadData();
      const interval = setInterval(loadData, 30000);
      return () => clearInterval(interval);
    }
  }, [user, profile, loadData]);

  useEffect(() => {
    if (!loading && user && !profile) {
      navigate('/', { replace: true });
    } else if (!loading && user && profile && profile.perfil !== 'GESTOR') {
      navigate('/', { replace: true });
    }
  }, [loading, user, profile, navigate]);

  // Build timeline from data
  useEffect(() => {
    const events: TimelineEventItem[] = [];
    for (const r of resumos.slice(0, 15)) {
      events.push({
        id: `triagem-${r.id}`,
        type: 'TRIAGEM_FINALIZADA',
        message: `Triagem finalizada: ${r.quantidade_pacotes} pacotes para ${r.cidade_nome}`,
        actor: r.auxiliar_responsavel,
        cidade: r.cidade_nome,
        timestamp: r.created_at,
      });
    }
    for (const rt of rotas.slice(0, 10)) {
      events.push({
        id: `rota-${rt.id}`,
        type: 'CIDADE_ENVIADA_ROTA',
        message: `Rota criada: ${rt.cidades_nomes} com ${rt.motorista_nome}`,
        actor: rt.motorista_nome,
        cidade: rt.cidades_nomes,
        timestamp: rt.created_at,
      });
    }
    for (const c of cidades) {
      if (c.status === 'ENTREGUE_AO_ENTREGADOR') {
        events.push({
          id: `entregue-${c.id}`,
          type: 'ENTREGADOR_CONFIRMOU',
          message: `Entregador confirmou recebimento: ${c.nome}`,
          actor: c.entregador_padrao_nome || 'Entregador',
          cidade: c.nome,
          timestamp: c.created_at,
        });
      }
      if (c.status === 'AGUARDANDO_CONFIRMACAO_ENTREGADOR') {
        events.push({
          id: `finalizado-${c.id}`,
          type: 'MOTORISTA_FINALIZOU',
          message: `Motorista finalizou bipagem: ${c.nome}`,
          actor: c.motorista_nome || 'Motorista',
          cidade: c.nome,
          timestamp: c.created_at,
        });
      }
    }
    events.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    setTimelineEvents(events.slice(0, 50));
  }, [resumos, rotas, cidades]);

  // Toggle user active/inactive
  const handleToggleUserActive = async (p: PerfilUsuario) => {
    if (p.perfil === 'ADMINISTRADOR' || p.perfil === 'GESTOR') {
      toast.error('Sem permissão para alterar este perfil');
      return;
    }
    try {
      await entityUpdate('perfis_usuarios', p.id, { ativo: !p.ativo });
      toast.success(`Usuário "${p.nome}" ${!p.ativo ? 'ativado' : 'desativado'}`);
      await loadData();
    } catch {
      toast.error('Erro ao atualizar usuário');
    }
  };

  const handleAddAuxiliar = async () => {
    if (!auxiliarNome.trim()) return;
    setSavingAuxiliar(true);
    try {
      await client.entities.perfis_usuarios.create({
        data: { nome: auxiliarNome.trim(), perfil: 'AUXILIAR', cidade_vinculada_id: 0, cidade_vinculada_nome: '', ativo: true },
      });
      toast.success(`Auxiliar "${auxiliarNome}" cadastrado`);
      setAuxiliarNome('');
      await loadData();
    } catch {
      toast.error('Erro ao cadastrar auxiliar');
    } finally {
      setSavingAuxiliar(false);
    }
  };

  const handleAddMotorista = async () => {
    if (!motoristaNome.trim()) return;
    setSavingMotorista(true);
    try {
      await client.entities.perfis_usuarios.create({
        data: { nome: motoristaNome.trim(), perfil: 'MOTORISTA', cidade_vinculada_id: 0, cidade_vinculada_nome: '', ativo: true },
      });
      toast.success(`Motorista "${motoristaNome}" cadastrado`);
      setMotoristaNome('');
      await loadData();
    } catch {
      toast.error('Erro ao cadastrar motorista');
    } finally {
      setSavingMotorista(false);
    }
  };

  const handleAssignEntregador = async () => {
    if (!entregadorNome.trim() || !entregadorCidade) return;
    setSavingEntregador(true);
    try {
      const cidadeId = Number(entregadorCidade);
      const cidade = cidades.find((c) => c.id === cidadeId);
      if (!cidade) return;
      await entityUpdate('cidades', cidadeId, {
        entregador_padrao_nome: entregadorNome.trim(),
        entregador_padrao_id: entregadorNome.trim().toLowerCase().replace(/\s+/g, '_'),
      });
      toast.success(`Entregador "${entregadorNome}" vinculado a ${cidade.nome}`);
      setEntregadorNome('');
      setEntregadorCidade('');
      await loadData();
    } catch {
      toast.error('Erro ao vincular entregador');
    } finally {
      setSavingEntregador(false);
    }
  };

  const handleCriarRota = async () => {
    if (!selectedMotorista || !selectedVeiculo || selectedCidadesRota.length === 0) return;
    setDispatching(true);
    try {
      const cidadesNomes = selectedCidadesRota.map((id) => cidades.find((c) => c.id === id)?.nome || '').join(', ');

      await client.entities.rotas.create({
        data: {
          motorista_id: selectedMotorista,
          motorista_nome: selectedMotoristaNome,
          veiculo_tipo: selectedVeiculo,
          cidades_ids: selectedCidadesRota.join(','),
          cidades_nomes: cidadesNomes,
          status: 'EM_ROTA',
          created_at: new Date().toISOString(),
        },
      });

      for (const cidadeId of selectedCidadesRota) {
        await entityUpdate('cidades', cidadeId, {
          status: 'EM_ROTA',
          motorista_id: selectedMotorista,
          motorista_nome: selectedMotoristaNome,
          veiculo_tipo: selectedVeiculo,
        });

        // Update resumos_triagem status to EM_ROTA
        const cidadeResumos = resumos.filter((r) => r.cidade_id === cidadeId && r.status === 'AGUARDANDO_DESPACHO');
        for (const r of cidadeResumos) {
          try {
            await entityUpdate('resumos_triagem', r.id, { status: 'EM_ROTA' });
          } catch {
            // ignore
          }
        }
      }

      addTimelineEvent('CIDADE_ENVIADA_ROTA', `Rota criada: ${cidadesNomes}`, selectedMotoristaNome, cidadesNomes);
      toast.success(`Rota criada para ${selectedCidadesRota.length} cidade(s) com ${selectedMotoristaNome}`);
      setSelectedMotorista('');
      setSelectedMotoristaNome('');
      setSelectedVeiculo('');
      setSelectedCidadesRota([]);
      await loadData();
    } catch {
      toast.error('Erro ao criar rota');
    } finally {
      setDispatching(false);
    }
  };

  const handleEnviarParaRota = (resumo: ResumoTriagem) => {
    setSelectedCidadesRota((prev) =>
      prev.includes(resumo.cidade_id) ? prev : [...prev, resumo.cidade_id]
    );
    setActiveTab('rota');
    toast.info(`Cidade "${resumo.cidade_nome}" adicionada à seleção de rota`);
  };

  const toggleCidadeRota = (cidadeId: number) => {
    setSelectedCidadesRota((prev) =>
      prev.includes(cidadeId) ? prev.filter((id) => id !== cidadeId) : [...prev, cidadeId]
    );
  };

  // Delete triagem
  const handleDeleteTriagem = async (resumo: ResumoTriagem) => {
    if (!confirm(`Excluir triagem de "${resumo.cidade_nome}" (${resumo.quantidade_pacotes} pacotes)?`)) return;
    setDeletingId(resumo.id);
    try {
      // Delete associated pacotes with AGUARDANDO_DESPACHO
      const pacotesRes = await client.entities.pacotes.query({
        query: { cidade_id: resumo.cidade_id, status: 'AGUARDANDO_DESPACHO' },
        limit: 500,
      });
      const pkgs = (pacotesRes?.data?.items || []) as { id: number }[];
      for (const pkg of pkgs) {
        try {
          await entityDelete('pacotes', pkg.id);
        } catch {
          // ignore
        }
      }
      await entityDelete('resumos_triagem', resumo.id);
      toast.success(`Triagem de "${resumo.cidade_nome}" excluída`);
      await loadData();
    } catch {
      toast.error('Erro ao excluir triagem');
    } finally {
      setDeletingId(null);
    }
  };

  // VER PACOTES
  const handleViewPacotes = async (resumo: ResumoTriagem) => {
    setViewingResumo(resumo);
    setLoadingResumoPacotes(true);
    try {
      const res = await client.entities.pacotes.query({
        query: { cidade_id: resumo.cidade_id },
        limit: 500,
      });
      setResumoPacotes((res?.data?.items || []) as Pacote[]);
    } catch {
      setResumoPacotes([]);
    } finally {
      setLoadingResumoPacotes(false);
    }
  };

  // GERAR IMAGEM
  const handleGerarImagem = async (resumo: ResumoTriagem) => {
    setViewingResumo(resumo);
    setGeneratingImage(true);
    try {
      const res = await client.entities.pacotes.query({
        query: { cidade_id: resumo.cidade_id },
        limit: 500,
      });
      const pkgs = (res?.data?.items || []) as Pacote[];
      setResumoPacotes(pkgs);

      await new Promise((r) => setTimeout(r, 500));

      const el = imageRef.current;
      if (!el) {
        toast.error('Erro ao gerar imagem');
        setGeneratingImage(false);
        return;
      }

      const html2canvas = (await import('html2canvas')).default;
      const canvas = await html2canvas(el, {
        backgroundColor: '#0F172A',
        scale: 2,
        useCORS: true,
      });

      const link = document.createElement('a');
      link.download = `DRACCO_Triagem_${resumo.cidade_nome}_${new Date().toISOString().split('T')[0]}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
      toast.success('Imagem gerada e baixada!');
    } catch {
      toast.error('Erro ao gerar imagem');
    } finally {
      setGeneratingImage(false);
    }
  };

  // XLS Import
  const handleXlsImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImportingXls(true);
    try {
      const XLSX = await import('xlsx');
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data);
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json<{ codigo_rastreio?: string; cidade?: string; data_vencimento?: string }>(sheet);

      if (rows.length === 0) {
        toast.error('Planilha vazia');
        setImportingXls(false);
        return;
      }

      let created = 0;
      let duplicates = 0;
      let errors = 0;

      for (const row of rows) {
        const codigo = String(row.codigo_rastreio || '').trim();
        const cidadeNome = String(row.cidade || '').trim();
        const vencimento = String(row.data_vencimento || '').trim();

        if (!codigo || !cidadeNome) {
          errors++;
          continue;
        }

        const cidade = cidades.find((c) => c.nome.toLowerCase() === cidadeNome.toLowerCase());
        if (!cidade) {
          errors++;
          continue;
        }

        // Block if city is EM_ROTA
        if (cidade.status === 'EM_ROTA') {
          errors++;
          continue;
        }

        // Check duplicate
        const existing = pacotes.find((p) => p.codigo_rastreio === codigo);
        if (existing) {
          duplicates++;
          continue;
        }

        try {
          await client.entities.pacotes.create({
            data: {
              codigo_rastreio: codigo,
              cidade_id: cidade.id,
              cidade_nome: cidade.nome,
              data_vencimento: vencimento,
              auxiliar_responsavel: 'Importação XLS',
              status: 'AGUARDANDO_DESPACHO',
              created_at: new Date().toISOString(),
            },
          });
          created++;
        } catch {
          duplicates++;
        }
      }

      addTimelineEvent('XLS_IMPORTADO', `Importação XLS: ${created} pacotes criados`, profile?.nome || 'Gestor');
      toast.success(`Importação concluída: ${created} criados, ${duplicates} duplicados, ${errors} erros`);
      await loadData();
    } catch {
      toast.error('Erro ao processar planilha');
    } finally {
      setImportingXls(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  if (loading || !user || !profile) {
    return (
      <div className="min-h-screen bg-[#0F172A] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
      </div>
    );
  }

  const totalPacotes = pacotes.length;
  const motoristaProfiles = allProfiles.filter((p) => p.perfil === 'MOTORISTA' && p.ativo !== false);
  const auxiliarProfiles = allProfiles.filter((p) => p.perfil === 'AUXILIAR');
  const cidadesParaRota = cidades.filter((c) => c.status === 'AGUARDANDO_DESPACHO');
  const resumosAguardando = resumos.filter((r) => r.status === 'AGUARDANDO_DESPACHO');

  // Status counts
  const statusCounts: Record<string, number> = {};
  for (const c of cidades) {
    statusCounts[c.status] = (statusCounts[c.status] || 0) + 1;
  }

  // Vencendo hoje
  const today = new Date().toISOString().split('T')[0];
  const vencendoHoje = pacotes.filter((p) => p.data_vencimento === today && p.status === 'AGUARDANDO_DESPACHO').length;

  // Today's routes
  const todayRoutes = rotas.filter((r) => {
    try {
      return r.created_at?.startsWith(today);
    } catch {
      return false;
    }
  });

  const getCidadePacotes = (cidadeId: number) => pacotes.filter((p) => p.cidade_id === cidadeId);

  const formatDate = (d: string) => {
    if (!d) return '—';
    try {
      return new Date(d).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
    } catch {
      return d;
    }
  };

  const formatTime = (d: string) => {
    if (!d) return '—';
    try {
      return new Date(d).toLocaleString('pt-BR', { timeStyle: 'short' });
    } catch {
      return d;
    }
  };

  const tabs: { key: GestorTab; label: string; icon: typeof Package; badge?: number }[] = [
    { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { key: 'resumos', label: 'Resumos', icon: ClipboardList, badge: resumosAguardando.length },
    { key: 'auxiliares', label: 'Equipe', icon: Users },
    { key: 'entregadores', label: 'Entregadores', icon: UserPlus },
    { key: 'rota', label: 'Criar Rota', icon: Send },
    { key: 'importar', label: 'Importar XLS', icon: Upload },
  ];

  const dashboardCards = [
    { label: 'AGUARDANDO_DESPACHO', count: statusCounts['AGUARDANDO_DESPACHO'] || 0, icon: '📦', color: 'from-slate-600 to-slate-700', textColor: 'text-slate-300' },
    { label: 'EM_ROTA', count: statusCounts['EM_ROTA'] || 0, icon: '🚚', color: 'from-blue-600 to-blue-700', textColor: 'text-blue-300' },
    { label: 'AGUARDANDO_CONFIRMAÇÃO', count: statusCounts['AGUARDANDO_CONFIRMACAO_ENTREGADOR'] || 0, icon: '📍', color: 'from-purple-600 to-purple-700', textColor: 'text-purple-300' },
    { label: 'ENTREGUE', count: statusCounts['ENTREGUE_AO_ENTREGADOR'] || 0, icon: '✅', color: 'from-green-600 to-green-700', textColor: 'text-green-300' },
    { label: 'VENCENDO HOJE', count: vencendoHoje, icon: '⚠️', color: 'from-amber-600 to-amber-700', textColor: 'text-amber-300' },
  ];

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      <Sidebar profileType={profile.perfil} profileName={profile.nome} onLogout={logout} onSwitchProfile={clearProfile} />
      <main className="ml-64">
        <div className="bg-gradient-to-r from-[#0F172A] to-[#1E293B] px-8 py-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-sm flex items-center justify-center">
                <LayoutDashboard className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">Central Logística</h1>
                <p className="text-slate-400 text-sm">DRACCO — Painel do Gestor</p>
              </div>
            </div>
            <button onClick={() => loadData()} disabled={loadingData} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/10 text-white text-sm hover:bg-white/20 transition-all">
              <RefreshCw className={cn('w-4 h-4', loadingData && 'animate-spin')} />
              Atualizar
            </button>
          </div>
          <div className="flex gap-1 bg-white/5 rounded-xl p-1 overflow-x-auto">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  className={cn(
                    'flex-1 flex items-center justify-center gap-1.5 px-2 py-2.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap',
                    activeTab === tab.key ? 'bg-white/15 text-white shadow-sm' : 'text-slate-400 hover:text-white hover:bg-white/5'
                  )}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span className="hidden xl:inline">{tab.label}</span>
                  {tab.badge && tab.badge > 0 ? (
                    <span className="text-[10px] bg-amber-500 text-white px-1.5 py-0.5 rounded-full font-bold">{tab.badge}</span>
                  ) : null}
                </button>
              );
            })}
          </div>
        </div>

        <div className="px-8 py-6">
          {/* DASHBOARD */}
          {activeTab === 'dashboard' && (
            <>
              {/* Status Cards */}
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
                {dashboardCards.map((card) => (
                  <div key={card.label} className={cn('rounded-xl p-5 bg-gradient-to-br text-white shadow-lg', card.color)}>
                    <div className="text-3xl mb-2">{card.icon}</div>
                    <p className="text-3xl font-bold">{card.count}</p>
                    <p className={cn('text-xs mt-1 font-medium', card.textColor)}>{card.label}</p>
                  </div>
                ))}
              </div>

              {/* Triagens Recentes + Rotas do Dia */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
                  <h3 className="text-sm font-semibold text-slate-800 mb-4 flex items-center gap-2">
                    <ClipboardList className="w-4 h-4 text-cyan-500" />
                    Triagens Recentes
                  </h3>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {resumos.slice(0, 8).map((r) => (
                      <div key={r.id} className="flex items-center justify-between py-2 px-3 rounded-lg bg-slate-50">
                        <div className="flex items-center gap-3">
                          <MapPin className="w-3.5 h-3.5 text-slate-400" />
                          <div>
                            <p className="text-xs font-medium text-slate-700">{r.cidade_nome}</p>
                            <p className="text-[10px] text-slate-500">{r.auxiliar_responsavel}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-bold text-slate-800">{r.quantidade_pacotes}</p>
                          <p className="text-[10px] text-slate-500">{formatDate(r.created_at)}</p>
                        </div>
                      </div>
                    ))}
                    {resumos.length === 0 && (
                      <p className="text-xs text-slate-500 text-center py-4">Nenhuma triagem recente</p>
                    )}
                  </div>
                </div>

                <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
                  <h3 className="text-sm font-semibold text-slate-800 mb-4 flex items-center gap-2">
                    <Truck className="w-4 h-4 text-blue-500" />
                    Rotas do Dia
                  </h3>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {todayRoutes.map((r) => (
                      <div key={r.id} className="flex items-center justify-between py-2 px-3 rounded-lg bg-slate-50">
                        <div>
                          <p className="text-xs font-medium text-slate-700">{r.motorista_nome}</p>
                          <p className="text-[10px] text-slate-500">{r.veiculo_tipo} — {r.cidades_nomes}</p>
                        </div>
                        <span className={cn('text-[10px] font-semibold px-2 py-1 rounded-full', r.status === 'EM_ROTA' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700')}>
                          {r.status}
                        </span>
                      </div>
                    ))}
                    {todayRoutes.length === 0 && (
                      <p className="text-xs text-slate-500 text-center py-4">Nenhuma rota criada hoje</p>
                    )}
                  </div>
                </div>
              </div>

              {/* Timeline ao vivo */}
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 mb-6">
                <h3 className="text-sm font-semibold text-slate-800 mb-4 flex items-center gap-2">
                  <Activity className="w-4 h-4 text-emerald-500" />
                  Timeline ao Vivo
                  <span className="flex items-center gap-1 ml-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="text-[10px] text-emerald-600 font-normal">Auto-refresh 30s</span>
                  </span>
                </h3>
                <div className="space-y-2 max-h-72 overflow-y-auto">
                  {timelineEvents.slice(0, 20).map((evt) => {
                    const config = timelineEventConfig[evt.type];
                    return (
                      <div key={evt.id} className={cn('flex items-start gap-3 py-2.5 px-3 rounded-lg', config.bgColor)}>
                        <span className="text-lg flex-shrink-0 mt-0.5">{config.icon}</span>
                        <div className="flex-1 min-w-0">
                          <p className={cn('text-xs font-medium', config.color)}>{evt.message}</p>
                          <p className="text-[10px] text-slate-500 mt-0.5">
                            {evt.actor} · {formatTime(evt.timestamp)}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                  {timelineEvents.length === 0 && (
                    <p className="text-xs text-slate-500 text-center py-4">Nenhum evento registrado</p>
                  )}
                </div>
              </div>

              {/* Cidades */}
              <h2 className="text-lg font-semibold text-slate-800 mb-4">Cidades</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {cidades.map((cidade) => {
                  const cidadePacotes = getCidadePacotes(cidade.id);
                  const cidadeBipados = cidadePacotes.filter((p) => p.status === 'BIPADO');
                  const total = cidadePacotes.length;
                  const bipCount = cidadeBipados.length;
                  const pct = total > 0 ? Math.round((bipCount / total) * 100) : 0;
                  const sc = cidadeStatusColors[cidade.status as CidadeStatus] || cidadeStatusColors.AGUARDANDO_DESPACHO;
                  const icon = cidadeStatusIcons[cidade.status as CidadeStatus] || '📦';

                  return (
                    <div key={cidade.id} className="bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-all overflow-hidden">
                      <div className="p-5">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-500 to-cyan-600 flex items-center justify-center text-lg">
                              {icon}
                            </div>
                            <div>
                              <h3 className="text-sm font-semibold text-slate-800">{cidade.nome}</h3>
                              <p className="text-xs text-slate-500">Entregador: {cidade.entregador_padrao_nome || '—'}</p>
                            </div>
                          </div>
                          <span className={cn('text-[10px] font-semibold px-2 py-1 rounded-full', sc.bg, sc.text)}>
                            {cidadeStatusLabels[cidade.status as CidadeStatus] || cidade.status}
                          </span>
                        </div>
                        <div className="mb-3">
                          <div className="flex items-center justify-between text-xs mb-1">
                            <span className="text-slate-500">Pacotes</span>
                            <span className="font-semibold text-slate-700">{total}</span>
                          </div>
                          <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                            <div className="h-full bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-full transition-all duration-500" style={{ width: `${pct}%` }} />
                          </div>
                        </div>
                        <div className="flex items-center justify-between text-xs text-slate-500">
                          <div className="flex items-center gap-1">
                            <ScanLine className="w-3 h-3" />
                            <span>{total} pacotes</span>
                          </div>
                          {cidade.motorista_nome && (
                            <div className="flex items-center gap-1">
                              <Truck className="w-3 h-3" />
                              <span>{cidade.motorista_nome}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}

          {/* RESUMOS */}
          {activeTab === 'resumos' && (
            <div className="max-w-3xl">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-500 to-teal-600 flex items-center justify-center">
                  <ClipboardList className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-slate-800">Resumos Recebidos do Auxiliar</h2>
                  <p className="text-xs text-slate-500">Triagens finalizadas — VER PACOTES, GERAR IMAGEM ou EXCLUIR</p>
                </div>
              </div>

              {resumos.length === 0 ? (
                <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-8 text-center">
                  <ClipboardList className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                  <p className="text-slate-500">Nenhum resumo de triagem recebido</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {resumos.map((resumo) => {
                    const isAguardando = resumo.status === 'AGUARDANDO_DESPACHO';
                    return (
                      <div key={resumo.id} className="bg-white rounded-xl border border-slate-200 shadow-sm p-5 hover:shadow-md transition-all">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-500 to-cyan-600 flex items-center justify-center">
                              <MapPin className="w-5 h-5 text-white" />
                            </div>
                            <div>
                              <h3 className="text-sm font-semibold text-slate-800">{resumo.cidade_nome}</h3>
                              <p className="text-xs text-slate-500">Responsável: {resumo.auxiliar_responsavel}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className={cn(
                              'text-[10px] font-semibold px-2 py-1 rounded-full',
                              isAguardando ? 'bg-amber-100 text-amber-700' : 'bg-blue-100 text-blue-700'
                            )}>
                              {resumo.status}
                            </span>
                            <button
                              onClick={() => handleDeleteTriagem(resumo)}
                              disabled={deletingId === resumo.id}
                              className="p-1.5 rounded-lg text-red-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                              title="Excluir triagem"
                            >
                              {deletingId === resumo.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                            </button>
                          </div>
                        </div>

                        <div className="grid grid-cols-3 gap-3 mb-4">
                          <div className="bg-slate-50 rounded-lg p-3 text-center">
                            <p className="text-2xl font-bold text-slate-800">{resumo.quantidade_pacotes}</p>
                            <p className="text-[10px] text-slate-500">Pacotes</p>
                          </div>
                          <div className="bg-slate-50 rounded-lg p-3 text-center">
                            <p className="text-sm font-semibold text-slate-700">{resumo.data_vencimento || '—'}</p>
                            <p className="text-[10px] text-slate-500">Vencimento</p>
                          </div>
                          <div className="bg-slate-50 rounded-lg p-3 text-center">
                            <p className="text-xs font-medium text-slate-700">{formatDate(resumo.created_at)}</p>
                            <p className="text-[10px] text-slate-500">Data/Hora</p>
                          </div>
                        </div>

                        {/* Action buttons */}
                        <div className="flex gap-2 mb-3">
                          <button onClick={() => handleViewPacotes(resumo)} className="flex-1 py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 bg-cyan-600 text-white hover:bg-cyan-700 transition-all">
                            <Eye className="w-4 h-4" />
                            VER PACOTES
                          </button>
                          <button onClick={() => handleGerarImagem(resumo)} disabled={generatingImage} className="flex-1 py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 bg-indigo-600 text-white hover:bg-indigo-700 transition-all">
                            {generatingImage ? <Loader2 className="w-4 h-4 animate-spin" /> : <Image className="w-4 h-4" />}
                            GERAR IMAGEM
                          </button>
                        </div>

                        {isAguardando && (
                          <button onClick={() => handleEnviarParaRota(resumo)} className="w-full py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 bg-amber-600 text-white hover:bg-amber-700 shadow-lg shadow-amber-500/20 transition-all">
                            <Send className="w-4 h-4" />
                            ENVIAR PARA ROTA
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* EQUIPE (Auxiliares, Motoristas, toggle active) */}
          {activeTab === 'auxiliares' && (
            <div className="max-w-2xl space-y-6">
              {/* Add Auxiliar */}
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
                <h2 className="text-lg font-semibold text-slate-800 mb-4">Cadastrar Auxiliar</h2>
                <div className="flex gap-3">
                  <input type="text" value={auxiliarNome} onChange={(e) => setAuxiliarNome(e.target.value)} placeholder="Nome do auxiliar..." className="flex-1 px-4 py-2.5 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50" />
                  <button onClick={handleAddAuxiliar} disabled={savingAuxiliar || !auxiliarNome.trim()} className={cn('px-6 py-2.5 rounded-lg font-bold text-sm flex items-center gap-2 transition-all', auxiliarNome.trim() && !savingAuxiliar ? 'bg-emerald-600 text-white hover:bg-emerald-700' : 'bg-slate-100 text-slate-400 cursor-not-allowed')}>
                    {savingAuxiliar ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                    Cadastrar
                  </button>
                </div>
                <div className="mt-4 space-y-2">
                  {auxiliarProfiles.map((a) => (
                    <div key={a.id} className="flex items-center justify-between py-2 px-3 rounded-lg bg-slate-50">
                      <span className="text-sm text-slate-700">{a.nome}</span>
                      <button onClick={() => handleToggleUserActive(a)} className={cn('text-xs font-semibold px-2 py-1 rounded-full cursor-pointer transition-colors', a.ativo !== false ? 'bg-green-100 text-green-700 hover:bg-green-200' : 'bg-red-100 text-red-700 hover:bg-red-200')}>
                        {a.ativo !== false ? 'Ativo' : 'Inativo'}
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Add Motorista */}
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
                <h2 className="text-lg font-semibold text-slate-800 mb-4">Cadastrar Motorista</h2>
                <div className="flex gap-3">
                  <input type="text" value={motoristaNome} onChange={(e) => setMotoristaNome(e.target.value)} placeholder="Nome do motorista..." className="flex-1 px-4 py-2.5 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50" />
                  <button onClick={handleAddMotorista} disabled={savingMotorista || !motoristaNome.trim()} className={cn('px-6 py-2.5 rounded-lg font-bold text-sm flex items-center gap-2 transition-all', motoristaNome.trim() && !savingMotorista ? 'bg-emerald-600 text-white hover:bg-emerald-700' : 'bg-slate-100 text-slate-400 cursor-not-allowed')}>
                    {savingMotorista ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                    Cadastrar
                  </button>
                </div>
                <div className="mt-4 space-y-2">
                  {motoristaProfiles.map((m) => (
                    <div key={m.id} className="flex items-center justify-between py-2 px-3 rounded-lg bg-slate-50">
                      <span className="text-sm text-slate-700">{m.nome}</span>
                      <button onClick={() => handleToggleUserActive(m)} className={cn('text-xs font-semibold px-2 py-1 rounded-full cursor-pointer transition-colors', m.ativo !== false ? 'bg-green-100 text-green-700 hover:bg-green-200' : 'bg-red-100 text-red-700 hover:bg-red-200')}>
                        {m.ativo !== false ? 'Ativo' : 'Inativo'}
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* All operational users */}
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
                <h3 className="text-sm font-semibold text-slate-700 mb-3 flex items-center gap-2">
                  <UserCheck className="w-4 h-4 text-emerald-500" />
                  Equipe Operacional
                </h3>
                <div className="space-y-2">
                  {allProfiles.filter((p) => ['AUXILIAR', 'MOTORISTA', 'ENTREGADOR'].includes(p.perfil)).map((p) => (
                    <div key={p.id} className="flex items-center justify-between py-2 px-3 rounded-lg bg-slate-50">
                      <div>
                        <p className="text-sm text-slate-700">{p.nome}</p>
                        <p className="text-[10px] text-slate-500">{p.perfil} {p.cidade_vinculada_nome ? `— ${p.cidade_vinculada_nome}` : ''}</p>
                      </div>
                      <button onClick={() => handleToggleUserActive(p)} className={cn('text-xs font-semibold px-2 py-1 rounded-full cursor-pointer transition-colors', p.ativo !== false ? 'bg-green-100 text-green-700 hover:bg-green-200' : 'bg-red-100 text-red-700 hover:bg-red-200')}>
                        {p.ativo !== false ? 'Ativo' : 'Inativo'}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ENTREGADORES */}
          {activeTab === 'entregadores' && (
            <div className="max-w-2xl">
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 mb-6">
                <h2 className="text-lg font-semibold text-slate-800 mb-4">Definir Entregador por Cidade</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">Nome do Entregador</label>
                    <input type="text" value={entregadorNome} onChange={(e) => setEntregadorNome(e.target.value)} placeholder="Nome..." className="w-full px-3 py-2.5 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">Cidade</label>
                    <select value={entregadorCidade} onChange={(e) => setEntregadorCidade(Number(e.target.value) || '')} className="w-full px-3 py-2.5 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50">
                      <option value="">Selecione...</option>
                      {cidades.map((c) => (<option key={c.id} value={c.id}>{c.nome}</option>))}
                    </select>
                  </div>
                </div>
                <button onClick={handleAssignEntregador} disabled={savingEntregador || !entregadorNome.trim() || !entregadorCidade} className={cn('w-full py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all', entregadorNome.trim() && entregadorCidade && !savingEntregador ? 'bg-emerald-600 text-white hover:bg-emerald-700' : 'bg-slate-100 text-slate-400 cursor-not-allowed')}>
                  {savingEntregador ? <Loader2 className="w-4 h-4 animate-spin" /> : <UserPlus className="w-4 h-4" />}
                  Vincular Entregador
                </button>
              </div>
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
                <h3 className="text-sm font-semibold text-slate-700 mb-3">Entregadores por Cidade</h3>
                <div className="space-y-2">
                  {cidades.map((c) => (
                    <div key={c.id} className="flex items-center justify-between py-3 px-4 rounded-lg bg-slate-50">
                      <div>
                        <p className="text-sm font-medium text-slate-800">{c.nome}</p>
                        <p className="text-xs text-slate-500">{c.entregador_padrao_nome ? `Entregador: ${c.entregador_padrao_nome}` : 'Sem entregador'}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* CRIAR ROTA */}
          {activeTab === 'rota' && (
            <div className="max-w-2xl">
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
                    <Send className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h2 className="text-lg font-semibold text-slate-800">Criar Rota Diária</h2>
                    <p className="text-xs text-slate-500">Selecione motorista, veículo e cidades</p>
                  </div>
                </div>

                <div className="mb-4">
                  <label className="block text-xs font-medium text-slate-600 mb-1">Motorista</label>
                  <select value={selectedMotorista} onChange={(e) => { setSelectedMotorista(e.target.value); const mp = motoristaProfiles.find((p) => p.user_id === e.target.value); setSelectedMotoristaNome(mp?.nome || ''); }} className="w-full px-3 py-2.5 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50">
                    <option value="">Selecione um motorista...</option>
                    {motoristaProfiles.map((mp) => (<option key={mp.user_id} value={mp.user_id}>{mp.nome}</option>))}
                  </select>
                  {motoristaProfiles.length === 0 && (
                    <p className="text-xs text-amber-600 mt-1 flex items-center gap-1"><AlertCircle className="w-3 h-3" />Nenhum motorista cadastrado</p>
                  )}
                </div>

                <div className="mb-4">
                  <label className="block text-xs font-medium text-slate-600 mb-1">Tipo de Veículo</label>
                  <select value={selectedVeiculo} onChange={(e) => setSelectedVeiculo(e.target.value as VeiculoTipo)} className="w-full px-3 py-2.5 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50">
                    <option value="">Selecione...</option>
                    {veiculoTipos.map((v) => (<option key={v} value={v}>{v}</option>))}
                  </select>
                </div>

                <div className="mb-4">
                  <label className="block text-xs font-medium text-slate-600 mb-2">Cidades (AGUARDANDO_DESPACHO)</label>
                  {cidadesParaRota.length === 0 ? (
                    <p className="text-xs text-slate-500 py-4 text-center bg-slate-50 rounded-lg">Nenhuma cidade com status AGUARDANDO_DESPACHO</p>
                  ) : (
                    <div className="space-y-2">
                      {cidadesParaRota.map((c) => {
                        const isSelected = selectedCidadesRota.includes(c.id);
                        const pkgCount = getCidadePacotes(c.id).length;
                        return (
                          <button key={c.id} onClick={() => toggleCidadeRota(c.id)} className={cn('w-full flex items-center justify-between py-3 px-4 rounded-lg border transition-all text-left', isSelected ? 'bg-emerald-50 border-emerald-300 shadow-sm' : 'bg-slate-50 border-slate-200 hover:border-slate-300')}>
                            <div className="flex items-center gap-3">
                              <div className={cn('w-5 h-5 rounded border-2 flex items-center justify-center transition-all', isSelected ? 'bg-emerald-500 border-emerald-500' : 'border-slate-300')}>
                                {isSelected && <CheckCircle2 className="w-3 h-3 text-white" />}
                              </div>
                              <div>
                                <p className="text-sm font-medium text-slate-800">{c.nome}</p>
                                <p className="text-xs text-slate-500">{pkgCount} pacotes</p>
                              </div>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>

                <button onClick={handleCriarRota} disabled={dispatching || !selectedMotorista || !selectedVeiculo || selectedCidadesRota.length === 0} className={cn('w-full py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all', selectedMotorista && selectedVeiculo && selectedCidadesRota.length > 0 && !dispatching ? 'bg-amber-600 text-white hover:bg-amber-700 shadow-lg shadow-amber-500/20' : 'bg-slate-100 text-slate-400 cursor-not-allowed')}>
                  {dispatching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  {dispatching ? 'Criando Rota...' : `Criar Rota (${selectedCidadesRota.length} cidades)`}
                </button>
              </div>
            </div>
          )}

          {/* IMPORTAR XLS */}
          {activeTab === 'importar' && (
            <div className="max-w-2xl">
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
                    <Upload className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h2 className="text-lg font-semibold text-slate-800">Importar Pacotes via XLS</h2>
                    <p className="text-xs text-slate-500">Formato: codigo_rastreio | cidade | data_vencimento</p>
                  </div>
                </div>

                <div className="bg-slate-50 rounded-xl p-6 border-2 border-dashed border-slate-300 text-center mb-4">
                  <Upload className="w-10 h-10 text-slate-400 mx-auto mb-3" />
                  <p className="text-sm text-slate-600 mb-3">Arraste ou selecione um arquivo .xlsx / .xls</p>
                  <input ref={fileInputRef} type="file" accept=".xlsx,.xls,.csv" onChange={handleXlsImport} className="hidden" id="xls-upload" />
                  <button onClick={() => fileInputRef.current?.click()} disabled={importingXls} className={cn('px-6 py-3 rounded-xl font-bold text-sm flex items-center gap-2 mx-auto transition-all', !importingXls ? 'bg-indigo-600 text-white hover:bg-indigo-700' : 'bg-slate-200 text-slate-400 cursor-not-allowed')}>
                    {importingXls ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                    {importingXls ? 'Importando...' : 'Selecionar Arquivo'}
                  </button>
                </div>

                <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
                  <h4 className="text-xs font-semibold text-amber-800 mb-2">📋 Formato esperado da planilha:</h4>
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead>
                        <tr className="border-b border-amber-200">
                          <th className="text-left py-1 px-2 text-amber-700">codigo_rastreio</th>
                          <th className="text-left py-1 px-2 text-amber-700">cidade</th>
                          <th className="text-left py-1 px-2 text-amber-700">data_vencimento</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td className="py-1 px-2 font-mono text-amber-600">TBR123456789BR</td>
                          <td className="py-1 px-2 text-amber-600">Cidade A</td>
                          <td className="py-1 px-2 text-amber-600">2026-02-25</td>
                        </tr>
                        <tr>
                          <td className="py-1 px-2 font-mono text-amber-600">TBR987654321BR</td>
                          <td className="py-1 px-2 text-amber-600">Cidade B</td>
                          <td className="py-1 px-2 text-amber-600">2026-02-28</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <p className="text-[10px] text-amber-600 mt-2">
                    ⚠️ Duplicados existentes serão ignorados. Cidades devem estar cadastradas previamente.
                    Cidades EM_ROTA serão bloqueadas. Pacotes criados com status AGUARDANDO_DESPACHO.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* VER PACOTES Modal */}
      {viewingResumo && !generatingImage && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={() => setViewingResumo(null)}>
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[80vh] overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="bg-gradient-to-r from-[#0F172A] to-[#1E293B] px-6 py-4 flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold text-white">{viewingResumo.cidade_nome}</h3>
                <p className="text-xs text-slate-400">{viewingResumo.quantidade_pacotes} pacotes — {viewingResumo.auxiliar_responsavel}</p>
              </div>
              <button onClick={() => setViewingResumo(null)} className="p-2 rounded-lg text-white/60 hover:text-white hover:bg-white/10 transition-all">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 overflow-y-auto max-h-[60vh]">
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="bg-slate-50 rounded-lg p-3 text-center">
                  <p className="text-2xl font-bold text-slate-800">{viewingResumo.quantidade_pacotes}</p>
                  <p className="text-[10px] text-slate-500">Pacotes</p>
                </div>
                <div className="bg-slate-50 rounded-lg p-3 text-center">
                  <p className="text-sm font-semibold text-slate-700">{viewingResumo.data_vencimento || '—'}</p>
                  <p className="text-[10px] text-slate-500">Vencimento</p>
                </div>
              </div>
              {loadingResumoPacotes ? (
                <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 text-emerald-500 animate-spin" /></div>
              ) : (
                <div className="space-y-1">
                  <h4 className="text-xs font-semibold text-slate-600 mb-2">Lista Completa de Pacotes:</h4>
                  {resumoPacotes.map((p, idx) => (
                    <div key={p.id} className="flex items-center justify-between py-2 px-3 rounded-lg bg-slate-50">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-slate-400 w-6">{idx + 1}.</span>
                        <Package className="w-3.5 h-3.5 text-slate-400" />
                        <span className="text-xs font-mono text-slate-700">{p.codigo_rastreio}</span>
                      </div>
                      <span className={cn('text-[10px] font-semibold px-2 py-0.5 rounded-full', p.status === 'BIPADO' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-600')}>
                        {p.status}
                      </span>
                    </div>
                  ))}
                  {resumoPacotes.length === 0 && (
                    <p className="text-xs text-slate-500 text-center py-4">Nenhum pacote encontrado</p>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* GERAR IMAGEM - Hidden render target */}
      {generatingImage && viewingResumo && (
        <div className="fixed left-[-9999px] top-0">
          <div ref={imageRef} className="w-[600px] bg-[#0F172A] p-8 text-white">
            <div className="flex items-center gap-4 mb-6 pb-4 border-b border-white/10">
              <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-emerald-500 to-cyan-400 flex items-center justify-center">
                <span className="text-2xl">🚚</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold">DRACCO</h1>
                <p className="text-sm text-slate-400">Sistema Logístico — Resumo de Triagem</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                <p className="text-xs text-slate-400">Cidade</p>
                <p className="text-lg font-bold">{viewingResumo.cidade_nome}</p>
              </div>
              <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                <p className="text-xs text-slate-400">Quantidade</p>
                <p className="text-lg font-bold">{viewingResumo.quantidade_pacotes} pacotes</p>
              </div>
              <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                <p className="text-xs text-slate-400">Responsável</p>
                <p className="text-lg font-bold">{viewingResumo.auxiliar_responsavel}</p>
              </div>
              <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                <p className="text-xs text-slate-400">Data</p>
                <p className="text-lg font-bold">{formatDate(viewingResumo.created_at)}</p>
              </div>
            </div>
            <div className="bg-white/5 rounded-xl p-4 border border-white/10">
              <h3 className="text-sm font-semibold text-emerald-400 mb-3">Lista de Pacotes</h3>
              <div className="space-y-1">
                {resumoPacotes.map((p, idx) => (
                  <div key={p.id} className="flex items-center gap-2 py-1.5 px-2 rounded bg-white/5">
                    <span className="text-[10px] text-slate-500 w-6">{idx + 1}.</span>
                    <span className="text-xs font-mono text-white">{p.codigo_rastreio}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="mt-6 pt-4 border-t border-white/10 text-center">
              <p className="text-[10px] text-slate-500">Gerado em {new Date().toLocaleString('pt-BR')} — DRACCO v1.0</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}