import { useState, useEffect, useCallback } from 'react';
import { cn } from '@/lib/utils';
import { client } from '@/lib/api';
import { toast } from 'sonner';
import { listUsers, createUser, listTickets, updateTicket } from '@/lib/dracco-api';
import { LEVEL_LABELS, TICKET_STATUSES } from '@/lib/dracco-types';
import type { DraccoUserFull, Ticket, LoginResponse } from '@/lib/dracco-types';
import type { Cidade, Pacote, ResumoTriagem, Rota } from '@/lib/types';
import { entityUpdate, entityDelete } from '@/lib/apiHelpers';
import {
  LayoutDashboard, Users, MapPin, Loader2, RefreshCw, Truck, Plus, Trash2, Save,
  Search, UserPlus, TicketIcon, ClipboardList, Send, Package,
} from 'lucide-react';

type GerenteTab = 'dashboard' | 'usuarios' | 'triagens' | 'rotas' | 'busca' | 'tickets';

interface GerenteBaseProps {
  currentUser: LoginResponse;
  onLogout: () => void;
  onSwitchUser: () => void;
}

export default function GerenteBasePage({ currentUser, onLogout, onSwitchUser }: GerenteBaseProps) {
  const [activeTab, setActiveTab] = useState<GerenteTab>('dashboard');
  const [loadingData, setLoadingData] = useState(false);
  const [users, setUsers] = useState<DraccoUserFull[]>([]);
  const [cidades, setCidades] = useState<Cidade[]>([]);
  const [resumos, setResumos] = useState<ResumoTriagem[]>([]);
  const [rotas, setRotas] = useState<Rota[]>([]);
  const [tickets, setTickets] = useState<Ticket[]>([]);

  // Create user
  const [showCreate, setShowCreate] = useState(false);
  const [newUser, setNewUser] = useState({ nome: '', login: '', senha: '', level: 40, veiculo_tipo: '', login_amazon: '' });
  const [savingUser, setSavingUser] = useState(false);

  // TBR search
  const [tbrQuery, setTbrQuery] = useState('');
  const [tbrResults, setTbrResults] = useState<Pacote[]>([]);
  const [tbrSearched, setTbrSearched] = useState(false);
  const [searchingTbr, setSearchingTbr] = useState(false);

  const loadData = useCallback(async () => {
    setLoadingData(true);
    try {
      const [usersData, cidadesRes, resumosRes, rotasRes, ticketsData] = await Promise.all([
        listUsers(),
        client.entities.cidades.query({ query: {}, limit: 200 }),
        client.entities.resumos_triagem.queryAll({ query: {}, limit: 100, sort: '-created_at' }),
        client.entities.rotas.queryAll({ query: {}, limit: 50, sort: '-created_at' }),
        listTickets(currentUser.base_code),
      ]);
      setUsers(usersData);
      setCidades((cidadesRes?.data?.items || []) as Cidade[]);
      setResumos((resumosRes?.data?.items || []) as ResumoTriagem[]);
      setRotas((rotasRes?.data?.items || []) as Rota[]);
      setTickets(ticketsData);
    } catch { /* ignore */ }
    finally { setLoadingData(false); }
  }, [currentUser.base_code]);

  useEffect(() => { loadData(); }, [loadData]);

  const handleCreateUser = async () => {
    if (!newUser.nome.trim() || !newUser.login.trim() || !newUser.senha.trim()) return;
    setSavingUser(true);
    try {
      await createUser({
        nome: newUser.nome.trim(),
        login: newUser.login.trim(),
        senha: newUser.senha,
        level: newUser.level,
        base_code: currentUser.base_code,
        veiculo_tipo: newUser.veiculo_tipo,
        login_amazon: newUser.login_amazon,
      });
      toast.success(`Usuário "${newUser.nome}" criado`);
      setNewUser({ nome: '', login: '', senha: '', level: 40, veiculo_tipo: '', login_amazon: '' });
      setShowCreate(false);
      await loadData();
    } catch (err: any) {
      toast.error(err?.data?.detail || 'Erro ao criar');
    } finally { setSavingUser(false); }
  };

  const handleSearchTbr = async () => {
    if (!tbrQuery.trim()) return;
    setSearchingTbr(true);
    setTbrSearched(true);
    try {
      const res = await client.entities.pacotes.query({ query: { codigo_rastreio: tbrQuery.trim() }, limit: 10 });
      setTbrResults((res?.data?.items || []) as Pacote[]);
    } catch { setTbrResults([]); }
    finally { setSearchingTbr(false); }
  };

  const handleDeleteTriagem = async (r: ResumoTriagem) => {
    if (!confirm(`Excluir triagem de "${r.cidade_nome}"?`)) return;
    try {
      await entityDelete('resumos_triagem', r.id);
      toast.success('Triagem excluída');
      await loadData();
    } catch { toast.error('Erro'); }
  };

  const handleDeleteRota = async (r: Rota) => {
    if (!confirm(`Excluir rota de "${r.motorista_nome}"?`)) return;
    try {
      const cidadeIds = r.cidades_ids.split(',').map((id) => id.trim()).filter(Boolean);
      for (const cid of cidadeIds) {
        try { await entityUpdate('cidades', cid, { status: 'AGUARDANDO_DESPACHO', motorista_id: '', motorista_nome: '', veiculo_tipo: '' }); } catch { /* skip */ }
      }
      await entityDelete('rotas', r.id);
      toast.success('Rota excluída');
      await loadData();
    } catch { toast.error('Erro'); }
  };

  const handleTicketStatus = async (id: number, status: string) => {
    try { await updateTicket(id, status); toast.success('Atualizado'); await loadData(); }
    catch { toast.error('Erro'); }
  };

  const tabs: { key: GerenteTab; label: string; icon: typeof LayoutDashboard }[] = [
    { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { key: 'usuarios', label: 'Usuários', icon: Users },
    { key: 'triagens', label: 'Triagens', icon: ClipboardList },
    { key: 'rotas', label: 'Rotas', icon: Truck },
    { key: 'busca', label: 'Busca TBR', icon: Search },
    { key: 'tickets', label: 'Chamados', icon: TicketIcon },
  ];

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      <div className="bg-gradient-to-r from-[#0F172A] to-[#1E293B] px-4 sm:px-8 py-4 sm:py-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
              <LayoutDashboard className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg sm:text-2xl font-bold text-white">Gerente de Base</h1>
              <p className="text-slate-400 text-xs">{currentUser.nome} · Base {currentUser.base_code}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={loadData} disabled={loadingData} className="flex items-center gap-1 px-3 py-2 rounded-xl bg-white/10 text-white text-xs hover:bg-white/20">
              <RefreshCw className={cn('w-3.5 h-3.5', loadingData && 'animate-spin')} />
            </button>
            <button onClick={onSwitchUser} className="px-3 py-2 rounded-xl bg-white/10 text-slate-300 text-xs hover:bg-white/20">Trocar</button>
            <button onClick={onLogout} className="px-3 py-2 rounded-xl bg-red-500/20 text-red-300 text-xs hover:bg-red-500/30">Sair</button>
          </div>
        </div>
        <div className="flex gap-1 bg-white/5 rounded-xl p-1 overflow-x-auto">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button key={tab.key} onClick={() => setActiveTab(tab.key)}
                className={cn('flex-1 flex items-center justify-center gap-1.5 px-2 py-2.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap',
                  activeTab === tab.key ? 'bg-white/15 text-white shadow-sm' : 'text-slate-400 hover:text-white hover:bg-white/5')}>
                <Icon className="w-3.5 h-3.5" /><span className="hidden sm:inline">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="px-4 sm:px-8 py-6">
        {/* DASHBOARD */}
        {activeTab === 'dashboard' && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-3xl">
            <div className="bg-white rounded-xl border border-slate-200 p-4"><p className="text-xs text-slate-500">Cidades</p><p className="text-2xl font-bold text-slate-800">{cidades.length}</p></div>
            <div className="bg-white rounded-xl border border-slate-200 p-4"><p className="text-xs text-slate-500">Triagens</p><p className="text-2xl font-bold text-slate-800">{resumos.length}</p></div>
            <div className="bg-white rounded-xl border border-slate-200 p-4"><p className="text-xs text-slate-500">Rotas</p><p className="text-2xl font-bold text-slate-800">{rotas.length}</p></div>
            <div className="bg-white rounded-xl border border-slate-200 p-4"><p className="text-xs text-slate-500">Chamados</p><p className="text-2xl font-bold text-amber-600">{tickets.filter((t) => t.status === 'ABERTO').length}</p></div>
          </div>
        )}

        {/* USUARIOS */}
        {activeTab === 'usuarios' && (
          <div className="max-w-2xl">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-slate-800">Usuários da Base {currentUser.base_code}</h2>
              <button onClick={() => setShowCreate(!showCreate)} className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 text-white text-sm font-bold hover:bg-emerald-700">
                <UserPlus className="w-4 h-4" /> Novo
              </button>
            </div>
            {showCreate && (
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 mb-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
                  <input type="text" placeholder="Nome" value={newUser.nome} onChange={(e) => setNewUser({ ...newUser, nome: e.target.value })} className="px-3 py-2.5 rounded-lg border border-slate-200 text-sm" />
                  <input type="text" placeholder="Login" value={newUser.login} onChange={(e) => setNewUser({ ...newUser, login: e.target.value })} className="px-3 py-2.5 rounded-lg border border-slate-200 text-sm" />
                  <input type="password" placeholder="Senha" value={newUser.senha} onChange={(e) => setNewUser({ ...newUser, senha: e.target.value })} className="px-3 py-2.5 rounded-lg border border-slate-200 text-sm" />
                  <select value={newUser.level} onChange={(e) => setNewUser({ ...newUser, level: Number(e.target.value) })} className="px-3 py-2.5 rounded-lg border border-slate-200 text-sm">
                    <option value={40}>Auxiliar (40)</option>
                    <option value={30}>Motorista (30)</option>
                    <option value={20}>Entregador (20)</option>
                  </select>
                </div>
                <button onClick={handleCreateUser} disabled={savingUser} className={cn('w-full py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2', !savingUser ? 'bg-emerald-600 text-white hover:bg-emerald-700' : 'bg-slate-100 text-slate-400')}>
                  {savingUser ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} Criar
                </button>
              </div>
            )}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
              <div className="space-y-2">
                {users.map((u) => (
                  <div key={u.id} className="flex items-center justify-between py-3 px-4 rounded-lg bg-slate-50">
                    <div><p className="text-sm font-medium text-slate-800">{u.nome}</p><p className="text-xs text-slate-500">@{u.login} · {u.level_label}</p></div>
                    <span className={cn('text-xs font-semibold px-2 py-1 rounded-full', u.is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700')}>{u.is_active ? 'Ativo' : 'Inativo'}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TRIAGENS */}
        {activeTab === 'triagens' && (
          <div className="max-w-2xl">
            <h2 className="text-lg font-semibold text-slate-800 mb-4">Triagens Recentes ({resumos.length})</h2>
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
              <div className="space-y-2 max-h-[500px] overflow-y-auto">
                {resumos.map((r) => (
                  <div key={r.id} className="flex items-center justify-between py-3 px-4 rounded-lg bg-slate-50">
                    <div><p className="text-sm font-medium text-slate-800">{r.cidade_nome} — {r.quantidade_pacotes} pacotes</p><p className="text-xs text-slate-500">{r.auxiliar_responsavel} · {r.status}</p></div>
                    <button onClick={() => handleDeleteTriagem(r)} className="p-2 rounded-lg text-red-500 hover:bg-red-50"><Trash2 className="w-4 h-4" /></button>
                  </div>
                ))}
                {resumos.length === 0 && <p className="text-sm text-slate-500 text-center py-4">Nenhuma triagem</p>}
              </div>
            </div>
          </div>
        )}

        {/* ROTAS */}
        {activeTab === 'rotas' && (
          <div className="max-w-2xl">
            <h2 className="text-lg font-semibold text-slate-800 mb-4">Rotas ({rotas.length})</h2>
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
              <div className="space-y-2 max-h-[500px] overflow-y-auto">
                {rotas.map((r) => (
                  <div key={r.id} className="flex items-center justify-between py-3 px-4 rounded-lg bg-slate-50">
                    <div><p className="text-sm font-medium text-slate-800">{r.motorista_nome} — {r.veiculo_tipo}</p><p className="text-xs text-slate-500">{r.cidades_nomes} · {r.status}</p></div>
                    <button onClick={() => handleDeleteRota(r)} className="p-2 rounded-lg text-red-500 hover:bg-red-50"><Trash2 className="w-4 h-4" /></button>
                  </div>
                ))}
                {rotas.length === 0 && <p className="text-sm text-slate-500 text-center py-4">Nenhuma rota</p>}
              </div>
            </div>
          </div>
        )}

        {/* BUSCA TBR */}
        {activeTab === 'busca' && (
          <div className="max-w-2xl">
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
              <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2"><Search className="w-5 h-5 text-blue-500" /> Buscar Pacote por TBR</h2>
              <div className="flex gap-3 mb-4">
                <input type="text" value={tbrQuery} onChange={(e) => setTbrQuery(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSearchTbr()} placeholder="Digite o código TBR..."
                  className="flex-1 px-4 py-2.5 rounded-lg border border-slate-200 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-blue-500/50" />
                <button onClick={handleSearchTbr} disabled={searchingTbr || !tbrQuery.trim()}
                  className={cn('px-6 py-2.5 rounded-lg font-bold text-sm flex items-center gap-2', tbrQuery.trim() ? 'bg-blue-600 text-white hover:bg-blue-700' : 'bg-slate-100 text-slate-400 cursor-not-allowed')}>
                  {searchingTbr ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />} Buscar
                </button>
              </div>
              {tbrSearched && tbrResults.length === 0 && (
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-center">
                  <Package className="w-8 h-8 text-amber-400 mx-auto mb-2" />
                  <p className="text-sm text-amber-800 font-semibold">Este pacote não foi bipado por nenhum usuário.</p>
                </div>
              )}
              {tbrResults.map((p) => (
                <div key={p.id} className="bg-slate-50 rounded-xl p-4 mb-2">
                  <p className="text-sm font-bold text-slate-800 font-mono">{p.codigo_rastreio}</p>
                  <p className="text-xs text-slate-500">Cidade: {p.cidade_nome} · Status: {p.status} · Vencimento: {p.data_vencimento}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TICKETS */}
        {activeTab === 'tickets' && (
          <div className="max-w-2xl">
            <h2 className="text-lg font-semibold text-slate-800 mb-4">Chamados — Base {currentUser.base_code} ({tickets.length})</h2>
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
              <div className="space-y-2 max-h-[500px] overflow-y-auto">
                {tickets.map((t) => (
                  <div key={t.id} className="flex items-center justify-between py-3 px-4 rounded-lg bg-slate-50">
                    <div><p className="text-sm font-medium text-slate-800">TBR: <span className="font-mono">{t.tbr}</span></p><p className="text-xs text-slate-500">{t.motivo} · Por {t.created_by}</p></div>
                    <select value={t.status} onChange={(e) => handleTicketStatus(t.id, e.target.value)} className="text-xs px-2 py-1 rounded-lg border border-slate-200">
                      {TICKET_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                ))}
                {tickets.length === 0 && <p className="text-sm text-slate-500 text-center py-4">Nenhum chamado</p>}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}