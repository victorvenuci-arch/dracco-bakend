import { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import Sidebar from '@/components/Sidebar';
import { useProfile } from '@/hooks/useProfile';
import { client } from '@/lib/api';
import { cn } from '@/lib/utils';
import { cidadeStatusLabels, cidadeStatusColors } from '@/lib/types';
import type { Cidade, Pacote, CidadeStatus, Rota } from '@/lib/types';
import { entityUpdate } from '@/lib/apiHelpers';
import { toast } from 'sonner';
import {
  ScanLine,
  Loader2,
  MapPin,
  CheckCircle2,
  XCircle,
  Package,
  Truck,
  Camera,
  X,
  Keyboard,
  BarChart3,
  ArrowLeft,
} from 'lucide-react';

type MotoristaView = 'dashboard' | 'cidades' | 'scanner';

export default function ScannerMotoristaPage() {
  const navigate = useNavigate();
  const { user, profile, loading, logout, clearProfile } = useProfile();
  const [cidades, setCidades] = useState<Cidade[]>([]);
  const [allPacotes, setAllPacotes] = useState<Pacote[]>([]);
  const [rotas, setRotas] = useState<Rota[]>([]);
  const [loadingData, setLoadingData] = useState(false);
  const [view, setView] = useState<MotoristaView>('dashboard');

  // Scanner
  const [selectedCidade, setSelectedCidade] = useState<Cidade | null>(null);
  const [scanInput, setScanInput] = useState('');
  const [bipados, setBipados] = useState<string[]>([]);
  const [lastResult, setLastResult] = useState<{ ok: boolean; msg: string } | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Camera scanner
  const [cameraActive, setCameraActive] = useState(false);
  const html5QrCodeRef = useRef<any>(null);
  const [cameras, setCameras] = useState<{ id: string; label: string }[]>([]);
  const [selectedCameraId, setSelectedCameraId] = useState('');
  const [flashColor, setFlashColor] = useState<'green' | 'red' | null>(null);

  const triggerFlash = useCallback((color: 'green' | 'red') => {
    setFlashColor(color);
    setTimeout(() => setFlashColor(null), 300);
  }, []);

  const beepSuccess = useCallback(() => {
    try {
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.value = 1200;
      gain.gain.value = 0.3;
      osc.start();
      osc.stop(ctx.currentTime + 0.15);
    } catch { /* ignore */ }
  }, []);

  const beepError = useCallback(() => {
    try {
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.value = 300;
      gain.gain.value = 0.3;
      osc.start();
      osc.stop(ctx.currentTime + 0.3);
    } catch { /* ignore */ }
  }, []);

  const loadData = useCallback(async () => {
    setLoadingData(true);
    try {
      const [cidadesRes, pacotesRes, rotasRes] = await Promise.all([
        client.entities.cidades.query({ query: {}, limit: 50 }),
        client.entities.pacotes.query({ query: {}, limit: 1000 }),
        client.entities.rotas.queryAll({ query: {}, limit: 50, sort: '-created_at' }),
      ]);
      const cidadesData = (cidadesRes?.data?.items || []) as Cidade[];
      const pacotesData = (pacotesRes?.data?.items || []) as Pacote[];
      setCidades(cidadesData.filter((c) => c.status === 'EM_ROTA' || c.status === 'BIPAGEM_EM_ANDAMENTO'));
      setAllPacotes(pacotesData);
      setRotas((rotasRes?.data?.items || []) as Rota[]);
    } catch { /* ignore */ } finally {
      setLoadingData(false);
    }
  }, []);

  useEffect(() => {
    if (user && profile) loadData();
  }, [user, profile, loadData]);

  useEffect(() => {
    if (!loading && user && !profile) {
      navigate('/', { replace: true });
    } else if (!loading && user && profile && profile.perfil !== 'MOTORISTA') {
      navigate('/', { replace: true });
    }
  }, [loading, user, profile, navigate]);

  useEffect(() => {
    return () => {
      stopCamera();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const cidadePacotes = selectedCidade ? allPacotes.filter((p) => p.cidade_id === selectedCidade.id) : [];
  const cidadeBipados = cidadePacotes.filter((p) => p.status === 'BIPADO');
  const totalCidade = cidadePacotes.length;
  const bipCount = cidadeBipados.length + bipados.length;
  const allBipped = totalCidade > 0 && bipCount >= totalCidade;

  // Pacotes faltantes e conferidos
  const bipadosCodes = new Set([...cidadeBipados.map((p) => p.codigo_rastreio), ...bipados]);
  const pacotesFaltantes = cidadePacotes.filter((p) => !bipadosCodes.has(p.codigo_rastreio));
  const pacotesConferidos = cidadePacotes.filter((p) => bipadosCodes.has(p.codigo_rastreio));

  // Dashboard stats
  const allMyCidades = cidades;
  const totalPacotesMoto = allMyCidades.reduce((acc, c) => acc + allPacotes.filter((p) => p.cidade_id === c.id).length, 0);
  const totalBipadosMoto = allMyCidades.reduce((acc, c) => acc + allPacotes.filter((p) => p.cidade_id === c.id && p.status === 'BIPADO').length, 0);
  const cidadesFinalizadas = allMyCidades.filter((c) => c.status === 'AGUARDANDO_CONFIRMACAO_ENTREGADOR' || c.status === 'ENTREGUE_AO_ENTREGADOR').length;
  const progressoPct = totalPacotesMoto > 0 ? Math.round((totalBipadosMoto / totalPacotesMoto) * 100) : 0;

  // Today's route
  const today = new Date().toISOString().split('T')[0];
  const myRoute = rotas.find((r) => r.created_at?.startsWith(today));

  const getGPS = (): Promise<{ lat: number; lng: number }> =>
    new Promise((resolve) => {
      if (!navigator.geolocation) return resolve({ lat: 0, lng: 0 });
      navigator.geolocation.getCurrentPosition(
        (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        () => resolve({ lat: 0, lng: 0 }),
        { timeout: 5000 }
      );
    });

  const processScan = useCallback(async (code: string) => {
    if (!code.trim() || !selectedCidade) return;
    const trimmed = code.trim();

    const pacote = allPacotes.find((p) => p.codigo_rastreio === trimmed);
    if (!pacote) {
      beepError();
      triggerFlash('red');
      setLastResult({ ok: false, msg: 'Pacote não encontrado no sistema.' });
      toast.error('Pacote não encontrado');
      return;
    }

    if (pacote.cidade_id !== selectedCidade.id) {
      beepError();
      triggerFlash('red');
      setLastResult({ ok: false, msg: `Pacote não pertence a esta cidade. Pertence a: ${pacote.cidade_nome}` });
      toast.error('Pacote não pertence a esta cidade.');
      return;
    }

    if (pacote.status === 'BIPADO' || bipados.includes(trimmed)) {
      beepError();
      triggerFlash('red');
      setLastResult({ ok: false, msg: 'Pacote já registrado.' });
      toast.error('Pacote já registrado.');
      return;
    }

    beepSuccess();
    triggerFlash('green');
    setBipados((prev) => [...prev, trimmed]);
    setLastResult({ ok: true, msg: `✓ ${trimmed}` });

    try {
      await entityUpdate('pacotes', pacote.id, { status: 'BIPADO' });
      const gps = await getGPS();
      await client.entities.transferencias.create({
        data: {
          codigo_rastreio: trimmed,
          cidade_id: selectedCidade.id,
          cidade_nome: selectedCidade.nome,
          motorista_id: profile?.user_id || user?.id || '',
          motorista_nome: profile?.nome || '',
          data_hora: new Date().toISOString(),
          gps_lat: gps.lat,
          gps_lng: gps.lng,
        },
      });

      if (selectedCidade.status === 'EM_ROTA') {
        await entityUpdate('cidades', selectedCidade.id, { status: 'BIPAGEM_EM_ANDAMENTO' });
      }

      toast.success(`Bipagem: ${trimmed}`);
    } catch {
      toast.error('Erro ao registrar bipagem');
    }
  }, [allPacotes, selectedCidade, bipados, beepError, beepSuccess, triggerFlash, profile, user]);

  const handleScan = async (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key !== 'Enter' || !scanInput.trim()) return;
    await processScan(scanInput);
    setScanInput('');
  };

  const startCamera = useCallback(async (cameraId?: string) => {
    try {
      const { Html5Qrcode } = await import('html5-qrcode');
      const devices = await Html5Qrcode.getCameras();
      if (devices.length === 0) {
        toast.error('Nenhuma câmera encontrada');
        return;
      }

      const cameraList = devices.map((d) => ({ id: d.id, label: d.label || `Câmera ${d.id.slice(0, 8)}` }));
      setCameras(cameraList);

      let camId = cameraId || '';
      if (!camId) {
        const envCam = devices.find(
          (d) => d.label.toLowerCase().includes('back') || d.label.toLowerCase().includes('rear') || d.label.toLowerCase().includes('environment')
        );
        camId = envCam ? envCam.id : devices[0].id;
      }
      setSelectedCameraId(camId);

      if (html5QrCodeRef.current) {
        try {
          await html5QrCodeRef.current.stop();
          html5QrCodeRef.current.clear();
        } catch { /* ignore */ }
      }

      const html5QrCode = new Html5Qrcode('motorista-scanner-region');
      html5QrCodeRef.current = html5QrCode;

      await html5QrCode.start(
        camId,
        { fps: 10, qrbox: { width: 250, height: 250 }, aspectRatio: 1.0 },
        (decodedText: string) => {
          processScan(decodedText);
        },
        () => {}
      );

      setCameraActive(true);
    } catch {
      toast.error('Erro ao iniciar câmera. Verifique permissões e HTTPS.');
    }
  }, [processScan]);

  const stopCamera = useCallback(async () => {
    if (html5QrCodeRef.current) {
      try {
        await html5QrCodeRef.current.stop();
        html5QrCodeRef.current.clear();
      } catch { /* ignore */ }
      html5QrCodeRef.current = null;
    }
    setCameraActive(false);
  }, []);

  const handleSelectCidade = (c: Cidade) => {
    setSelectedCidade(c);
    setBipados([]);
    setLastResult(null);
    setView('scanner');
    // Auto-open camera after DOM renders
    setTimeout(() => {
      startCamera();
    }, 500);
  };

  const handleFinalizeCidade = async () => {
    if (!selectedCidade || !allBipped) return;
    try {
      await entityUpdate('cidades', selectedCidade.id, { status: 'AGUARDANDO_CONFIRMACAO_ENTREGADOR' });
      toast.success(`Cidade ${selectedCidade.nome} finalizada!`);
      await stopCamera();
      setSelectedCidade(null);
      setBipados([]);
      setView('dashboard');
      await loadData();
    } catch {
      toast.error('Erro ao finalizar cidade');
    }
  };

  if (loading || !user || !profile) {
    return (
      <div className="min-h-screen bg-[#0F172A] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] relative">
      {/* Flash overlay */}
      {flashColor && (
        <div
          className={cn(
            'fixed inset-0 z-[100] pointer-events-none transition-opacity duration-200',
            flashColor === 'green' ? 'bg-emerald-500/30' : 'bg-red-500/30'
          )}
        />
      )}

      <Sidebar profileType={profile.perfil} profileName={profile.nome} onLogout={logout} onSwitchProfile={clearProfile} />
      <main className="ml-64">
        <div className="bg-gradient-to-r from-[#0F172A] to-[#1E293B] px-8 py-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-sm flex items-center justify-center">
              <Truck className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">Dashboard Motorista</h1>
              <p className="text-slate-400 text-sm">DRACCO — {profile.nome}</p>
            </div>
          </div>
        </div>

        <div className="px-8 py-6">
          {/* DASHBOARD VIEW */}
          {view === 'dashboard' && (
            <div className="max-w-3xl mx-auto">
              {/* Route info */}
              {myRoute && (
                <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 mb-6">
                  <h3 className="text-sm font-semibold text-slate-800 mb-3 flex items-center gap-2">
                    <Truck className="w-4 h-4 text-blue-500" />
                    Rota do Dia
                  </h3>
                  <div className="grid grid-cols-3 gap-3">
                    <div className="bg-slate-50 rounded-lg p-3 text-center">
                      <p className="text-sm font-bold text-slate-800">{myRoute.motorista_nome}</p>
                      <p className="text-[10px] text-slate-500">Motorista</p>
                    </div>
                    <div className="bg-slate-50 rounded-lg p-3 text-center">
                      <p className="text-sm font-bold text-slate-800">{myRoute.veiculo_tipo}</p>
                      <p className="text-[10px] text-slate-500">Veículo</p>
                    </div>
                    <div className="bg-slate-50 rounded-lg p-3 text-center">
                      <p className="text-sm font-bold text-slate-800">{today}</p>
                      <p className="text-[10px] text-slate-500">Data</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Stats cards */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl p-5 text-white shadow-lg">
                  <MapPin className="w-6 h-6 mb-2 opacity-80" />
                  <p className="text-3xl font-bold">{allMyCidades.length}</p>
                  <p className="text-xs text-blue-200">Cidades Atribuídas</p>
                </div>
                <div className="bg-gradient-to-br from-green-600 to-green-700 rounded-xl p-5 text-white shadow-lg">
                  <CheckCircle2 className="w-6 h-6 mb-2 opacity-80" />
                  <p className="text-3xl font-bold">{cidadesFinalizadas}</p>
                  <p className="text-xs text-green-200">Cidades Finalizadas</p>
                </div>
                <div className="bg-gradient-to-br from-slate-600 to-slate-700 rounded-xl p-5 text-white shadow-lg">
                  <Package className="w-6 h-6 mb-2 opacity-80" />
                  <p className="text-3xl font-bold">{totalPacotesMoto}</p>
                  <p className="text-xs text-slate-300">Pacotes Totais</p>
                </div>
                <div className="bg-gradient-to-br from-cyan-600 to-cyan-700 rounded-xl p-5 text-white shadow-lg">
                  <ScanLine className="w-6 h-6 mb-2 opacity-80" />
                  <p className="text-3xl font-bold">{totalBipadosMoto}</p>
                  <p className="text-xs text-cyan-200">Pacotes Bipados</p>
                </div>
                <div className="bg-gradient-to-br from-amber-600 to-amber-700 rounded-xl p-5 text-white shadow-lg">
                  <Package className="w-6 h-6 mb-2 opacity-80" />
                  <p className="text-3xl font-bold">{totalPacotesMoto - totalBipadosMoto}</p>
                  <p className="text-xs text-amber-200">Pacotes Faltantes</p>
                </div>
                <div className="bg-gradient-to-br from-purple-600 to-purple-700 rounded-xl p-5 text-white shadow-lg">
                  <BarChart3 className="w-6 h-6 mb-2 opacity-80" />
                  <p className="text-3xl font-bold">{progressoPct}%</p>
                  <p className="text-xs text-purple-200">Progresso da Rota</p>
                </div>
              </div>

              {/* Progress bar */}
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 mb-6">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-semibold text-slate-800">Progresso da Rota</h3>
                  <span className="text-sm font-bold text-emerald-600">{progressoPct}%</span>
                </div>
                <div className="w-full h-4 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-full transition-all duration-700"
                    style={{ width: `${progressoPct}%` }}
                  />
                </div>
              </div>

              {/* Cities list */}
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-slate-800">Minhas Cidades</h2>
              </div>
              {loadingData ? (
                <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 text-emerald-500 animate-spin" /></div>
              ) : cidades.length === 0 ? (
                <div className="text-center py-12 text-slate-500">
                  <Truck className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                  <p>Nenhuma cidade em rota disponível</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {cidades.map((c) => {
                    const cPacotes = allPacotes.filter((p) => p.cidade_id === c.id);
                    const sc = cidadeStatusColors[c.status as CidadeStatus] || cidadeStatusColors.EM_ROTA;
                    return (
                      <button
                        key={c.id}
                        onClick={() => handleSelectCidade(c)}
                        className="w-full flex items-center justify-between p-4 rounded-xl bg-white border border-slate-200 shadow-sm hover:shadow-md transition-all text-left"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center">
                            <MapPin className="w-5 h-5 text-white" />
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-slate-800">{c.nome}</p>
                            <p className="text-xs text-slate-500">Pacotes: {cPacotes.length}</p>
                          </div>
                        </div>
                        <span className={cn('text-[10px] font-semibold px-2 py-1 rounded-full', sc.bg, sc.text)}>
                          {cidadeStatusLabels[c.status as CidadeStatus] || c.status}
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* SCANNER VIEW */}
          {view === 'scanner' && selectedCidade && (
            <div className="max-w-xl mx-auto">
              <button onClick={() => { stopCamera(); setSelectedCidade(null); setView('dashboard'); setBipados([]); }} className="text-sm text-blue-600 hover:text-blue-800 mb-4 flex items-center gap-1">
                <ArrowLeft className="w-4 h-4" />
                Voltar ao Dashboard
              </button>

              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 mb-4">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold text-slate-800">{selectedCidade.nome}</h2>
                  <span className="text-xs text-slate-500">Motorista: {profile.nome}</span>
                </div>

                {/* Counter - BIPADOS / TOTAL */}
                <div className="flex items-center justify-center py-6 mb-4 bg-gradient-to-br from-slate-50 to-slate-100 rounded-xl">
                  <div className="text-center">
                    <p className="text-5xl font-bold text-slate-800">{bipCount} <span className="text-2xl text-slate-400">/ {totalCidade}</span></p>
                    <p className="text-sm text-slate-500 mt-1">Pacotes bipados</p>
                  </div>
                </div>

                {/* Progress */}
                <div className="mb-4">
                  <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-full transition-all duration-500"
                      style={{ width: `${totalCidade > 0 ? Math.round((bipCount / totalCidade) * 100) : 0}%` }}
                    />
                  </div>
                </div>

                {/* Camera Scanner - Auto-open */}
                <div className="mb-4">
                  {!cameraActive ? (
                    <button
                      onClick={() => startCamera()}
                      className="w-full py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 bg-blue-600 text-white hover:bg-blue-700 shadow-lg shadow-blue-500/20 transition-all"
                    >
                      <Camera className="w-5 h-5" />
                      Abrir Scanner com Câmera
                    </button>
                  ) : (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-green-600 flex items-center gap-1">
                          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                          Câmera ativa — leitura contínua
                        </span>
                        <div className="flex items-center gap-2">
                          {cameras.length > 1 && (
                            <select
                              value={selectedCameraId}
                              onChange={async (e) => {
                                await stopCamera();
                                setTimeout(() => startCamera(e.target.value), 300);
                              }}
                              className="text-[10px] border border-slate-200 rounded-lg px-2 py-1"
                            >
                              {cameras.map((cam) => (
                                <option key={cam.id} value={cam.id}>{cam.label}</option>
                              ))}
                            </select>
                          )}
                          <button onClick={stopCamera} className="p-1.5 rounded-lg bg-red-50 text-red-500 hover:bg-red-100">
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                      <div id="motorista-scanner-region" className="w-full rounded-xl overflow-hidden" />
                    </div>
                  )}
                </div>

                {/* Manual Input */}
                <div className="mb-4">
                  <label className="flex items-center gap-2 text-xs font-medium text-slate-600 mb-1">
                    <Keyboard className="w-3.5 h-3.5" />
                    Digitar código manual (TBR)
                  </label>
                  <div className="flex gap-2">
                    <input
                      ref={inputRef}
                      type="text"
                      value={scanInput}
                      onChange={(e) => setScanInput(e.target.value)}
                      onKeyDown={handleScan}
                      placeholder="Escaneie ou digite o código..."
                      autoFocus
                      className="flex-1 px-4 py-3 rounded-xl border-2 border-blue-200 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 bg-blue-50/50"
                    />
                  </div>
                </div>

                {/* Last Result */}
                {lastResult && (
                  <div className={cn('flex items-center gap-2 p-3 rounded-lg mb-4', lastResult.ok ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700')}>
                    {lastResult.ok ? <CheckCircle2 className="w-5 h-5" /> : <XCircle className="w-5 h-5" />}
                    <span className="text-sm font-medium">{lastResult.msg}</span>
                  </div>
                )}

                {/* Finalize */}
                <button
                  onClick={handleFinalizeCidade}
                  disabled={!allBipped}
                  className={cn(
                    'w-full py-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all',
                    allBipped
                      ? 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-lg shadow-emerald-500/20'
                      : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  )}
                >
                  <CheckCircle2 className="w-5 h-5" />
                  {allBipped ? 'FINALIZAR CIDADE' : `Faltam ${totalCidade - bipCount} pacotes`}
                </button>
              </div>

              {/* PACOTES FALTANTES */}
              {pacotesFaltantes.length > 0 && (
                <div className="bg-white rounded-xl border border-red-200 shadow-sm p-4 mb-4">
                  <h3 className="text-sm font-semibold text-red-700 mb-2 flex items-center gap-2">
                    <XCircle className="w-4 h-4" />
                    Pacotes Faltantes ({pacotesFaltantes.length})
                  </h3>
                  <div className="max-h-48 overflow-y-auto space-y-1">
                    {pacotesFaltantes.map((p) => (
                      <div key={p.id} className="flex items-center gap-2 py-1.5 px-3 rounded bg-red-50">
                        <Package className="w-3.5 h-3.5 text-red-500" />
                        <span className="text-xs font-mono text-red-700">{p.codigo_rastreio}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* PACOTES JÁ CONFERIDOS */}
              {pacotesConferidos.length > 0 && (
                <div className="bg-white rounded-xl border border-green-200 shadow-sm p-4">
                  <h3 className="text-sm font-semibold text-green-700 mb-2 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4" />
                    Pacotes Já Conferidos ({pacotesConferidos.length})
                  </h3>
                  <div className="max-h-48 overflow-y-auto space-y-1">
                    {pacotesConferidos.map((p) => (
                      <div key={p.id} className="flex items-center gap-2 py-1.5 px-3 rounded bg-green-50">
                        <Package className="w-3.5 h-3.5 text-green-600" />
                        <span className="text-xs font-mono text-green-700">{p.codigo_rastreio}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}