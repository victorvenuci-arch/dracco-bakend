import { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useProfile } from '@/hooks/useProfile';
import { client } from '@/lib/api';
import { cn } from '@/lib/utils';
import type { Cidade } from '@/lib/types';
import { entityUpdate } from '@/lib/apiHelpers';
import { toast } from 'sonner';
import {
  Loader2,
  ScanLine,
  Trash2,
  CheckCircle2,
  Package,
  MapPin,
  Calendar,
  Truck,
  X,
  Camera,
  Keyboard,
  ArrowLeft,
  RefreshCw,
  SwitchCamera,
} from 'lucide-react';

type ViewMode = 'home' | 'triagem';

export default function AuxiliarPage() {
  const navigate = useNavigate();
  const { user, profile, loading, logout, clearProfile } = useProfile();
  const [cidades, setCidades] = useState<Cidade[]>([]);
  const [loadingData, setLoadingData] = useState(false);
  const [viewMode, setViewMode] = useState<ViewMode>('home');

  // Scanner state
  const [scannedCodes, setScannedCodes] = useState<string[]>([]);
  const [scannerActive, setScannerActive] = useState(false);
  const [lastScannedCode, setLastScannedCode] = useState('');
  const [flashColor, setFlashColor] = useState<'green' | 'red' | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const html5QrCodeRef = useRef<any>(null);
  const [cameras, setCameras] = useState<{ id: string; label: string }[]>([]);
  const [selectedCameraIdx, setSelectedCameraIdx] = useState(0);
  const [cameraError, setCameraError] = useState('');

  // Manual TBR input
  const [manualCode, setManualCode] = useState('');
  const manualInputRef = useRef<HTMLInputElement>(null);

  // Batch config
  const [selectedCidade, setSelectedCidade] = useState<number | ''>('');
  const [dataVencimento, setDataVencimento] = useState('');
  const [confirming, setConfirming] = useState(false);

  // Keep a ref to scannedCodes for use inside scanner callback
  const scannedCodesRef = useRef<string[]>([]);
  useEffect(() => {
    scannedCodesRef.current = scannedCodes;
  }, [scannedCodes]);

  const triggerFlash = useCallback((color: 'green' | 'red') => {
    setFlashColor(color);
    setTimeout(() => setFlashColor(null), 300);
  }, []);

  const beepSuccess = useCallback(() => {
    try {
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.value = 1200;
      gain.gain.value = 0.3;
      osc.start();
      osc.stop(ctx.currentTime + 0.15);
    } catch {
      // ignore
    }
  }, []);

  const beepError = useCallback(() => {
    try {
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.value = 300;
      gain.gain.value = 0.3;
      osc.start();
      osc.stop(ctx.currentTime + 0.3);
    } catch {
      // ignore
    }
  }, []);

  const vibrate = useCallback((pattern: number | number[]) => {
    try {
      if (navigator.vibrate) navigator.vibrate(pattern);
    } catch {
      // ignore
    }
  }, []);

  const addCode = useCallback(
    (code: string) => {
      const trimmed = code.trim();
      if (!trimmed) return;
      if (scannedCodesRef.current.includes(trimmed)) {
        beepError();
        vibrate([100, 50, 100]);
        triggerFlash('red');
        toast.error('Código já lido!');
      } else {
        beepSuccess();
        vibrate(100);
        triggerFlash('green');
        setScannedCodes((prev) => [...prev, trimmed]);
        setLastScannedCode(trimmed);
        toast.success(`Código adicionado: ${trimmed}`);
        setTimeout(() => setLastScannedCode((prev) => (prev === trimmed ? '' : prev)), 2000);
      }
    },
    [beepError, beepSuccess, vibrate, triggerFlash]
  );

  const loadData = useCallback(async () => {
    setLoadingData(true);
    try {
      const res = await client.entities.cidades.query({ query: {}, limit: 50 });
      const allCidades = (res?.data?.items || []) as Cidade[];
      setCidades(allCidades);
    } catch {
      // ignore
    } finally {
      setLoadingData(false);
    }
  }, []);

  useEffect(() => {
    if (user && profile) loadData();
  }, [user, profile, loadData]);

  useEffect(() => {
    if (!loading && user && !profile) {
      navigate('/', { replace: true });
    } else if (!loading && user && profile && profile.perfil !== 'AUXILIAR') {
      navigate('/', { replace: true });
    }
  }, [loading, user, profile, navigate]);

  // Cleanup scanner on unmount
  useEffect(() => {
    return () => {
      stopScanner();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const stopCameraStream = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  }, []);

  const stopScanner = useCallback(async () => {
    if (html5QrCodeRef.current) {
      try {
        const state = html5QrCodeRef.current.getState();
        // State 2 = SCANNING
        if (state === 2) {
          await html5QrCodeRef.current.stop();
        }
        html5QrCodeRef.current.clear();
      } catch {
        // ignore
      }
      html5QrCodeRef.current = null;
    }
    stopCameraStream();
    setScannerActive(false);
  }, [stopCameraStream]);

  const startScanner = useCallback(
    async (cameraDeviceId?: string) => {
      setCameraError('');

      try {
        // First, request camera permission explicitly via getUserMedia
        // This ensures the browser prompts the user for permission
        const testStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' },
        });
        // Stop the test stream immediately - html5-qrcode will manage its own stream
        testStream.getTracks().forEach((t) => t.stop());

        // Dynamic import html5-qrcode
        const { Html5Qrcode } = await import('html5-qrcode');

        // Get available cameras
        const devices = await Html5Qrcode.getCameras();
        if (devices.length === 0) {
          setCameraError('Nenhuma câmera encontrada. Verifique as permissões do navegador.');
          return;
        }

        const cameraList = devices.map((d, i) => ({
          id: d.id,
          label: d.label || `Câmera ${i + 1}`,
        }));
        setCameras(cameraList);

        // Select camera: prefer environment-facing, or use provided ID
        let camId = cameraDeviceId || '';
        if (!camId) {
          const envCam = devices.find(
            (d) =>
              d.label.toLowerCase().includes('back') ||
              d.label.toLowerCase().includes('rear') ||
              d.label.toLowerCase().includes('traseira') ||
              d.label.toLowerCase().includes('environment')
          );
          camId = envCam ? envCam.id : devices[0].id;
          const idx = devices.findIndex((d) => d.id === camId);
          setSelectedCameraIdx(idx >= 0 ? idx : 0);
        }

        // Stop existing scanner if any
        if (html5QrCodeRef.current) {
          try {
            const state = html5QrCodeRef.current.getState();
            if (state === 2) {
              await html5QrCodeRef.current.stop();
            }
            html5QrCodeRef.current.clear();
          } catch {
            // ignore
          }
        }

        const scannerId = 'qr-scanner-region';
        const scannerEl = document.getElementById(scannerId);
        if (!scannerEl) {
          setCameraError('Elemento do scanner não encontrado.');
          return;
        }

        // Clear any leftover content
        scannerEl.innerHTML = '';

        const html5QrCode = new Html5Qrcode(scannerId);
        html5QrCodeRef.current = html5QrCode;

        // Calculate scanner box size based on viewport
        const containerWidth = scannerEl.clientWidth || 300;
        const qrboxSize = Math.min(containerWidth - 40, 250);

        await html5QrCode.start(
          camId,
          {
            fps: 10,
            qrbox: { width: qrboxSize, height: qrboxSize },
            aspectRatio: 1.0,
          },
          (decodedText: string) => {
            addCode(decodedText);
          },
          () => {
            // ignore scan failures (no QR found in frame)
          }
        );

        setScannerActive(true);
      } catch (err: any) {
        console.error('Scanner error:', err);
        if (
          err?.message?.includes('Permission') ||
          err?.name === 'NotAllowedError' ||
          err?.message?.includes('denied')
        ) {
          setCameraError(
            'Permita acesso à câmera para iniciar a triagem. Verifique se a aplicação está publicada (HTTPS).'
          );
        } else if (err?.message?.includes('NotFoundError') || err?.name === 'NotFoundError') {
          setCameraError('Nenhuma câmera encontrada no dispositivo.');
        } else if (err?.message?.includes('NotReadableError') || err?.name === 'NotReadableError') {
          setCameraError('Câmera em uso por outro aplicativo. Feche outros apps e tente novamente.');
        } else {
          setCameraError(`Erro ao iniciar câmera: ${err?.message || 'Erro desconhecido'}`);
        }
      }
    },
    [addCode]
  );

  const switchCamera = useCallback(async () => {
    if (cameras.length <= 1) return;
    const nextIdx = (selectedCameraIdx + 1) % cameras.length;
    setSelectedCameraIdx(nextIdx);
    await stopScanner();
    // Small delay to let DOM settle
    setTimeout(() => {
      startScanner(cameras[nextIdx].id);
    }, 400);
  }, [cameras, selectedCameraIdx, stopScanner, startScanner]);

  const handleManualAdd = () => {
    if (manualCode.trim()) {
      addCode(manualCode);
      setManualCode('');
      manualInputRef.current?.focus();
    }
  };

  const handleManualKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleManualAdd();
    }
  };

  const handleRemoveCode = (code: string) => {
    setScannedCodes((prev) => prev.filter((c) => c !== code));
  };

  const handleStartTriagem = async () => {
    setViewMode('triagem');
    // Start camera after a small delay for DOM to render
    setTimeout(() => {
      startScanner();
    }, 600);
  };

  const handleConfirmTriagem = async () => {
    if (!selectedCidade || !dataVencimento || scannedCodes.length === 0) return;
    setConfirming(true);
    try {
      const cidadeId = Number(selectedCidade);
      const cidade = cidades.find((c) => c.id === cidadeId);
      if (!cidade) return;

      if (cidade.status === 'EM_ROTA') {
        toast.error('Cidade já despachada. Não é possível realizar triagem.');
        setConfirming(false);
        return;
      }

      let created = 0;
      let duplicates = 0;

      for (const code of scannedCodes) {
        try {
          await client.entities.pacotes.create({
            data: {
              codigo_rastreio: code,
              cidade_id: cidadeId,
              cidade_nome: cidade.nome,
              data_vencimento: dataVencimento,
              auxiliar_responsavel: profile?.nome || '',
              status: 'AGUARDANDO_DESPACHO',
              created_at: new Date().toISOString(),
            },
          });

          await client.entities.leituras_auxiliar.create({
            data: {
              codigo_rastreio: code,
              cidade_id: cidadeId,
              cidade_nome: cidade.nome,
              data_vencimento: dataVencimento,
              auxiliar_nome: profile?.nome || '',
              created_at: new Date().toISOString(),
            },
          });

          created++;
        } catch {
          duplicates++;
        }
      }

      if (created > 0) {
        await entityUpdate('cidades', cidadeId, { status: 'AGUARDANDO_DESPACHO' });
      }

      await client.entities.resumos_triagem.create({
        data: {
          cidade_id: cidadeId,
          cidade_nome: cidade.nome,
          quantidade_pacotes: created,
          data_vencimento: dataVencimento,
          auxiliar_responsavel: profile?.nome || '',
          status: 'AGUARDANDO_DESPACHO',
          created_at: new Date().toISOString(),
        },
      });

      toast.success(
        `Triagem finalizada: ${created} pacotes criados${duplicates > 0 ? `, ${duplicates} erros` : ''}`
      );
      await stopScanner();
      setScannedCodes([]);
      setSelectedCidade('');
      setDataVencimento('');
      setViewMode('home');
    } catch {
      toast.error('Erro ao finalizar triagem');
    } finally {
      setConfirming(false);
    }
  };

  const handleCancelTriagem = async () => {
    await stopScanner();
    setViewMode('home');
    setScannedCodes([]);
    setSelectedCidade('');
    setDataVencimento('');
    setLastScannedCode('');
  };

  if (loading || !user || !profile) {
    return (
      <div className="min-h-screen bg-[#0F172A] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0F172A] relative overflow-x-hidden">
      {/* Flash overlay */}
      {flashColor && (
        <div
          className={cn(
            'fixed inset-0 z-[100] pointer-events-none transition-opacity duration-200',
            flashColor === 'green' ? 'bg-emerald-500/30' : 'bg-red-500/30'
          )}
        />
      )}

      {/* Top bar - compact for mobile */}
      <div className="sticky top-0 z-50 bg-[#0F172A]/95 backdrop-blur-sm border-b border-white/10 px-3 py-2 sm:px-4 sm:py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="w-7 h-7 sm:w-9 sm:h-9 rounded-lg bg-gradient-to-br from-emerald-500 to-cyan-400 flex items-center justify-center flex-shrink-0">
              <Truck className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />
            </div>
            <div className="min-w-0">
              <h1 className="text-xs sm:text-sm font-bold text-white">DRACCO</h1>
              <p className="text-[9px] sm:text-[10px] text-slate-400 truncate">{profile.nome} — Auxiliar</p>
            </div>
          </div>
          <div className="flex items-center gap-1 sm:gap-2 flex-shrink-0">
            <button
              onClick={clearProfile}
              className="text-[9px] sm:text-[10px] text-slate-400 hover:text-white px-1.5 sm:px-2 py-1 rounded-lg hover:bg-white/10 transition-all"
            >
              Trocar
            </button>
            <button
              onClick={logout}
              className="text-[9px] sm:text-[10px] text-red-400 hover:text-red-300 px-1.5 sm:px-2 py-1 rounded-lg hover:bg-red-500/10 transition-all"
            >
              Sair
            </button>
          </div>
        </div>
      </div>

      <div className="px-3 py-3 sm:px-4 sm:py-4">
        {/* HOME VIEW */}
        {viewMode === 'home' && (
          <div className="max-w-md mx-auto text-center py-10 sm:py-16">
            <div className="w-16 h-16 sm:w-24 sm:h-24 rounded-2xl sm:rounded-3xl bg-gradient-to-br from-cyan-500 to-teal-600 flex items-center justify-center mx-auto mb-6 sm:mb-8 shadow-2xl shadow-cyan-500/30">
              <ScanLine className="w-8 h-8 sm:w-12 sm:h-12 text-white" />
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white mb-2 sm:mb-3">Pronto para Triagem</h2>
            <p className="text-xs sm:text-sm text-slate-400 mb-8 sm:mb-10 px-4">
              A câmera será aberta automaticamente para escanear QR Codes e códigos de barras
            </p>
            <button
              onClick={handleStartTriagem}
              className="px-6 sm:px-10 py-4 sm:py-5 rounded-2xl bg-gradient-to-r from-emerald-600 to-emerald-500 text-white font-bold text-base sm:text-xl hover:from-emerald-700 hover:to-emerald-600 shadow-2xl shadow-emerald-500/40 transition-all flex items-center gap-3 sm:gap-4 mx-auto active:scale-95"
            >
              <Camera className="w-5 h-5 sm:w-7 sm:h-7" />
              REALIZAR TRIAGEM
            </button>
          </div>
        )}

        {/* TRIAGEM VIEW */}
        {viewMode === 'triagem' && (
          <div className="max-w-lg mx-auto space-y-3 sm:space-y-4">
            {/* Back button + counter row */}
            <div className="flex items-center justify-between">
              <button
                onClick={handleCancelTriagem}
                className="flex items-center gap-1.5 text-slate-400 hover:text-white text-xs sm:text-sm transition-all"
              >
                <ArrowLeft className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                Voltar
              </button>
              <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-xl px-3 py-1.5 sm:px-4 sm:py-2">
                <Package className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-400" />
                <span className="text-lg sm:text-2xl font-bold text-white">{scannedCodes.length}</span>
                <span className="text-[10px] sm:text-xs text-slate-400">lidos</span>
              </div>
            </div>

            {/* Last scanned code */}
            {lastScannedCode && (
              <div className="bg-emerald-500/20 border border-emerald-500/40 rounded-xl sm:rounded-2xl p-3 sm:p-4 text-center animate-pulse">
                <p className="text-[9px] sm:text-[10px] text-emerald-400 uppercase tracking-wider mb-0.5">Último TBR</p>
                <p className="text-base sm:text-xl font-bold font-mono text-emerald-300 break-all">{lastScannedCode}</p>
              </div>
            )}

            {/* Camera Scanner - responsive height */}
            <div className="bg-white/5 border border-white/10 rounded-xl sm:rounded-2xl overflow-hidden">
              <div className="flex items-center justify-between px-3 sm:px-4 py-2 sm:py-3 border-b border-white/10">
                <div className="flex items-center gap-1.5 sm:gap-2">
                  <Camera className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-cyan-400" />
                  <span className="text-xs sm:text-sm font-medium text-white">Scanner</span>
                  {scannerActive && (
                    <span className="flex items-center gap-1">
                      <span className="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-green-500 animate-pulse" />
                      <span className="text-[9px] sm:text-[10px] text-green-400">Ativo</span>
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-1.5 sm:gap-2">
                  {cameras.length > 1 && (
                    <button
                      onClick={switchCamera}
                      className="p-1 sm:p-1.5 rounded-lg bg-white/10 text-white hover:bg-white/20 transition-colors"
                      title="Trocar câmera"
                    >
                      <SwitchCamera className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    </button>
                  )}
                  {scannerActive ? (
                    <button
                      onClick={stopScanner}
                      className="p-1 sm:p-1.5 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-colors"
                    >
                      <X className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    </button>
                  ) : (
                    <button
                      onClick={() => startScanner()}
                      className="p-1 sm:p-1.5 rounded-lg bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30 transition-colors"
                    >
                      <RefreshCw className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Scanner region - constrained height for mobile */}
              <div className="relative w-full" style={{ maxHeight: '45vh' }}>
                <div
                  id="qr-scanner-region"
                  className="w-full"
                  style={{ maxHeight: '45vh', overflow: 'hidden' }}
                />
                <video ref={videoRef} className="hidden" />
                {!scannerActive && !cameraError && (
                  <div className="flex items-center justify-center py-10 sm:py-16">
                    <button
                      onClick={() => startScanner()}
                      className="flex flex-col items-center gap-2 sm:gap-3 text-slate-400 hover:text-white transition-all"
                    >
                      <Camera className="w-8 h-8 sm:w-10 sm:h-10" />
                      <span className="text-xs sm:text-sm">Iniciar Câmera</span>
                    </button>
                  </div>
                )}
                {cameraError && (
                  <div className="p-4 sm:p-6 text-center">
                    <Camera className="w-8 h-8 sm:w-10 sm:h-10 text-amber-400 mx-auto mb-2 sm:mb-3" />
                    <p className="text-xs sm:text-sm text-amber-300 mb-2 sm:mb-3">{cameraError}</p>
                    <button
                      onClick={() => startScanner()}
                      className="px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg bg-amber-500/20 text-amber-300 text-xs sm:text-sm hover:bg-amber-500/30 transition-all"
                    >
                      Tentar Novamente
                    </button>
                  </div>
                )}
              </div>

              {/* Camera info */}
              {scannerActive && cameras.length > 0 && (
                <div className="px-3 sm:px-4 py-1.5 sm:py-2 border-t border-white/5 bg-white/[0.02]">
                  <p className="text-[9px] sm:text-[10px] text-slate-500 truncate">
                    📷 {cameras[selectedCameraIdx]?.label || 'Câmera'}
                    {cameras.length > 1 && ` (${selectedCameraIdx + 1}/${cameras.length})`}
                  </p>
                </div>
              )}
            </div>

            {/* Manual Input */}
            <div className="bg-white/5 border border-white/10 rounded-xl sm:rounded-2xl p-3 sm:p-4">
              <label className="flex items-center gap-1.5 sm:gap-2 text-[10px] sm:text-xs font-medium text-slate-400 mb-1.5 sm:mb-2">
                <Keyboard className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                Digitar código manual (TBR)
              </label>
              <div className="flex gap-2">
                <input
                  ref={manualInputRef}
                  type="text"
                  value={manualCode}
                  onChange={(e) => setManualCode(e.target.value)}
                  onKeyDown={handleManualKeyDown}
                  placeholder="Digite o código..."
                  className="flex-1 min-w-0 px-2.5 sm:px-3 py-2 sm:py-2.5 rounded-lg sm:rounded-xl bg-white/10 border border-white/10 text-white text-xs sm:text-sm font-mono placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                />
                <button
                  onClick={handleManualAdd}
                  disabled={!manualCode.trim()}
                  className={cn(
                    'px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg sm:rounded-xl font-bold text-xs sm:text-sm transition-all flex-shrink-0',
                    manualCode.trim()
                      ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                      : 'bg-white/5 text-slate-500 cursor-not-allowed'
                  )}
                >
                  Adicionar
                </button>
              </div>
            </div>

            {/* Scanned List - compact on mobile */}
            {scannedCodes.length > 0 && (
              <div className="bg-white/5 border border-white/10 rounded-xl sm:rounded-2xl p-3 sm:p-4">
                <h3 className="text-xs sm:text-sm font-semibold text-slate-300 mb-2 sm:mb-3">
                  Lista Temporária ({scannedCodes.length})
                </h3>
                <div className="max-h-32 sm:max-h-48 overflow-y-auto space-y-1">
                  {[...scannedCodes].reverse().map((code, idx) => (
                    <div
                      key={code}
                      className="flex items-center justify-between py-1.5 sm:py-2 px-2 sm:px-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                    >
                      <div className="flex items-center gap-1.5 sm:gap-2 min-w-0">
                        <span className="text-[10px] sm:text-xs text-slate-500 w-5 sm:w-6 flex-shrink-0">
                          {scannedCodes.length - idx}.
                        </span>
                        <span className="text-xs sm:text-sm font-mono text-white truncate">{code}</span>
                      </div>
                      <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
                        <span className="text-[9px] sm:text-[10px] px-1.5 sm:px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-semibold">
                          Lido
                        </span>
                        <button
                          onClick={() => handleRemoveCode(code)}
                          className="p-0.5 sm:p-1 text-red-400 hover:text-red-300"
                        >
                          <Trash2 className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Triage Config */}
            <div className="bg-white/5 border border-white/10 rounded-xl sm:rounded-2xl p-3 sm:p-4 space-y-3 sm:space-y-4">
              <h3 className="text-xs sm:text-sm font-semibold text-white flex items-center gap-1.5 sm:gap-2">
                <Package className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-400" />
                Confirmar Triagem
              </h3>

              <div>
                <label className="flex items-center gap-1.5 sm:gap-2 text-[10px] sm:text-xs font-medium text-slate-400 mb-1">
                  <MapPin className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                  Cidade dos Pacotes
                </label>
                <select
                  value={selectedCidade}
                  onChange={(e) => setSelectedCidade(Number(e.target.value) || '')}
                  className="w-full px-2.5 sm:px-3 py-2 sm:py-2.5 rounded-lg sm:rounded-xl bg-white/10 border border-white/10 text-white text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                >
                  <option value="" className="bg-slate-800">Selecione uma cidade...</option>
                  {cidades
                    .filter((c) => c.status !== 'EM_ROTA')
                    .map((c) => (
                      <option key={c.id} value={c.id} className="bg-slate-800">
                        {c.nome}
                      </option>
                    ))}
                </select>
                {cidades.some((c) => c.status === 'EM_ROTA') && (
                  <p className="text-[9px] sm:text-[10px] text-amber-400 mt-1">
                    ⚠️ Cidades em rota estão bloqueadas para triagem
                  </p>
                )}
              </div>

              <div>
                <label className="flex items-center gap-1.5 sm:gap-2 text-[10px] sm:text-xs font-medium text-slate-400 mb-1">
                  <Calendar className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                  Data de Vencimento
                </label>
                <input
                  type="date"
                  value={dataVencimento}
                  onChange={(e) => setDataVencimento(e.target.value)}
                  className="w-full px-2.5 sm:px-3 py-2 sm:py-2.5 rounded-lg sm:rounded-xl bg-white/10 border border-white/10 text-white text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                />
              </div>

              <div>
                <label className="flex items-center gap-1.5 sm:gap-2 text-[10px] sm:text-xs font-medium text-slate-400 mb-1">
                  <Truck className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                  Responsável
                </label>
                <div className="px-2.5 sm:px-3 py-2 sm:py-2.5 rounded-lg sm:rounded-xl bg-white/5 border border-white/10 text-xs sm:text-sm text-slate-300">
                  {profile.nome} (automático)
                </div>
              </div>

              {/* Summary */}
              <div className="bg-emerald-500/10 rounded-lg sm:rounded-xl p-3 sm:p-4 border border-emerald-500/20">
                <h4 className="text-[10px] sm:text-xs font-semibold text-emerald-400 mb-1.5 sm:mb-2">Resumo</h4>
                <div className="space-y-0.5 sm:space-y-1 text-[10px] sm:text-xs text-emerald-300">
                  <p>Códigos: <strong>{scannedCodes.length}</strong></p>
                  <p>Cidade: <strong>{cidades.find((c) => c.id === Number(selectedCidade))?.nome || '—'}</strong></p>
                  <p>Vencimento: <strong>{dataVencimento || '—'}</strong></p>
                </div>
              </div>

              <button
                onClick={handleConfirmTriagem}
                disabled={confirming || !selectedCidade || !dataVencimento || scannedCodes.length === 0}
                className={cn(
                  'w-full py-3 sm:py-4 rounded-lg sm:rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all',
                  selectedCidade && dataVencimento && scannedCodes.length > 0 && !confirming
                    ? 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-lg shadow-emerald-500/20'
                    : 'bg-white/5 text-slate-500 cursor-not-allowed'
                )}
              >
                {confirming ? (
                  <Loader2 className="w-4 h-4 sm:w-5 sm:h-5 animate-spin" />
                ) : (
                  <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5" />
                )}
                {confirming
                  ? 'Finalizando...'
                  : `FINALIZAR TRIAGEM (${scannedCodes.length})`}
              </button>
            </div>

            {/* Bottom spacer for mobile */}
            <div className="h-4 sm:h-0" />
          </div>
        )}
      </div>
    </div>
  );
}