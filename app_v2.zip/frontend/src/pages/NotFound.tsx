import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft, MapPin } from 'lucide-react';

export default function NotFound() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center p-6">
      <div className="text-center max-w-md">
        <div className="w-16 h-16 rounded-2xl bg-slate-100 flex items-center justify-center mx-auto mb-6">
          <MapPin className="w-8 h-8 text-slate-400" />
        </div>
        <h1 className="text-4xl font-bold text-slate-800 mb-2">404</h1>
        <p className="text-lg text-slate-600 mb-1">Página no encontrada</p>
        <p className="text-sm text-slate-400 mb-6">
          La ruta que buscas no existe o ha sido movida.
        </p>
        <Button onClick={() => navigate('/')} className="bg-blue-600 hover:bg-blue-700 text-white gap-2">
          <ArrowLeft className="w-4 h-4" />
          Volver al inicio
        </Button>
      </div>
    </div>
  );
}