import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useProfile } from '@/hooks/useProfile';
import ProfileSelect from '@/pages/ProfileSelect';
import { Loader2, LogIn, Truck } from 'lucide-react';

export default function IndexPage() {
  const navigate = useNavigate();
  const { user, profile, loading, login, selectProfile } = useProfile();

  useEffect(() => {
    if (!loading && user && profile) {
      switch (profile.perfil) {
        case 'ADMINISTRADOR':
          navigate('/administrador', { replace: true });
          break;
        case 'GESTOR':
          navigate('/gestor', { replace: true });
          break;
        case 'AUXILIAR':
          navigate('/auxiliar', { replace: true });
          break;
        case 'MOTORISTA':
          navigate('/scanner', { replace: true });
          break;
        case 'ENTREGADOR':
          navigate('/entregador', { replace: true });
          break;
        default:
          break;
      }
    }
  }, [loading, user, profile, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0F172A] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#0F172A] via-[#1E293B] to-[#0F172A] flex items-center justify-center p-4">
        <div className="text-center">
          <div className="flex items-center justify-center gap-3 mb-8">
            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-emerald-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-emerald-500/25">
              <Truck className="w-7 h-7 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">DRACCO</h1>
          <p className="text-slate-400 mb-2">Sistema Logístico Profissional</p>
          <p className="text-slate-500 text-sm mb-8">Administrador · Gestor · Auxiliar · Motorista · Entregador</p>
          <button
            onClick={login}
            className="px-8 py-4 rounded-xl bg-emerald-600 text-white font-bold text-lg hover:bg-emerald-700 shadow-lg shadow-emerald-500/30 transition-all flex items-center gap-3 mx-auto"
          >
            <LogIn className="w-5 h-5" />
            Entrar no Sistema
          </button>
        </div>
      </div>
    );
  }

  if (!profile) {
    return <ProfileSelect userName={user.name || user.email || ''} onSelect={selectProfile} />;
  }

  return (
    <div className="min-h-screen bg-[#0F172A] flex items-center justify-center">
      <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
    </div>
  );
}