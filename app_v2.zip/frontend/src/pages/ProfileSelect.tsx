import { useState, useEffect } from 'react';
import { Shield, LayoutDashboard, ClipboardList, ScanLine, PackageCheck, Loader2, Truck } from 'lucide-react';
import { client } from '@/lib/api';
import { cn } from '@/lib/utils';
import type { UserProfile, Cidade } from '@/lib/types';

interface ProfileSelectProps {
  userName: string;
  onSelect: (nome: string, perfil: UserProfile, cidadeId?: number, cidadeNome?: string) => Promise<void>;
}

export default function ProfileSelect({ userName, onSelect }: ProfileSelectProps) {
  const [selectedProfile, setSelectedProfile] = useState<UserProfile | null>(null);
  const [nome, setNome] = useState(userName || '');
  const [cidades, setCidades] = useState<Cidade[]>([]);
  const [selectedCidade, setSelectedCidade] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const loadCidades = async () => {
      try {
        const res = await client.entities.cidades.query({ query: {}, limit: 50 });
        setCidades((res?.data?.items || []) as Cidade[]);
      } catch {
        // ignore
      }
    };
    loadCidades();
  }, []);

  const handleConfirm = async () => {
    if (!selectedProfile || !nome.trim()) return;
    if (selectedProfile === 'ENTREGADOR' && !selectedCidade) return;
    setSaving(true);
    try {
      const cidade = cidades.find((c) => c.id === selectedCidade);
      await onSelect(nome.trim(), selectedProfile, selectedCidade || undefined, cidade?.nome || undefined);
    } finally {
      setSaving(false);
    }
  };

  const profiles = [
    {
      type: 'ADMINISTRADOR' as UserProfile,
      label: 'Administrador',
      desc: 'Gerenciar estrutura do sistema',
      icon: Shield,
      color: 'from-red-500 to-rose-600',
      shadow: 'shadow-red-500/30',
    },
    {
      type: 'GESTOR' as UserProfile,
      label: 'Gestor',
      desc: 'Gerenciar auxiliares, rotas e despachos',
      icon: LayoutDashboard,
      color: 'from-blue-500 to-indigo-600',
      shadow: 'shadow-blue-500/30',
    },
    {
      type: 'AUXILIAR' as UserProfile,
      label: 'Auxiliar',
      desc: 'Escanear e cadastrar pacotes',
      icon: ClipboardList,
      color: 'from-cyan-500 to-teal-600',
      shadow: 'shadow-cyan-500/30',
    },
    {
      type: 'MOTORISTA' as UserProfile,
      label: 'Motorista',
      desc: 'Escanear pacotes nas cidades da rota',
      icon: ScanLine,
      color: 'from-amber-500 to-orange-600',
      shadow: 'shadow-amber-500/30',
    },
    {
      type: 'ENTREGADOR' as UserProfile,
      label: 'Entregador',
      desc: 'Confirmar recebimento dos pacotes',
      icon: PackageCheck,
      color: 'from-green-500 to-emerald-600',
      shadow: 'shadow-green-500/30',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0F172A] via-[#1E293B] to-[#0F172A] flex items-center justify-center p-4">
      <div className="w-full max-w-lg">
        {/* Logo */}
        <div className="flex items-center justify-center gap-3 mb-8">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-emerald-500/25">
            <Truck className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">DRACCO</h1>
            <p className="text-xs text-slate-400">Selecione seu perfil</p>
          </div>
        </div>

        {/* Name Input */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-slate-300 mb-2">Seu Nome</label>
          <input
            type="text"
            value={nome}
            onChange={(e) => setNome(e.target.value)}
            placeholder="Digite seu nome..."
            className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/10 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500/50"
          />
        </div>

        {/* Profile Cards */}
        <div className="space-y-3 mb-6">
          {profiles.map((p) => {
            const Icon = p.icon;
            const isSelected = selectedProfile === p.type;
            return (
              <button
                key={p.type}
                onClick={() => {
                  setSelectedProfile(p.type);
                  if (p.type !== 'ENTREGADOR') setSelectedCidade(null);
                }}
                className={cn(
                  'w-full flex items-center gap-4 p-4 rounded-xl border transition-all duration-200 text-left',
                  isSelected
                    ? 'bg-white/10 border-emerald-500/50 shadow-lg'
                    : 'bg-white/5 border-white/5 hover:bg-white/10 hover:border-white/10'
                )}
              >
                <div
                  className={cn(
                    'w-12 h-12 rounded-xl flex items-center justify-center shadow-lg bg-gradient-to-br',
                    p.color,
                    p.shadow
                  )}
                >
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-white">{p.label}</p>
                  <p className="text-xs text-slate-400">{p.desc}</p>
                </div>
                <div
                  className={cn(
                    'w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all',
                    isSelected ? 'border-emerald-500 bg-emerald-500' : 'border-slate-500'
                  )}
                >
                  {isSelected && <div className="w-2 h-2 rounded-full bg-white" />}
                </div>
              </button>
            );
          })}
        </div>

        {/* City Selection for Entregador */}
        {selectedProfile === 'ENTREGADOR' && (
          <div className="mb-6">
            <label className="block text-sm font-medium text-slate-300 mb-2">Cidade Vinculada</label>
            <select
              value={selectedCidade || ''}
              onChange={(e) => setSelectedCidade(Number(e.target.value) || null)}
              className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
            >
              <option value="" className="bg-slate-800">Selecione uma cidade...</option>
              {cidades.map((c) => (
                <option key={c.id} value={c.id} className="bg-slate-800">
                  {c.nome}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Confirm Button */}
        <button
          onClick={handleConfirm}
          disabled={!selectedProfile || !nome.trim() || saving || (selectedProfile === 'ENTREGADOR' && !selectedCidade)}
          className={cn(
            'w-full py-4 rounded-xl text-base font-bold transition-all duration-300 flex items-center justify-center gap-2',
            selectedProfile && nome.trim() && !saving
              ? 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-lg shadow-emerald-500/30'
              : 'bg-white/10 text-slate-500 cursor-not-allowed'
          )}
        >
          {saving ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Salvando...
            </>
          ) : (
            'Confirmar Perfil'
          )}
        </button>
      </div>
    </div>
  );
}