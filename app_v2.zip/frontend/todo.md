# DRACCO - Sistema Logístico (Versão Final)

## Design Guidelines
- **Brand**: DRACCO (dark navy + emerald/cyan accents)
- **Color Palette**: Primary #0F172A (Navy), Secondary #1E293B (Dark Slate), Accent #10B981 (Emerald), Cyan #06B6D4
- **Typography**: System sans-serif, bold headings
- **Style**: Dark professional sidebar, light content area

## Status Flow
AGUARDANDO_DESPACHO → EM_ROTA → BIPAGEM_EM_ANDAMENTO → AGUARDANDO_CONFIRMACAO_ENTREGADOR → ENTREGUE_AO_ENTREGADOR

## Profiles (5)
ADMINISTRADOR, GESTOR, AUXILIAR, MOTORISTA, ENTREGADOR

## Files to Create/Update

1. **src/lib/types.ts** - Updated types with 5 profiles, new statuses, new entities
2. **src/lib/api.ts** - Keep existing client setup
3. **src/hooks/useProfile.ts** - Updated for 5 profiles + ativo field
4. **src/components/Sidebar.tsx** - DRACCO branding, 5 profile navs
5. **src/pages/ProfileSelect.tsx** - 5 profile cards, city selection for entregador
6. **src/pages/Index.tsx** - Login DRACCO + routing hub (redirects by profile)
7. **src/pages/Administrador.tsx** - Admin panel: cities, entregador_padrao, motoristas, users
8. **src/pages/Gestor.tsx** - Gestor panel: auxiliares, motoristas, entregadores, PDF, criar rota
9. **src/pages/Auxiliar.tsx** - Scanner QR + batch registration with city/date
10. **src/pages/ScannerMotorista.tsx** - Driver scanner with validations
11. **src/pages/Entregador.tsx** - Delivery confirmation with GPS
12. **src/pages/Historico.tsx** - 30-day history for Admin/Gestor
13. **src/App.tsx** - Updated routes for all pages
14. **index.html** - DRACCO title